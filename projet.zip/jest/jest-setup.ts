import 'jest-preset-angular';
// import './jest-global-mock'; // browser mocks globally available for every test
