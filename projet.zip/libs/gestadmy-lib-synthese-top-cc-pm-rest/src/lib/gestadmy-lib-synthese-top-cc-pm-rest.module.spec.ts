import { async, TestBed } from '@angular/core/testing';
import { GestadmyLibSyntheseTopCcPmRestModule } from './gestadmy-lib-synthese-top-cc-pm-rest.module';

describe('GestadmyLibSyntheseTopCcPmRestModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [GestadmyLibSyntheseTopCcPmRestModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(GestadmyLibSyntheseTopCcPmRestModule).toBeDefined();
  });
});
