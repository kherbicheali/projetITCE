import { RessourceTiersV2Identification } from '../modeles/tiers-v2-identification.modele';

export namespace RessourceMockTiersV2Identification {
  export const identificationRestMock: RessourceTiersV2Identification.IIdentification = {
    donneeIdentification: {
      codeEtablissement: '17515',
      identifiantPersonne: 66912975,
      codePersonnaliteJuridique: '2',
      libellePersonnaliteJuridique: null,
      codeEtatPersonne: '0',
      codeTypeRelation: '0',
      libelleTypeRelation: null,
      dateEntreeRelation: '2001-06-11'
    },
    lutteAntiBlanchiment: null,
    listMarche: [
      {
        codeMarche: '201401',
        libelleLongCodeMarche: 'ENT : GE - Grandes Entreprises (50 M€ <= CA < 100 M€)',
        libelleCourtCodeMarche: 'GE 50-100M€',
        libelleFamilleCodeMarche: 'PME-PMI'
      }
    ],
    suiviComercial: {
      identifiantEDSSuiviCommercial: 355039,
      typeEDSSuiviCommercial: '001',
      referenceExterneEDSSuiviCommercial: 355039,
      identifiantAgent: 7562477,
      designationCourteEDS: 'CHIRON MATHIEU',
      designationLongueEDS: 'MR CHIRON MATHIEU'
    }
  };
}
