import { RessourceTiersV2CorporateEtablissement } from '../modeles/tiers-v2-corporate-etablissement.modele';

export namespace RessourceMockTiersV2CorporateEtablissement {
  export const corporateEtabRestMock: RessourceTiersV2CorporateEtablissement.ICorporateEtablissement = {
    gestionSuite: {
      indicateurListeSuivre: 'F',
      contexteRepositionnementListe: null
    },
    listeMessageFonctionnel: null,
    listeEtablissement: [
      {
        designationCourteLieuActivite: 'XXXXX',
        numeroTelecopieurLieuActivite: '0556081422',
        effectifDuLieuActivite: 0,
        enseigneCommercialeLieuActivit: 'FENTO JCY',
        designationLongueLieuActivite: 'XXXXX',
        numeroSIRENProfessionnel: '398828814',
        numeroComplementSIRETEtabli: '00069',
        codeFamilleAPEINSEE: '74',
        deuxDerniersCaracteresAPE: '1J',
        codeResident: '1',
        codeFamilleNAFINSEE: '70',
        troisDerniersCaracteresNAF: '10Z',
        codeClientTiers: null,
        activiteEconomiqueReelleLieu: null,
        libelleEtablissement: null,
        codeEtablissement: '42559',
        identifiantTiers: 904025074,
        dateDebutExploitationLieuActivite: '1994-07-04',
        dateFinExploitationLieuActivite: null,
        numeroLieuActivite: 1,
        numeroProfessionnel: 1,
        numeroTelexLieuActivite: null,
        listeAdresse: [
          {
            identifiant: 800007029432,
            codeType: '1',
            libelleType: null,
            ligne2AFNOR: null,
            ligne3AFNOR: null,
            ligne4AFNOR: '35 AVENUE AUGUSTE FERRET',
            ligne5AFNOR: null,
            ligne6AFNOR: '33110 LE BOUSCAT',
            codePostalPTT: '33110',
            codeInseePays: '99000',
            codeISOPays: 'FR',
            libelleISOPays: 'FRANCE',
            codeInseeLocalite: '33069',
            libelleInseeLocalite: 'LE BOUSCAT',
            codeTypeRetourPTT: null,
            nombreRetourPTT: 0,
            dateDernierRetourPTT: null,
            indicateurConfirmeAdresse: null
          },
          {
            identifiant: 800012239990,
            codeType: '4',
            libelleType: null,
            ligne2AFNOR: null,
            ligne3AFNOR: null,
            ligne4AFNOR: '35 AVENUE AUGUSTE FERRET',
            ligne5AFNOR: null,
            ligne6AFNOR: '33110 LE BOUSCAT',
            codePostalPTT: '33110',
            codeInseePays: '99000',
            codeISOPays: 'FR',
            libelleISOPays: 'FRANCE',
            codeInseeLocalite: '33069',
            libelleInseeLocalite: 'LE BOUSCAT',
            codeTypeRetourPTT: null,
            nombreRetourPTT: 0,
            dateDernierRetourPTT: null,
            indicateurConfirmeAdresse: null
          }
        ]
      }
    ]
  };
}
