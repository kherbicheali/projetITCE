/* tslint:disable:max-line-length */
export namespace RessourceTiersV2CorporateActiviteProfessionnelle {
  export interface ISituationFinanciere {
    /**
     * Détermine le montant brut de l'activité d'un professionnel sur un exercice annuel :
     * - Le chiffre d'affaires social concerne les entreprises total des ventes TTC de biens et de services
     * - Le montant du budget concerne plus particulièrement les collectivités locales : total des enveloppes de crédits permettant les dépenses de l'exercice.
     *
     * Exprimé en milliers d'euros.
     */
    montantChiffreAffaires: number;
    /**
     * Année de référence du chiffre d'affaire ou du montant du budget.
     */
    anneeChiffreAffaires: number;
    /**
     * Montant des apports (en biens ou numéraires) effectué par les actionnaires ou associés au moment de la création ou de l'augmentation de capital de la société. En milliers d'euros.
     */
    montantCapitalSocial: number;
    /**
     * Montant du capital social de la personne morale exprimé en centimes d'euros.
     */
    montantCapitalSocialEnCentimes: number;
    /**
     * Correspond au volume d'affaire de l'activité de promotion immobilière. Il est stocké en centimes d'Euros, mais restitué au poste de travail en KEuros.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    montantDuCADeLaPromotionImmobiliere: number;
    /**
     * Définition : correspond à l'année de valorisation du volume d'affaire de l'activité de promotion immobilière.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    anneeDuCADeLaPromotionImmobiliere: number;
    /**
     * Cette rubrique permet au central de mettre à jour la date de traçage de la rubrique CA si le CA est saisi sur le PTU. Elle permet aussi au PTU de ne pas afficher les zéros par défaut.
     *
     * Valorisation:
     * - __O__ : Rubrique CA renseignée
     * - __N__ : Rubrique CA non renseignée (zéro par défaut)
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    indicateurDePresenceDuCA: string;
  }

  export interface ISecteurActivite {
    /**
     * Famille de code activité exercée par le professionnel.
     *
     * Exemple:
     * - __01__ : agriculture
     * - __03__ : pêche
     * - __16__ : industrie du verre
     */
    codeDeLaFamilleAPE: string;
    /**
     * Classification des catégories juridiques des personnes selon l'INSEE. Correspond au niveau 2 de la nomenclature de l'INSEE. Correspond aux deux premiers caractères du code catégorie juridique / CODACJ.
     *
     * Typologie gérée dans la table DU1F / appli GESTADM.
     *
     * Exemples:
     * - __11__ : artisan - commerçant
     * - __12__ : commercant
     * - __13__ : artisant
     * - __14__ : officier public ou ministériel
     * - __15__ : profession libéral
     * - __16__ : Exploitant agricole
     * - __19__ : autre personne physique
     */
    codeFamilleCategorieJuridique: string;
    /**
     * Détermine le statut dans une catégorie juridique donnée. Correspond à la typologie de niveau 3 de l'INSEE . Correspond aux 2 derniers caractères du code catégorie juridique / CODACJ : format X4.
     */
    codeCategoJuridi2DerCaracteres: string;
    /**
     * Cette rubrique permet de définir les deux derniers caractères du code APE.
     */
    deuxDernierCaracteresAPE: string;
    /**
     * Précise l'activité économique principale du professionnel. Complète le code APE.
     *
     * Exemples:
     * - Concessionnaire Renault
     * - Franchisé Rodier
     */
    activiteEconomiquePrincipale: string;
    /**
     * Libellé libre qui précise le code APE du lieu d'activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    activiteEconomiqueReelleDuLieu: string;
    /**
     * Détermine une famille d'activités des personnes selon l'INSEE.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codeDeLaFamilleNAF: string;
    /**
     * Détermine une activité au sein d'une famille d'activités selon l'INSEE.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codeNAF3DerniersCaracteres: string;
    /**
     * Code associé à la branche d'activité.
     * Codification pour l'ensemble des caisses.
     * Donnée relative aux personnes morales et entrepreneurs individuels, basée sur une approche commerciale ou sectorielle, permettant de paramétrer des      regroupements fonctionnels de codes NAF.
     * Format XX9999
     */
    brancheActivite: string;
  }

  export interface IInformationJuridique {
    /**
     * Date à laquelle une entité professionnelle a commencé d'exister:
     * - date de début d'exploitation pour les personnes physiques
     * - date de création pour les personnes morales
     * Type date au format yyyy-MM-dd
     */
    dateDeCreation: string;
    /**
     * Date à partir de laquelle une entité professionnelle a cessé d'exister :
     * - date de fin d'exploitation pour les personnes physique
     * - date de dissolution d'une personne morale
     * Type date au format yyyy-MM-dd
     */
    dateDeCloture: string;
    /**
     * Le code situation juridique indique dans quel état juridique se trouve une entité professionnelle.
     *
     * Valorisation:
     * - __1__ : En formation
     * - __2__ : Normale
     * - __3__ : Dissoute
     * - __4__ : Sans objet (pseudo personne morale)
     * - __5__ : En cours d'immatriculation
     *
     * __Gestion des incidents__ : Pour avoir un état complet du professionnel, il faut également vérifier qu'il ne fait pas l'objet d'un incident "redressement liquidation judiciaire".
     */
    codeSituation: string;
    /**
     * Détermine le type de personnalité juridique de la personne.
     *
     * Il existe principalement deux types de personnalité :
     * - PJ physique : concerne les individus
     * - PJ morale : concerne les groupes d'individus et les entités reconnus comme sujets de droit (ex : sociétés, associations ...)
     *
     * La personnalité juridique conditionne les droits et obligations.
     *
     * Valorisation:
     * - __1__ : Personne physique
     * - __2__ : Personne morale ou assimilée morale
     */
    indicateurPersonnePhysiqueOuMorale: string;
    /**
     * Détermine si l'entrepreneur individuel a opté pour le statut à responsabilité limitée. Se traduit par la création d'un patrimoine affecté à l'activité professionnelle et séparé du patrimoine personnel.
     *
     * Valorisation:
     * - __O__ : EI
     * - __N__ : Non Concerné (cas des personnes morales)
     */
    indicateurEIRL: string;
    /**
     * Détermine la date de début de validité de l'option de statut à responsabilité limitée pour un entrepreneur individuel donné.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     * Type date au format yyyy-MM-dd
     */
    dateDeDebutDeOptionEIRL: string;
    /**
     * Détermine la date de fin de validité de l'option de statut à responsabilité limitée pour un entrepreneur individuel donné.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     * Type date au format yyyy-MM-dd
     */
    dateDeFinDeOptionEIRL: string;
    /**
     * Détermine si l'Entrepreneur Individuel a indiqué l'option d'opposabilité de son patrimoine pour ses créances antérieures. Le patrimoine exclusivement affecté à l'activité professionnelle est pris en compte, également pour les litiges antérieurs à la déclaration en EIRL.
     *
     * Valorisation:
     * - __O__ : Oui
     * - __N__ : Non
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    indicateurDeOptionOpposabiliteEIRL: string;
    /**
     * Date de début d'exploitation du lieu d'activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     * Type date au format yyyy-MM-dd
     */
    dateDeDebutExploitationDuLieu: string;
    /**
     * Date de fin d'exploitation du lieu d'activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     * Type date au format yyyy-MM-dd
     */
    dateDeFinExploitationDuLieu: string;
    /**
     * Indicateur de droit au compte
     */
    indicateurDroitAuCompte: string;
    /**
     * Référence d'identification des entités juridiques (LEI : LEGAL ENTITY IDENTIFIER) effectuant des transactions financières.
     */
    identifiantLei: string;
    /**
     * Classification de la personne selon le règlement EMIR / European Market and Infrastructure Regulation. Attribut porté par une contrepartie effectuant une transaction sur le marché des dérivés
     */
    codeEmir: string;
    /**
     * Autorisation donnée par le Client pour que l'Etablissement puisse effectuer des déclarations à sa place (LEI, classification EMIR). 'O' Etab autorisé à effectuer les déclarations 'N' Etab non autorisé à effectuer les déclarations
     */
    indicateurDelegationDeclaration: string;
  }

  export interface IDonneeAdministrative {
    /**
     * Code positionné par traitement qui indique si les données professionnel sont à vérifier.
     *
     * Valorisation:
     * - __0__ : pas de vérification
     * - __1__ : vérification à effectuer
     */
    codeDeRafraichissement: string;
    /**
     * Date système de dernière vérification des données du professionnel.
     * Type date au format yyyy-MM-dd
     */
    dateDeDerniereVerification: string;
    /**
     * Référence libre de la pièce justificative qui a servi lors de la gestion administrative du professionnel.
     *
     * Exemple:
     * - __EXEMPLAIRE DES STATUTS CERTIFIE CONFORME__
     * - __EXEMPLAIRE DU JOURNAL OFFICIEL__
     * - __EXTRAIT DE DELIBERATION SIGNE__
     */
    referenceDeLaPieceJustificative: string;
    /**
     * Code indiquant si l'entreprise est étrangère.
     *
     * Valorisation:
     * - __0__ : Oui
     * - __1__ : Non
     */
    codeIndicateurEntrepriseEtrangere: string;
    /**
     * Détermine une monnaie / devise selon la nomenclature ISO 4217 alpha.
     *
     * Exemple:
     * - __USD__ : dollar - USA
     * - __JPY__ : yen - JAPON
     * - __CNY__ : yuan - CHINE
     * - __DKK__ : couronne - DANEMARK
     */
    codeDevise: string;
    /**
     * __TODO__: Déterminer la différence entre la rubrique ECOLIDV (codeDevise) et la rubrique ECOLID9 (codeDeviseBis).
     */
    codeDeviseBis: string;
    /**
     * Détermine le niveau de relation de la personne avec l’Établissement GCE, personne connue comme :
     * - client : personne détentrice de contrat(s) de produit / service
     * - tiers : personne non _client_ en lien avec une personne _client_; concerne la sphère du Particulier ou Professionnel.
     * Ex : participant à un contrat, représentant légal
     *
     * Le prospect est enregistré comme un tiers au niveau de CODATI et est explicitement déterminé comme prospect dans CDDAPO. Le tiers requiert moins d'information que le client dans la gestion administrative.
     *
     * Caractéristique de la personne / table DU7A. Permet de déterminer la relation-type de la personne.
     *
     * connue avec L’Établissement -> voir CTDAPR en fonction de CDDAPO / code prospect.
     *
     * Valorisation:
     * - __0__ : Client
     * - __1__ : Tiers
     */
    indicateurClientOuTier: string;
    /**
     * Identifie une personne (tiers) dans BPCE. Identifiant Chrono affecté par la Direction. Risque du Groupe via le flux retour de la Base Tiers Groupe (BTG). Cet identifiant correspond à l'identifiant unique de la personne pour l'ensemble du Groupe BPCE.
     *
     * Cet identifiant peut être modifié durant l'existence de la personne au sein du Systeme d'Information. En effet la BTG considère une personne active lorsque celle-ci à des engagements au sens Bâle 2.
     */
    identifiantDuTiersGCE: string;
    /**
     * Code établissement de l'entité appartenant à BPCE identifiée par la DRG comme pilote des données sur un Tiers (personne).
     */
    codeEtablissementDeLEntitePilote: string;
    /**
     * Mode d'imposition auquel est assujetti un professionnel entreprise ou entrepreneur individuel.
     *
     * Valorisation:
     * - __1__ : Forfait
     * - __2__ : Réel
     * - __3__ : Impôt sur les sociétés (IS)
     * - __4__ : Sans régime particulier
     * - __5__ : Réel simplifié
     * - __6__ : Impôt sur le revenu des personnes physiques (IRPP)
     */
    codeRegimeFiscal: string;
    /**
     * Mois d'arrêté de la déclaration risques BDF. Format SSAAMM.
     */
    moisDArreteDesRisquesBDF: string;
    /**
     * Dénomination commerciale se rapportant à un fonds de commerce exploité par une société ou assimilée. Dénomination vis à vis de la clientèle. Peut correspondre à l'enseigne. Une société peut avoir un nom commercial différent pour chacun des fonds de commerce qu'elle exploite.
     *
     * Exemples:
     * - La Samaritaine
     * - But
     */
    nomCommercial: string;
    /**
     * Ordre de grandeur du nombre de salariés (en effet l'effectif peut varier en fonction de l'activité du professionnel).
     */
    nombreDeSalaries: number;
    /**
     * Jour d'arrêté du bilan d'un professionnel pour un exercice donné. Format : JJMM. utilisée en complément de l'année du bilan.
     */
    dateArreteComptable: number;
    /**
     * Date système de mise à jour d'au moins une des données professionnel.
     * Type date au format yyyy-MM-dd
     */
    dateDeMiseAJour: string;
    /**
     * Date système d'enregistrement du professionnel.
     * Type date au format yyyy-MM-dd
     */
    dateEnregistrement: string;
    /**
     * Correspond à l'expérience du dirigeant dans l'activité de promotion immobilière.
     *
     * Valorisation:
     * - __1__ : Moins de 5 ans
     * - __2__ : 5 ans et plus
     * - _blanc_ : Inconnue
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    experienceDuDirigeantEnImmobilier: string;
    /**
     * Correspond à l'année de valorisation de l'expérience du dirigeant concernant l'activité de promotion immobilière.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    anneeDeSaisieDeExperienceDuDirigeant: string;
    /**
     * Nature de l'organisation commerciale; Caractérise l'activité professionnelle.
     *
     * Valorisation:
     * - _blanc_ : Inconnu
     * - __0__ : Non concerné
     * - __1__ : Franchisé ou Entreprise Affiliée
     * - __2__ : Franchiseur ou Tête de Réseau
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    natureDeLOrganisationCommerciale: string;
    /**
     * Détermine le profil d'un professionnel. Classification des professionnels selon la gestion des données comptables et financières.
     *
     * Valorisation:
     * - __Z1__ : 2050 PRO REEL NORMAL
     * - __Z2__ : 2033 PRO REEL SIMPLIFIE
     * - __Z3__ : 2035 PROFESSION LIBERALE
     * - __Z4__ : 2050 PME REEL NORMAL
     * - __Z5__ : AUTRE PRO REEL NORMAL
     * - __Z6__ : AUTRE PRO REEL SIMPLIFIE
     * - __Z7__ : PROFESSIONNEL AU FORFAIT
     * - __ZA__ : 2050 PROMOTEUR
     * - __ZB__ : 2050 LOTISSEUR
     * - __ZC__ : 2050 MARCHAND DE BIENS
     * - __ZD__ : 2050 INVESTISSEUR
     * - __ZE__ : 2050 PRO AUTRES SR
     * - __ZF__ : 2050 PME AUTRES SR
     * - __ZG__ : 2033 PRO AUTRES SR
     * - __ZH__ : 2035 PRO AUTRES SR
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codeDuProfilClient: string;
    /**
     * Résidents:
     * - Personnes physiques ayant leur principal centre d'interet en FRANCE
     * - Fonctionnaires et autres agents publics français en poste à l'etranger
     * - Personnes morales françaises ou étrangères pour leurs etablissement en FRANCE
     * La France est définie comme suit :
     * 	- France métropolitaine (avec la principaute de MONACO )
     * 	- DOM (avec Saint-Pierre et Miquelon)
     * 	- TOM (avec Mayotte)..
     *
     * Non résidents:
     * - Personnes physiques ayant leur principal centre d'interet à l'etranger
     * - Fonctionnaires et autres agents publics étrangers en poste en FRANCE
     * L'étranger est défini comme suite :
     * 	- Pays autre que la France (y compris les Etats dont dont l'Institut d'Emission est lié au Trésor Français
     * 	par un compte d'opérations).
     * - La distinction entre les deux types de non-résidents
     * 	- Non-résident zone euro : Personnes appartenant à un un Etat membre de la zone de monnaie unique (EMUM),hors-France,
     * 	- Non-résident hors zones euro : Personnes appartenant à un autre pays étranger (non-EMUM).
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codeResident: string;
    /**
     * Code permettant d'identifier l'établissement qui souhaite être pilote ou qui est pilote du Tiers.
     *
     * Valorisation:
     * - __1__ : Je suis pilote, ou je souhaite être pilote
     * - __2__ : Je ne suis pas pilote, ou je ne souhaite pas être pilote
     * - __3__ : Je ne me prononce pas, je n'ai pas d'avis
     * - _blanc_ : N.C.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codePiloteDuTiers: string;
    /**
     * Détermine un type de pièce justifiant d'une activité/situation professionnelle.
     *
     * Exemples:
     * - __00__ : EXEMPLAIRE DES STATUTS CERTIFIE CONFORME
     * - __01__ : EXEMPLAIRE DU JOURNAL OFFICIEL
     * - __02__ : EXTRAIT DE DELIBERATION SIGNE
     * - __03__ : COPIE CERTIFIE CONFORME DU J.O
     * - __04__ : AGREMENT DE L'ASSOCIATION
     * - __05__ : COPIE DE L'ACTE AUTHENTIQUE OU TESTAMENT
     * - __06__ : STATUTS DE LA DELEGATION DEPARTEMENTALE
     * - __07__ : DECRET DE RECONNAISSANCE LEGALE
     * - __08__ : COPIE DES STATUTS CERTIFIEE CONFORME
     * - __09__ : COPIE DE L'EXTRAIT KBIS REG. DU COMMERCE
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codeDeLaPieceJustificativeProfessionnelle: string;
    /**
     * Cette rubrique permet au central de mettre à jour la date de traçage de la rubrique nb de salariés si le nb de salariés est saisi sur le PTU. Elle permet aussi au PTU de ne pas afficher les zéros par défaut.
     *
     * Valorisation:
     * - __O__ : Rubrique nb de salariés renseignée
     * - __N__ : Rubrique nb de salariés non renseignée (zéro par défaut)
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    indicateurDePresenceDuNombreDeSalarie: string;
    /**
     * Désignation longue du lieu d'activité. Elle est utilisée pour l'impression du volet un de l'adresse.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    designationLongueDuLieuActivite: string;
    /**
     * Libellé de désignation de l'enseigne d'un lieu d'activité d'un Professionnel. Signe/marque/appellation apposé sur un établissement commercial le distinguant des autres établissements. Élément incorporel du fonds de commerce, elle désigne :
     * - un nom de personne
     * - un emblème
     * - une dénomination de fantaisie
     *
     * L'enseigne peut ne pas être unique mais commune, ex: Café du Commerce.
     *
     * Désignation longue qui référence le volet un et deux de l'adresse.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    enseigneCommercialeDuLieuActivite: string;
    /**
     * Numéro de télex du lieu activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    numeroDeTelexDuLieuActivite: string;
    /**
     * Numéro de télécopie du lieu d'activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    numeroTelecopieurDuLieuActivite: string;
  }

  export interface ICotation {
    /**
     * Cote d'une entreprise établie à une date donnée. Concerne les entreprises suivies dans la base FIBEN.
     */
    cotation: string;
    /**
     * En retour des traitements FIBEN, contient la date de cotation de la Banque de France, en lien avec la cote Banque de France COMRCT.
     * Type date au format yyyy-MM-dd
     */
    dateDeLaCotation: string;
    /**
     * Cotation précédemment enregistrée pour une entreprise donnée.
     */
    cotationPrecedente: string;
    /**
     * Date de cotation Fiben BDF N-1.
     * Type date au format yyyy-MM-dd
     */
    dateDeLaCotationPrecedente: string;
    /**
     * Détermine la cotation FIBEN d'un dirigeant donné pour une personne morale donnée.
     *
     * Valorisation:
     * - __000__ : Pas de réserve
     * - __040__ : Attention particulière
     * - __050__ : Réserves
     * - __060__ : Réserves sérieuses
     */
    cotationDuDirigeant: string;
    /**
     * Date à laquelle est référencée la dernière mise à jour de la cotation FIBEN du dirigeant.
     * Type date au format yyyy-MM-dd
     */
    dateDeLaCotationDuDirigeant: string;
    /**
     * La cotation FIBEN du dirigeant est attribué au dirigeant d'une personne morale ou de l'activité d'une personne physique.
     *
     * Règles de gestion et types de contrôle : La cotation du dirigeant est saisie et stockée sur l'activité. Aucune application ne l'utilise. Elle est utilisée par des procédures internes caisses.
     *
     * Valorisation:
     * - __0__ : Pas de réserve
     * - __4__ : Attention particulière
     * - __5__ : Réserves
     * - __6__ : Réserves sérieuses
     */
    cotationSimplifieDuDirigeant: string;
    /**
     * Date à laquelle est référencée la dernière mise à jour de la cotation professionnelle.
     * Type date au format yyyy-MM-dd
     */
    dateDeDerniereMiseAJourDeLaCotation: string;
    /**
     * Cette rubrique identifie la date de dernière révision de l'activité professionnelle. Dans le cadre des interfaces ANADEFI --> SIRIS, elle correspond à la date de dernière mise à jour du dossier ANADEFI, même si la cotation n'évolue pas.
     * Type date au format yyyy-MM-dd
     */
    dateDeDerniereRevisionDeLaCotation: string;
    /**
     * Précise la "qualité" d'un professionnel/collectivité.
     *
     * Règles de gestion et types de contrôle : Obligation de côter tout client ouvrant un compte commercial. La cote permet d'établir les fourchettes de taux d'agios ou de frais.
     *
     * Valorisation:
     * - __A__ : Affaire excellente
     * - __B__ : Bonne affaire : rien de défavorable
     * - __C__ : Affaire de qualité moyenne : précautions à prendre
     * - __D__ : Affaire de mauvaise qualité : à surveiller
     * - _blanc_ : Client non encore coté ('*' à l'édition)
     * - __E__ : Contentieux
     */
    codeCotation: string;
  }

  export interface IActiviteProfessionnelle {
    /**
     * Numéro de SIREN du professionnel enregistré dans le SI d'un Établissement du GCE.
     */
    numeroSiren: string;
    /**
     * Identifiant d'un Établissement du RCE. Il correspond au code Banque sous lequel une Caisse ou un établissement du réseau CE est répertoriée par la Banque de France.
     */
    codeEtablissement: string;
    /**
     * Numéro d'identification de la personne dans le SI d'un Etablissement Référence interne MYSYS Perso.
     */
    identifiantTiers: number;
    /**
     * Numéro d'identification de l'activité professionnelle d'une personne dans le SI d'un Établissement du Groupe CE. Numéro chrono attribué par le système. Une personne morale est enregistrée sous une seule activité : valeur 1. Une personne physique peut avoir plusieurs activités en tant que professionnel : enregistrement chrono.
     *
     * Un professionnel est référencé dans le SI d'un Établissement du Groupe CE par :
     * - NODAPE / Numéro de personne
     * - NODAPS / Numéro chrono Prof
     * Constitue une référence unique dans MYSYS.
     */
    numeroChrono: number;
    situationFinanciere: ISituationFinanciere;
    secteurActivite: ISecteurActivite;
    donneAdministrative: IDonneeAdministrative;
    informationJuridique: IInformationJuridique;
    cotation: ICotation;
    listeImmatriculation: Array<IImmatriculation>;
    listeAdresse: Array<IAdresse>;
    listeEtablissement: Array<IEtablissement>;
    /**
     * RUBRIQUE MERE : IKDQST
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    numeroComplementaireSIRET: string;
    /**
     * à partir de la V17.01 seulement
     *
     * Si 'T' : mise à jour complète avec les Immatriculations
     * Si 'I' : mise à jour des Immatriculations seulement
     * Sinon mise à jour de corporateInformation sans les Immatriculations
     */
    codeMajImmatriculation: string;
    /**
     * Indicateur précisant si une personne connue est un prospect : personne n'étant ni client ni tiers et généralement référencée dans le cadre d'une relation d'avant vente (simulation, pré-souscription d'une offre).
     *
     * Valeurs :
     *
     * '1' personne prospect
     * '0' personne non prospect
     */
    indicateurProspect: string;
  }

  export interface IParametreCorporate {
    compteurEnregistrement: number;
    /**
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    referenceExterneDeAgent: number;
    /**
     * Poste fonctionnel en qualité de titulaire, remplaçant, suppléant ou au titre d'une affectation temporaire.
     *
     * Valorisation:
     * - __T__ : Titulaire
     * - __R__ : Remplaçant
     * - __S__ : Suppléant
     * - __A__ : Affectation temporaire
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codeQualiteDeAgentAffecte: string;
    /**
     * Trouver la différence entre les rubriques _ENOCEE1_ et _ENOCEE6_.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    identifiantDeElementDeStructure: number;
    /**
     * Trouver la différence entre les rubriques _ENOCEE1_ et _ENOCEE6_.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    identifiantDeElementDeStructureBis: number;
    /**
     * Indique si la personne est à l'état bloquée dans la table VAO.
     *
     * Valorisation:
     * - __N__ : Non bloqué
     * - __B__ : Bloqué
     * - __D__ : Débloqué
     */
    codeDeBlocageVAO: string;
    /**
     * La rubrique CIDCCB indique si un client bancaire existe pour une activité professionnelle.
     *
     * Valorisation:
     * - __O__ : Existe
     * - __N__ : N'existe pas
     */
    indicateurExistanceDeEntiteTitulaire: string;
  }

  export interface ICorporateActiviteProfessionnelle {
    activitesProfessionnelles: Array<IActiviteProfessionnelle>;
    parametreCorporate: IParametreCorporate;
    listeMessageFonctionnel: Array<IMessageFonctionnel>;
  }

  export interface IImmatriculation {
    /**
     * Identifiant d'un Etablissement du RCE. Correspond au code Banque sous lequel une Caisse ou un Etablissement du réseau CE est répertoriée par la Banque de France.
     */
    codeEtablissement: string;
    /**
     * Numéro d'identification de la personne dans le SI d'un Etablissement bancaire
     */
    identifiantPersonne: number;
    /**
     * Numéro d'identification de l'activité professionnelle d'une personne dans le SI d'un Etablissement du Groupe CE.
     */
    numeroChronoProfesionnel: number;
    /**
     * Détermine un registre officiel en France permettant l'immatriculation de personnes ou la publication d'informations 01 RCS (Registre du commerce et des sociétés) 02 RM (Répertoire des métiers) 03 MSA (Mutualité sociale agricole) 04 Publication journal officiel 05 Préfecture 06 Mairie 07 Ordre des métiers 08 Autres
     */
    codeTypeRegistre: string;
    /**
     * Numéro d'immatriculation à un registre officiel d'un professionnel.
     *
     * Ce numéro peut être notamment :
     * - un numéro RCS
     * - un numéro Registre des métiers
     * - un numéro d'inscription à la préfecture
     * - un numéro d'inscription à la MSA
     * - un ordre des métiers pour les professions libérales
     * - un numéro de publication au JO
     *
     * Le contenu de NODAIM est interprété en fonction de la valeur du code CTDARI qui lui correspond.
     */
    numeroImmatriculationRegistre: string;
    /**
     * Libellé du lieu d'inscription au registre.
     */
    lieuInscriptionRegistre: string;
    /**
     * Date à laquelle une personne est immatriculé en tant que professionnel auprès d'un organisme habilité (ex: chambre de commerce,...).
     * Type date au format yyyy-MM-dd
     */
    dateImmatriculation: string;
  }

  export interface IAdresse {
    /**
     * Numéro d'identification d'une adresse en tant que localisation géographique d'une personne référencée dans Client-Tiers / appli GESTADM.
     */
    identifiantAdresse: number;
    /**
     * Indique le numéro de la voie au fichier des PTT pour les voies francaises répertoriées.
     */
    numeroDeLaVoiePTT: number;
    /**
     * RUBRIQUE MERE : CODGCP. CODIFICATION NON NORMALISEE : UTILISER CODGCP.
     */
    numeroDuCodePostalPTT: string;
    /**
     * Détermine le quartier d'une adresse.
     */
    codeDuQuartier: string;
    /**
     * Numéro de la tournée du facteur. Cette donnée pourra être utilisée à des fins de ciblage marketing de la clientèle.
     */
    numeroDeLaTourneeDuFacteur: number;
    /**
     * Numéro de téléphone associé à une adresse et concernant un particulier ou un lieu d'activité pour un professionnel.
     */
    numeroDeTelephoneAdresse: string;
    /**
     * Identifie un pays ou territoire selon la norme INSEE.
     *
     * Exemples:
     * - __99000__ : France
     * - __99132__ : Grande Bretagne
     * - __99109__ : Allemagne
     * - __99134__ : Espagne
     */
    codeDuPaysINSEE: string;
    /**
     * Identifie une commune / lieu-dit selon la nomenclature INSEE.
     *
     * Format du code INSEE des communes :
     * - numéro minéralogique du département
     * - numéro de code de la commune
     *
     * Format du code pour les lieux-dits (localités n'ayant pas le statut de commune) :
     * - numéro minéralogique du département
     * - numéro de code du lieu-dit
     */
    codeDeLaLocaliteINSEE: string;
    /**
     * Permet de savoir qui est le possesseur de l'adresse.
     *
     * Valorisation:
     * - __1__ : PERSONNE
     * - __2__ : LIEU D'ACTIVITE
     * - __3__ : ENTITE JURIDIQUE (pas géré)
     * - __4__ : ELEMENT DE STRUCTURE (pas géré)
     */
    indicateurDePossessionAdresse: string;
    /**
     * Numéro d'identification du lieu d'activité d'un professionnel dans le SI d'un Établissement du Groupe CE. Implantation d'une activité d'un professionnel. Peut correspondre à un établissement au sens INSEE.
     *
     * Numéro chrono attribué par le système. Identification du lieu :
     * - NODAPE / Numéro de personne
     * - NODAPS / Numéro chrono Prof
     * - NODALS / Numéro chrono Lieu
     *
     * Constitue une référence unique dans MYSYS.
     */
    numeroChronoDuLieuActivite: number;
    /**
     * Détermine la nature/finalité d'une adresse.
     *
     * Valorisation:
     * - __1__ : Adresse légale (domicile), localisation pour un lieu d'activité
     * - __4__ : Adresse communication (correspondance)
     * - __6__ : Adresse spéciale communication
     */
    codeDuTypeAdresse: string;
    /**
     * Code validité de l'adresse. Code initialisé lors du traitement de l'adresse par le logiciel UNICONVERT.
     *
     * Valorisation:
     * - __00__ : Adresse correcte
     * - __XY__ : Adresse forcée avec X : contrôle analyse syntaxique et Y : contrôle analyse géographique (code issu d'une transposition des codes retour UNISERV).
     */
    codeDeValiditeAdresse: string;
    /**
     * Cette rubrique est initialisée lors de la saisie des adresses au PTMS. Elle indique si le téléphone de la personne est en liste rouge ou non.
     *
     * Valorisation:
     * - __0__ : Pas en liste rouge
     * - __1__ : En liste rouge
     */
    indicateurDeTelephoneSurListeRouge: string;
    /**
     * Numéro de fax du particulier ou du lieu d'activité pour un professionnel. Pour un particulier, il s'agit dans la plupart des cas, du numéro de fax du domicile.
     */
    numeroFax: string;
    /**
     * Cette rubrique indique si le client détient un téléphone. Permet d'indiquer que la rubrique numéro de téléphone de l'adresse client n'est pas renseignée parce que le client n'a pas le téléphone.
     *
     * Valorisation:
     * - _blanc_ : Valeur d'initialisation
     * - __1__ : Ne détient pas de téléphone
     */
    indicateurDeDetentionDeTelephone: string;
    /**
     * Cette donnée précise à quoi correspond le téléphone NODATP.
     */
    commentaireTelephone: string;
    /**
     * Indique le numéro de la voie du fichier HEXAVIA pour les voies francaises répertoriées.
     */
    numeroDeVoieHEXAVIA: number;
    /**
     * Code postal pour la France et l'étranger :
     * - Sur 5 caractères pour la France
     * - Sur 9 caractères pour l'étranger : peut être en alphanumérique
     */
    codePostalPourFranceEtEtranger: string;
    /**
     * RUBRIQUE MERE : LIDGCM
     */
    libelleCommune: string;
    /**
     * Libellé de la ligne 2 d'une adresse normée AFNOR. La ligne 2 permet d'indiquer le point de remise ou un complément d'identifiaction du destinataire : N° APP ou BAL-ETAGE-COULOIR-ESC.
     *
     * La ligne 2 correspond à tout ce qui est situé à l'intérieur d'un bâtiment, cela peut être l'indication d'étage, d'appartement, de porte, de numéro de boite aux lettres, etc ...
     */
    ligne2AdresseAFNOR: string;
    /**
     * Libellé de la ligne 3 d'une adresse normée AFNOR. La ligne 3 permet d'indiquer le point de remise (informations complémentaires de distribution) : ENTREE-BATIMENT-IMMEUBLE-RESIDENCE.
     *
     * La ligne 3 correspond à tout ce qui est à l'extérieur du batiment. entrée, batiment, bloc, tour etc ...
     */
    ligne3AdresseAFNOR: string;
    /**
     * Libellé de la ligne 4 d'une adresse normée AFNOR. La ligne 4 permet d'identifier la voie de destination NUMERO-LIBELLE DE LA VOIE. Peut comprendre :
     * - Le numéro dans la voie, type et nom de voie
     * - Le nom d'une résidence ou d'un ensemble immobilier qui ne peut être assimilé à une commune ou à un lieu-dit
     * - Un service X
     * - Une boîte postale
     * - Un numéro de CEDEX
     */
    ligne4AdresseAFNOR: string;
    /**
     * Libellé de la ligne 5 d'une adresse normée AFNOR. La ligne 5 permet d'identifier la destination : LIEU DIT ou SERVICE PARTICULIER DE DISTRIBUTION. Peut comprendre :
     * - Nom d'un quartier, d'un lieu dit, d'un hameau
     * - Nom d'un ensemble immobilier pouvant être assimilé à une commune ou à un lieu dit et possédant plusieurs voies internes.
     */
    ligne5AdresseAFNOR: string;
    /**
     * Libellé de la ligne 6 d'une adresse normée AFNOR. La ligne 6 permet d'identifier la destination : CODE POSTAL et LOCALITE DE DESTINATION ou CODE CEDEX et LIBELLE CEDEX. Peut comprendre :
     * - Le numéro de code postal et nom de la localite
     * - Le numéro de code spécifique et nom de la localité complétés éventuellement par la mention CEDEX
     */
    ligne6AdresseAFNOR: string;
    /**
     * le code iso du pays
     */
    codeISOPays: string;
    /**
     * le libelle du pays
     */
    libelleISOPays: string;
    /**
     * indicatif du téléphone :
     *  - +33 pour la france
     * - + 32 pour la belgique
     */
    indicatifTelephone: string;
    /**
     * indicatif du téléphone du fax :
     *  - +33 pour la france
     * - + 32 pour la belgique
     */
    indicatifTelephoneFax: string;
    /**
     * Code Type Retour PTT.
     */
    codeTypeRetourPTT: string;
    /**
     * Nombre de Retour PTT.
     */
    nombreRetourPTT: number;
    /**
     * Date de Dernier Retour PTT.
     * Type date au format yyyy-MM-dd
     */
    dateDernierRetourPTT: string;
    /**
     * Indicateur confirmation ou non de l’adresse.
     * Valeurs : O/N.
     */
    indicateurConfirmeAdresse: string;
  }

  export interface IEtablissement {
    /**
     * Numéro de télex du lieu activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    numeroDeTelexDuLieuActivite: string;
    /**
     * Numéro de télécopie du lieu d'activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    numeroTelecopieurDuLieuActivite: string;
    /**
     * Désignation longue du lieu d'activité. Elle est utilisée pour l'impression du volet un de l'adresse.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    designationLongueDuLieuActivite: string;
    /**
     * Libellé de désignation de l'enseigne d'un lieu d'activité d'un Professionnel. Signe/marque/appellation apposé sur un établissement commercial le distinguant des autres établissements. Élément incorporel du fonds de commerce, elle désigne :
     * - un nom de personne
     * - un emblème
     * - une dénomination de fantaisie
     *
     * L'enseigne peut ne pas être unique mais commune, ex: Café du Commerce.
     *
     * Désignation longue qui référence le volet un et deux de l'adresse.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    enseigneCommercialeDuLieuActivite: string;
    /**
     * RUBRIQUE MERE : IKDQST
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    numeroComplementaireSIRET: string;
    /**
     * Date de début d'exploitation du lieu d'activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     * Type date au format yyyy-MM-dd
     */
    dateDeDebutExploitationDuLieu: string;
    /**
     * Date de fin d'exploitation du lieu d'activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     * Type date au format yyyy-MM-dd
     */
    dateDeFinExploitationDuLieu: string;
    /**
     * Libellé libre qui précise le code APE du lieu d'activité.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    activiteEconomiqueReelleDuLieu: string;
    /**
     * Détermine une famille d'activités des personnes selon l'INSEE.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codeDeLaFamilleNAF: string;
    /**
     * Détermine une activité au sein d'une famille d'activités selon l'INSEE.
     *
     * __Remarque__: Ce champs est utilisé uniquement lors de la __création__ d'une activité professionnelle.
     */
    codeNAF3DerniersCaracteres: string;
    /**
     * Détermine le statut du lieu d'activité d'un professionnel.
     * Permet de déterminer le siège
     *
     * Valeurs :
     *
     * - '1'        Etablissement siège
     * - '2'        Etablissement secondaire
     */
    codeStatut: string;
    listeAdresse: Array<IAdresse>;
    /**
     * Numéro d'identification du lieu d'activité d'un professionnel dans le SI d'un Établissement du Groupe CE. Implantation d'une activité d'un professionnel. Peut correspondre à un établissement au sens INSEE.
     *
     * Numéro chrono attribué par le système. Identification du lieu :
     * - NODAPE / Numéro de personne
     * - NODAPS / Numéro chrono Prof
     * - NODALS / Numéro chrono Lieu
     *
     * Constitue une référence unique dans MYSYS.
     */
    numeroChronoDuLieuActivite: number;
    /**
     * Code associé à la branche d'activité.
     * Codification pour l'ensemble des caisses.
     * Donnée relative aux personnes morales et entrepreneurs individuels, basée sur une approche commerciale ou sectorielle, permettant de paramétrer des      regroupements fonctionnels de codes NAF.
     * Format XX9999
     */
    brancheActivite: string;
  }

  export interface IMessageFonctionnel {
    /**
     * Avec le code Domaine, ce code Message Erreur compose l'identifiant réduit pour le poste PETRA d'un Message d'erreur. Valeurs : La composition de ce code se déduit de l'identifiant complet d'un Message d'Erreur en reprenant :
     *
     * la partie utile du code entité (sur 4 car.) . pour une entité programme ou dialogue, cela correspond aux 4 derniers caractères du code sachant que les 2 premiers sont connus dans le code bibliothèque (première composante de la clé) . pour un segment, elle correspond aux 4 carac. codifiant le segment. le rang de la rubrique (sur 3 car.) le type de l'erreur (sur 1 car.)
     */
    code: string;
    /**
     * Libellé de description d'une anomalie / erreur associé à un code erreur. Correspond à une erreur de traitement, de contenu de données reçues via un interface (écran de saisie, PTMS, autre Q/R, fichier séquentiel, ...).
     */
    libelle: string;
  }
}
