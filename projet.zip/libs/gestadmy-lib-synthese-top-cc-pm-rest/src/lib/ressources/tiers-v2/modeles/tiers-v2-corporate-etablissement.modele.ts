/* tslint:disable:max-line-length */
export namespace RessourceTiersV2CorporateEtablissement {
  export interface ICorporateEtablissement {
    gestionSuite: IGestionSuite;
    listeMessageFonctionnel: Array<IMessageFonctionnel>;
    listeEtablissement: Array<IEtablissement>;
  }

  export interface IAdresse {
    /**
     * ####Identifiant adresse
     * ---
     *
     * **Définition : **
     * Numéro d'identification d'une adresse en tant que localisation géographique d'une personne référencée dans Client-Tiers.
     *
     * **Concerne les adresses : **
     * - des Particuliers
     * - des lieux d'activité des Professionnels
     *
     * Enregistrement de l'adresse au format 38
     */
    identifiant: number;
    /**
     * ####Code type adresse
     * ---
     *
     * **Définition : **
     * Détermine la nature/finalité d'une adresse
     *
     * **Valeurs : **
     * '1' adresse légale (domicile) localisation pour un lieu d'activité
     * '4' adresse communication (correspondance)
     * '6' adresse spéciale communication
     */
    codeType: string;
    /**
     * Libellé du code type adresse
     */
    libelleType: string;
    /**
     * Libellé de la ligne 2 d'une adresse normée AFNOR.
     * La ligne 2 permet d'indiquer le point de remise ou un complément d'identification du destinataire.
     * La ligne 2 correspond à tout ce qui est situé à l'intérieur d'un bâtiment, cela peut être l'indication d'étage, d'appartement, de porte, de numéro de boite aux lettres, etc.
     */
    ligne2AFNOR: string;
    /**
     * Libellé de la ligne 3 d'une adresse normée AFNOR.
     * La ligne 3 permet d'indiquer le point de remise (informations complémentaires de distribution).
     * La ligne 3 correspond à tout ce qui est à l'extérieur
     * du bâtiment (entrée, bâtiment, bloc, tour etc.)
     */
    ligne3AFNOR: string;
    /**
     * Libellé de la ligne 4 d'une adresse normée AFNOR.
     * La ligne 4 permet d'identifier la voie de destination.
     * Peut comprendre, le numéro dans la voie, type et nom de voie, le nom d'une résidence ou d'un ensemble immobilier qui ne peut être assimilé à une commune ou à un lieu-dit, un service X, une boîte postale ou un numéro de CEDEX.
     */
    ligne4AFNOR: string;
    /**
     * Libellé de la ligne 5 d'une adresse normée AFNOR.
     * La ligne 5 permet d'identifier la destination.
     * Peut comprendre, le nom d'un quartier, d'un lieu-dit, d'un hameau, le nom d'un ensemble immobilier pouvant être assimilé à une commune ou à un lieu-dit et possédant plusieurs  voies internes.
     */
    ligne5AFNOR: string;
    /**
     * Libellé de la ligne 6 d'une adresse normée AFNOR.
     * La ligne 6 permet d'identifier la destination.
     * Peut comprendre, le numéro de code postal et nom de la localité, le numéro de code spécifique et nom de la localité complétés éventuellement par la mention CEDEX.
     */
    ligne6AFNOR: string;
    /**
     * Identifie le bureau distributeur du courrier.
     * Permet de préciser le bureau qui assure la distribution du courrier.
     */
    codePostalPTT: string;
    /**
     * Identifie un pays ou territoire selon la norme INSEE.
     */
    codeInseePays: string;
    /**
     * Identifie un pays ou un territoire selon la nomenclature ISO 3166-1 sur 2 caractères.
     */
    codeISOPays: string;
    /**
     * Libellé de désignation en français du pays selon
     * la norme ISO 3166-1.
     */
    libelleISOPays: string;
    /**
     * Identifie une commune / lieu-dit selon la nomenclature INSEE.
     */
    codeInseeLocalite: string;
    /**
     * Désignation conforme au code géographique INSEE.
     */
    libelleInseeLocalite: string;
    /**
     * Code Type Retour PTT.
     */
    codeTypeRetourPTT: string;
    /**
     * Nombre de Retour PTT .
     */
    nombreRetourPTT: number;
    /**
     * Date de Dernier Retour PTT.
     * Type date au format yyyy-MM-dd
     */
    dateDernierRetourPTT: string;
    /**
     * Indicateur confirmation ou non de l’adresse.
     * Valeurs : O/N.
     */
    indicateurConfirmeAdresse: string;
  }

  export interface IMessageFonctionnel {
    /**
     * Avec le code Domaine, ce code Message Erreur compose l'identifiant réduit pour le poste PETRA d'un Message d'erreur. Valeurs : La composition de ce code se déduit de l'identifiant complet d'un Message d'Erreur en reprenant :
     *
     * la partie utile du code entité (sur 4 car.) . pour une entité programme ou dialogue, cela correspond aux 4 derniers caractères du code sachant que les 2 premiers sont connus dans le code bibliothèque (première composante de la clé) . pour un segment, elle correspond aux 4 carac. codifiant le segment. le rang de la rubrique (sur 3 car.) le type de l'erreur (sur 1 car.)
     */
    code: string;
    /**
     * Libellé de description d'une anomalie / erreur associé à un code erreur. Correspond à une erreur de traitement, de contenu de données reçues via un interface (écran de saisie, PTMS, autre Q/R, fichier séquentiel, ...).
     */
    libelle: string;
  }

  export interface IGestionSuite {
    /**
     * Ce code indique s'il existe ou non une suite pour l'information listée.
     * Permet de gérer les pages d'une liste de données
     */
    indicateurListeSuivre: string;
    /**
     * Ensemble de données constituant le contexte pour repositionnement dans une QR de type liste, lors d'une suite.
     * Permet de stocker les rubriques nécessaires au repositionnement
     */
    contexteRepositionnementListe: string;
  }

  export interface IEtablissement {
    /**
     * Libellé libre du lieu d'activité.
     */
    designationCourteLieuActivite: string;
    /**
     * Numéro télécopieur du lieu activité
     */
    numeroTelecopieurLieuActivite: string;
    /**
     * Ordre de grandeur du nombre de salariés du lieu d'activité.
     */
    effectifDuLieuActivite: number;
    /**
     * Libellé de désignation de l'enseigne d'un lieu d'activité d'un Professionnel.
     * Signe / marque / appellation apposé sur un établissement commercial le distinguant des autres établissements.
     * Élément incorporel du fonds de commerce,
     * Elle désigne :
     *  - un nom de personne
     *  - un emblème
     *  - une dénomination de fantaisie
     * L'enseigne peut ne pas être unique mais commune
     * ex : Café du Commerce.
     */
    enseigneCommercialeLieuActivit: string;
    /**
     * Désignation longue du lieu activité.
     * Elle est utilisée pour l'impression du volet un de l'adresse.
     * Elle correspond :
     *  - aux nom et prénom pour la personne physique
     *  - à la raison sociale pour la personne morale.
     */
    designationLongueLieuActivite: string;
    /**
     * Numéro d'identification d'une entreprise francaise répertoriée dans le fichier SIRENE de l'INSEE :
     * Système d'Identification du Répertoire des ENtreprises
     * Identifie de manière unique une entreprise au niveau national.
     * Attribué une seule fois, n'est supprimé du répertoire qu'au moment de la disparition de la personne juridique (décès ou cessation de toute activité pour une personne physique, dissolution pour une personne morale).
     * Un professionnel n'a pas forcément de SIREN, cas des professionnels n'ayant pas d'activité commerciale et/ou n'ayant pas de salariés.
     * Pour les entreprises étrangères résidant en France :
     * SIREN fictif attribué par le Banque De France dans le cadre de l'identification FIBEN (commence par 200).
     * En cas de non attribution par l'INSEE :
     * (hors périmètre SIRENE ou inscription en instance).
     */
    numeroSIRENProfessionnel: string;
    /**
     * Numéro interne de classement attribué à un établissement appartenant à une entreprise par l'INSEE.
     * Identifie un établissement au sein d'une entreprise répertoriée à l'INSEE.
     * Complète le SIREN pour constituer le SIRET.
     */
    numeroComplementSIRETEtabli: string;
    /**
     * Famille de code activité exercée par le professionnel.
     * Valeur :
     * 01 Agriculture
     * 03 Pêche
     * 16 Industrie du verre
     */
    codeFamilleAPEINSEE: string;
    /**
     * Cette rubrique permet de définir les deux derniers caractères du code APE.
     */
    deuxDerniersCaracteresAPE: string;
    /**
     * Résidents :
     *  - Personnes physiques ayant leur principal centre d'intérêt en FRANCE
     *  - Fonctionnaires et autres agents publics français en poste à l'étranger
     *  - Personnes morales françaises ou étrangères pour leur établissement en FRANCE
     * La France est définie comme suit :
     *  - France métropolitaine (avec la principauté de MONACO )
     *  - DOM (avec Saint-Pierre et Miquelon))
     *  - TOM (avec Mayotte)..
     *
     * Non résidents :
     *  - Personnes physiques ayant leur principal centre d'intérêt à l'étranger
     *  - Fonctionnaires et autres agents publics étrangers en poste en FRANCE
     *
     * L'étranger est défini comme suite :
     *  - Pays autre que la France (y compris les Etats dont l'Institut d'Emission est lié au Trésor Français par un compte d'opérations).
     *  - La distinction entre les deux types de non-résidents
     *  - Non-résident zone euro :
     *
     * Personnes appartenant à un un Etat membre de la zone de monnaie unique (EMUM),hors-France,
     *  - Non-résident hors zones euro :
     *
     * Personnes appartenant à un autre pays étranger (non-EMUM).
     *
     * Valeurs:
     * ---
     * | Valeur | Libellé |
     * |---|---|
     * | '1' | Résident |
     * | '2' | Non Résident |
     */
    codeResident: string;
    /**
     * Cette rubrique permet de définir les deux premiers caractères du code NAF qui correspond à la famille de code activité exercée par le professionnel.
     */
    codeFamilleNAFINSEE: string;
    /**
     * Cette rubrique permet de définir les trois derniers caractères du code NAF.
     */
    troisDerniersCaracteresNAF: string;
    /**
     * Code client tiers
     */
    codeClientTiers: string;
    /**
     * Activité économique réelle lieu.
     * Libellé libre qui précise le code APE du lieu d'activité.
     */
    activiteEconomiqueReelleLieu: string;
    /**
     * Libelle d'un établissement lié à un code établissement.
     */
    libelleEtablissement: string;
    /**
     * Identifiant d'un Etablissement du RCE.
     * Correspond au code Banque sous lequel une Caisse ou un Etablissement du réseau CE est répertoriée par la Banque de France.
     */
    codeEtablissement: string;
    /**
     * Numéro d'identification du tiers dans le SI d'un Etablissement Référence interne MYSYS Personne référencée comme client, tiers ou prospect.
     * Numéro chronologique attribué par le système.
     * Référence unique dans MYSYS (identifiant interne).
     */
    identifiantTiers: number;
    /**
     * Date de début d'exploitation de l'établissement.
     * Type date au format yyyy-MM-dd
     */
    dateDebutExploitationLieuActivite: string;
    /**
     * Date de fin d'exploitation du lieu d'activité.
     * Type date au format yyyy-MM-dd
     */
    dateFinExploitationLieuActivite: string;
    /**
     * Numéro d'identification du lieu d'activité d'un professionnel dans le SI d'un Etablissement du Groupe CE.
     * Numéro chrono attribué par le système.
     * Implantation d'une activité d'un professionnel.
     * Peut correspondre à un établissement au sens INSEE.
     */
    numeroLieuActivite: number;
    /**
     * Numéro d'identification de l'activité professionnelle d'une personne dans le SI d'un Etablissement du Groupe CE.
     * Numéro chrono attribué par le système.
     * Une personne morale est enregistrée sous une seule activité : valeur 1.
     * Une personne physique peut avoir plusieurs activités en tant que professionnel : enregistrement chrono.
     */
    numeroProfessionnel: number;
    /**
     * Numéro telex du lieu activité
     */
    numeroTelexLieuActivite: string;
    listeAdresse: Array<IAdresse>;
  }
}
