export namespace RessourceClasseurclientV1Recherche {
  export interface IPorteur {
    /**
     * CodeType
     */
    typePorteur: string;
    /**
     * Idnt
     */
    idPorteur: string;
  }

  export interface IDossier {
    /**
     * CodeApp
     */
    codeApp: string;
    /**
     * IdntDoss
     */
    idDossier: string;
    /**
     * LiblDossAcqs
     */
    libelleDossier: string;
    /**
     * LiblMotf
     */
    libelleMotif: string;
    /**
     * CodeEvnmMetr
     */
    codeEvenementMetier: string;
    /**
     * IndicComp
     */
    indicateurCompletude: string;
    /**
     * DateCrtn
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateCreation: string;
    /**
     * DateModf
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateModification: string;
    /**
     * CodeTypeDoss
     */
    typeDossier: string;
    /**
     * Port
     */
    porteur: IPorteur;
    /**
     * RefrCtxt
     */
    referenceContexte: string;
    /**
     * IndicCrsAcqs
     */
    indicateurEnCoursAcquisition: boolean;
    /**
     * codeReferenceExterne
     */
    codeReferenceExterne: string;
  }

  export interface IRechercherDossierOutput {
    /**
     * ListDoss
     */
    dossiers: Array<IDossier>;
  }

  export interface IRechercherPieceValideDRCOutput {
    documents: Array<IDocument>;
  }

  export interface IDocument {
    idDocument: string;
    typeDocument: string;
    codeNature: string;
    idPersonne: string;
  }

  export interface ITypeDocument {
    /**
     * IndicDocVald
     */
    indicDocVald: boolean;
    /**
     * Code
     */
    code: string;
    /**
     * Libl
     */
    libl: string;
  }

  export interface IDocumentArchive {
    /**
     * IndicElgb
     */
    indicElgb: string;
    /**
     * CodeModf
     */
    codeModf: string;
    /**
     * DateFinUtls
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateFinUtls: string;
    /**
     * DateFinVald
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateFinVald: string;
    /**
     * DateDebuVald
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateDebuVald: string;
    /**
     * UtilModf
     */
    utilModf: string;
    /**
     * DateModf
     */
    dateModf: string;
    /**
     * UtilCrtn
     */
    utilCrtn: string;
    /**
     * DateCrtn
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateCrtn: string;
    /**
     * CodeTypeAttrb
     */
    codeTypeAttrb: string;
    /**
     * IdntAttrb
     */
    idntAttrb: string;
    /**
     * NumrOrdr
     */
    numrOrdr: number;
    /**
     * CodeNatr
     */
    codeNatr: string;
    /**
     * DateNumr
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateNumr: string;
    /**
     * DateEmss
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateEmss: string;
    /**
     * IdntDoc
     */
    idntDoc: string;
    /**
     * CodeTypeDoc
     */
    codeTypeDoc: string;
    /**
     * CodeNumr
     */
    codeNumr: string;
    /**
     * CodeEtatAlerte
     */
    codeEtatAlerte: string;
    /**
     * CodeEtatLeveeAlerte
     */
    codeEtatLeveeAlerte: string;
    /**
     * IdntAlerte
     */
    idntAlerte: number;
  }

  export interface ITypeDocumentEligible {
    /**
     * liste de string LiblMotfElgb
     */
    listLiblMotfElgb: Array<string>;
    listTypeDoc: Array<ITypeDocument>;
  }

  export interface IDetailDossier {
    listDocArch: Array<IDocumentArchive>;
    listTypeDocCompl: Array<ITypeDocument>;
    /**
     * CodeAppli
     */
    codeAppli: string;
    /**
     * CodeRefrExtn
     */
    codeRefrExtn: string;
    /**
     * CodeExtnEds
     */
    codeExtnEds: string;
    /**
     * UtilModf
     */
    utilModf: string;
    motfObgt: ITypeDocumentEligible;
    /**
     * MotfFacl
     */
    motfFacl: ITypeDocumentEligible;
    /**
     * UtilCrtn
     */
    utilCrtn: string;
    /**
     * IndicReut
     */
    indicReut: boolean;
    /**
     * liste CodeTypePort
     */
    listCodeTypePort: Array<string>;
    /**
     * utilArch
     */
    utilArch: string;
    /**
     * CodeAppliArch
     */
    codeAppliArch: string;
    /**
     * CodeIndicDossPurge
     */
    codeIndicDossPurge: string;
    /**
     * CodeExtnEdsOprn
     */
    codeExtnEdsOprn: string;
    /**
     * DateArchiv
     * Type date au format yyyy-MM-dd
     */
    dateArchiv: string;
    /**
     * IndDossArch
     */
    indDossArch: string;
    /**
     * codeApp
     */
    codeApp: string;
    /**
     * idDossier
     */
    idDossier: string;
    /**
     * libelleDossier
     */
    libelleDossier: string;
    /**
     * libelleMotif
     */
    libelleMotif: string;
    /**
     * codeEvenementMetier
     */
    codeEvenementMetier: string;
    /**
     * indicateurCompletude
     */
    indicateurCompletude: string;
    /**
     * dateCreation
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateCreation: string;
    /**
     * dateModification
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateModification: string;
    /**
     * typeDossier
     */
    typeDossier: string;
    porteur: IPorteur;
    /**
     * referenceContexte
     */
    referenceContexte: string;
    /**
     * indicateurEnCoursAcquisition
     */
    indicateurEnCoursAcquisition: boolean;
    /**
     * codeReferenceExterne
     */
    codeReferenceExterne: string;
  }

  export interface IReferenceExterne {
    /**
     * identifiant de la reference externe
     */
    identifiantReferenceExterne: string;
    /**
     * type de la reference externe
     */
    typeReferenceExterne: string;
  }

  export interface IRechercherDossierReferenceExterne {
    listeDossier: Array<IDossier>;
  }

  export interface IPorteurDossier {
    /**
     * Identifiant du porteur du dossier. (ex: id personne ou ref contrat, etc)
     */
    identifiantPorteur: string;
    /**
     * Type porteur : 1 pour un contrat, 2 pour une personne, etc
     */
    typePorteur: string;
  }

  export interface IDossierPorteur extends IDossier {
    /**
     * Libellé du dossier à afficher.
     */
    libelleAffichage: string;
    /**
     * EXT pour une reference externe
     */
    codeTypeAffichage: string;
    referenceExterne: Array<IReferenceExterneDossier>;
  }

  export interface IReferenceExterneDossier extends IReferenceExterne {
    /**
     * Libellé de la reference externe
     */
    libelleReferenceExterne: string;
  }

  export interface IRechercheDossierPorteur {
    listePorteur: Array<IPorteurDossier>;
    /**
     * Liste des references contexte
     */
    listeReferenceContexte: Array<string>;
    /**
     * Type du dossier CC sur lequel porte la recherche
     */
    typeDossierCC: string;
    /**
     * Evenement Metier
     */
    evenementMetier: string;
  }

  export interface IRecherchePanier {
    recherchePanierIn: IRecherchePanierIn;
    recherchePanierOut: IRecherchePanierOut;
  }

  export interface IRecherchePanierIn {
    /**
     * Date de début de la période de recherche. Le critère vérifie que la date de création est postérieur ou égale à la date saisie.
     * Type date au format yyyy-MM-dd
     */
    dateDebut: string;
    /**
     * Date de fin de la période de recherche. Le critère vérifie que la date de création du dossier est antérieur ou égale à cette date.
     * Type date au format yyyy-MM-dd
     */
    dateFin: string;
    /**
     * Utilisateur ayant créé le dossier.
     */
    utilisateurCreation: string;
  }

  export interface IRecherchePanierOut {
    listeDossiers: Array<IDossierPorteur>;
  }

  export interface IRecupererEvenementsCollecteManuelleOutput {
    listeCategoriesEvenemmentMetier: Array<ICategorieEvenementMetier>;
    listeEvenements: Array<IEvenement>;
    listeContratsClos: Array<string>;
  }

  export interface ICategorieEvenementMetier {
    code: string;
    libelle: string;
  }

  export interface IEvenement {
    codeEvenement: string;
    libelleEvenement: string;
    codeCategorie: string;
    codeTypeCollecte: string;
    codeTypeAcquisition: string;
    indicateurSaisieLibre: boolean;
    saisieLibreType: string;
    saisieLibreLongueur: number;
    indicateurUnicite: boolean;
    categorieEvenementMetier: ICategorieEvenementMetier;
    niveauEvenementMetier: INiveauEvenementMetier;
    usageEvenementMetier: IUsageEvenementMetier;
    libelleSousFamille: string;
    libelleObjectActeGestion: string;
    identifiantProduitService: number;
    codeTypeProduitService: string;
    codeFamilleGestionProduit: string;
    codeTypeDosiers: string;
    codeNatureGed: string;
    indicateurModeNumerisation: string;
  }

  export interface INiveauEvenementMetier {
    code: string;
    libelle: string;
  }

  export interface IUsageEvenementMetier {
    code: string;
    libelle: string;
  }

  export interface IRechercheParEds {
    /**
     * critères de la recherche
     */
    rechercheIn: IRechercheParEdsIn;
    /**
     * Résultats de la recherche
     */
    rechercheOut: IRechercheParEdsOut;
  }

  export interface IRechercheParEdsOut {
    listeDossiers: Array<IDossierPorteur>;
  }

  export interface IRechercheParEdsIn {
    /**
     * Filtre les dossier par période de création. Ne retient que les dossiers postérieurs à la date de ce paramètre: CCLI_DOSS.DATE_CRTN
     * Type date au format yyyy-MM-dd
     */
    dateDebutCreation: string;
    /**
     * Filtre les dossier par période de création. Ne retient que les dossiers antérieurs à la date de ce paramètre: CCLI_DOSS.DATE_CRTN
     * Type date au format yyyy-MM-dd
     */
    dateFinCreation: string;
    /**
     * Filtre les dossier par période de dernière modification. Ne retient que les dossiers postérieurs à la date de ce paramètre: CCLI_DOSS.DATE_MODF
     * Type date au format yyyy-MM-dd
     */
    dateDebutModification: string;
    /**
     * Filtre les dossier par période de dernière modification. Ne retient que les dossiers antérieurs à la date de ce paramètre: CCLI_DOSS.DATE_MODF
     * Type date au format yyyy-MM-dd
     */
    dateFinModification: string;
    /**
     * Filtre les dossiers par code identifiant utilisateur ayant créé le dossier. (colonne CCLI_DOSS.IDNT_UTIL_CRTN)
     */
    utilisateurCreation: string;
    /**
     * Filtre les dossiers par code identifiant utilisateur ayant modifier le dossier en dernier. (colonne CCLI_DOSS.IDNT_UTIL_MODF)
     */
    utilisateurModification: string;
    /**
     * Filtre par code Element de structure de l'opérant : (CCLI_DOSS.CODE_EXTN_EDS_OPRN)
     */
    codeEdsOprn: string;
    /**
     * Filtre les dossiers par type dossier : ex : DRC pour les dossiers DRC. (Filtre colonne: CCLI_DOSS.CODE_TYPE_DOSS)
     */
    codeTypeDossier: string;
    /**
     * Filtre les dossier par l'indicateur complétude : I pour incomplet ou C pour complet. (filtre sur la colonne CCLI_DOSS.CODE_COMP)
     */
    indicateurCompletude: string;
  }
}
