/* tslint:disable:max-line-length */
export namespace RessourceClasseurclientV1DossierReglementaireClient {
  export interface Motif {
    /**
     * Code motif éligibilité dossier
     */
    codeEligibiliteDossier: string;

    /**
     * Libellé motif éligibilité
     */
    libelle: string;

    /**
     * Code motif obligatoire / facultatif
     */
    code: string;
  }
  export interface Dossier {
    /**
     * N° de dossier CRDU
     */
    numeroCRDU: string;

    /**
     * Code Retour Echanges
     */
    codeRetourEchanges: number;

    /**
     * Type de porteur du dossier
     */
    typePorteur: string;

    /**
     * Porteur du dossier (Numéro de personne dans notre cas car c'est un DRC)
     */
    porteur: string;

    /**
     * Numéro chrono du professionnel
     */
    numeroChronoProfessionnel: number;

    motifs: Motif[];
  }
  export interface Client {
    codeEtablissement: string;

    numeroOrdreDossier: number;

    porteur: string;

    typePorteur: string;

    numeroChronoProfessionnel: number;

    raisonSocial: string;

    nomPatronymique: string;

    nomMarital: string;

    prenom: string;

    codeEligibiliteMotif: string;

    codeMotif: string;

    libelleMotif: string;
  }
  export interface DonneesEntree {
    /**
     * code de l'établissement
     */
    codeEtablissement: string;

    /**
     * Identifiant personne
     */
    identifiantPersonne: number;

    /**
     * Numéro Entité Titulaire
     */
    numeroEntiteTitulaire: number;

    /**
     * type DRC
     */
    typeDossierReglementaireClient: string;

    /**
     * Acte de Gestion CRDU
     */
    acteGestion?: string;

    /**
     * Identifiant Element de Structure
     */
    identifiantElementStructure: number;

    /**
     * Type Element de Structure
     */
    typeElementStructure: string;

    /**
     * Référence Externe de l'EDS
     */
    referenceExterneEDS: number;

    /**
     * Code catégorie juridique INSEE
     */
    codeINSEE: string;

    /**
     * Code type Capacite Juridique
     */
    codeCapaciteJuridique: string;

    /**
     * Indicateur présence du Client Bancaire
     */
    indicateurClientBancaire: boolean;

    /**
     * Mode Force à O ou N
     */
    modeForce: string;

    /**
     * personnesLiees à O ou N
     */
    personnesLiees: string;

    /**
     * AspirationAuto à O ou N
     */
    aspirationAuto: string;
  }
  export interface CompletudeResponse {
    /**
     * S97U - liste des LBDYJU correspondant aux pièces manquantes
     */
    piecesManquantes: string[];

    /**
     * S97U - liste des LBDYJU correspondant aux pièces en alerte
     */
    piecesEnAlerte: PieceEnAlerte[];

    /**
     * CIDYCC
     */
    etatCompletude: string;

    /**
     * QCDSJU
     */
    nombrePiecesConcernees: number;
  }
  export interface PieceManquante {
    /**
     * LBDYJU
     */
    libelleTypeJustificatif: string;
  }
  export interface PieceEnAlerte {
    /**
     * Libellé du type de justificatif
     */
    libelleTypeJustificatif: string;

    /**
     * Code type de justificatif
     */
    typeJustificatif: string;
  }
  export interface QstnDRCMiseAJour {
    /**
     * CodeEtablissement
     */
    codeEtablissement: string;

    /**
     * TypeDRC
     */
    typeDRC: string;

    /**
     * AppOrigine
     */
    appOrigine: string;

    /**
     * RefExtEDS
     */
    referenceExterieurEDS: string;

    /**
     * IdentifiantEDS
     */
    identifiantEDS: string;

    /**
     * TypeEDS
     */
    typeEDS: string;

    /**
     * CodeCatJuridique
     */
    codeCatJuridique: string;

    /**
     * TypeCapJuridique
     */
    typeCapJuridique: string;

    /**
     * IndicateurPresenceCB
     */
    indicateurPresenceCB: string;

    /**
     * AspirationAuto
     */
    aspirationAutomatique: string;

    /**
     * PersonnesLiees
     */
    personnesLiees: string;

    /**
     * ModeForce
     */
    modeForce: string;

    /**
     * CodeActe
     */
    codeActe: string;

    /**
     * Nodiet
     */
    nodiet: number;

    /**
     * Nodape
     */
    nodape: number;
  }
  export interface DRCMiseAJourInput {
    listedeDrcMiseAJour: QstnDRCMiseAJour[];
  }
  export interface DRCMiseAJourOutput {
    /**
     * Coderetour
     */
    codeRetour: number;

    listeDrcRetour: DrcRetour[];
  }
  export interface DrcRetour {
    /**
     * CodeDossier
     */
    codeDossier: string;

    /**
     * CodeTypeDossier
     */
    codeTypeDossier: string;

    /**
     * CodeTypePort
     */
    codeTypePort: string;

    /**
     * IdntPorteur
     */
    idntPorteur: string;

    /**
     * CodeRefExt
     */
    codeRefExt: string;

    /**
     * CompDrc
     */
    compDrc: string;

    listeMotifs: MotifEligibilite;
  }
  export interface MotifEligibilite {
    /**
     * IdntMotf
     */
    idntMotf: string;

    /**
     * LiblMotf
     */
    liblMotf: string;

    /**
     * IndicTypeMotf : O or N
     */
    indicTypeMotf: string;
  }
}
