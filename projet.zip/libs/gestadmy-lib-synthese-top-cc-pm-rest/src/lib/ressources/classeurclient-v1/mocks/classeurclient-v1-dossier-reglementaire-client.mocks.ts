import { RessourceClasseurclientV1DossierReglementaireClient } from '../modeles/classeurclient-v1-dossier-reglementaire-client.modele';

export namespace RessourceMockClasseurclientV1DossierReglementaireClient {
  export const infoDRCIncompletMock: RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse = {
    etatCompletude: 'I',
    nombrePiecesConcernees: 5,
    piecesEnAlerte: [],
    piecesManquantes: [
      'STATUTS CERTIFIES CONFORMES',
      'EXISTENCE JURIDIQUE PERS MORALE',
      'IDENT. REPRESENTANTS LEGAUX PP',
      'NOMINATIONS ET POUVOIRS',
      'ACTIVITE ECONOMIQUE PERS MORALE'
    ]
  };

  export const infoDRCCompletMock: RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse = {
    etatCompletude: 'C',
    nombrePiecesConcernees: undefined,
    piecesEnAlerte: [],
    piecesManquantes: []
  };

  export const infoDRCAlerteMock: RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse = {
    etatCompletude: 'A',
    nombrePiecesConcernees: undefined,
    piecesEnAlerte: [],
    piecesManquantes: []
  };

  export const infoDRCVideMock: RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse = {
    etatCompletude: 'TEST',
    nombrePiecesConcernees: undefined,
    piecesEnAlerte: [],
    piecesManquantes: []
  };
}
