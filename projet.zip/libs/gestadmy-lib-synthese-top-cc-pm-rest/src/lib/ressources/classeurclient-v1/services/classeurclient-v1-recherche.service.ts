/* istanbul ignore file */
import { Inject, Injectable } from '@angular/core';
import { ENVIRONMENT, Environment } from '@myway/env';
import { MywayHttpClient } from '@ptmyway-stc-v2/core-agent';
import { Observable } from 'rxjs';
import { RessourceClasseurclientV1Recherche } from '../modeles/classeurclient-v1-recherche.modele';

@Injectable({
  providedIn: 'root'
})
export class ClasseurclientV1RechercheService {
  constructor(private myWayHttpClient: MywayHttpClient, @Inject(ENVIRONMENT) private env: Environment) {}
  /**
   * Methode GET de recuperation du dossier DRC
   * @param idPersonne Identifiant de la personne dans le SI d'un Etablissement.
   * @returns recuperation du dossier DRC
   */
  public getDossier(idPersonne: string): Observable<RessourceClasseurclientV1Recherche.IRechercherDossierOutput> {
    return this.myWayHttpClient.get(`${this.env.urlRest}/classeurclient/v1/recherche/dossier/`, {
      params: {
        idPersonne: `${idPersonne}`
      }
    });
    // return of(RessourceClasseurclientV1Recherche.IRechercherDossierOutput);
  }
}
