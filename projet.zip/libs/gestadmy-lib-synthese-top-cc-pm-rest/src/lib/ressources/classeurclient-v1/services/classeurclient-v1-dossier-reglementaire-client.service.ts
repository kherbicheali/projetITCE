import { Inject, Injectable } from '@angular/core';
import { Environment, ENVIRONMENT } from '@myway/env';
import { MywayHttpClient } from '@ptmyway-stc-v2/core-agent';
import { Observable } from 'rxjs';
import { RessourceClasseurclientV1DossierReglementaireClient } from '../modeles/classeurclient-v1-dossier-reglementaire-client.modele';

@Injectable({
  providedIn: 'root'
})
export class ClasseurclientV1DossierReglementaireClientService {
  constructor(private myWayHttpClient: MywayHttpClient, @Inject(ENVIRONMENT) private env: Environment) {}

  /**
   * @param DonneesEntree
   * @returns Résultat des traitements
   */
  public putDossierReglementaireClient(
    DonneesEntree: RessourceClasseurclientV1DossierReglementaireClient.DonneesEntree
  ): Observable<RessourceClasseurclientV1DossierReglementaireClient.Dossier[]> {
    return this.myWayHttpClient.put(`${this.env.urlRest}/classeurclient/v1/dossierReglementaireClient/`, DonneesEntree, {
      params: {}
    });
  }
  /**
   * Méthode GET de récupération de la complétude de DRC
   * @param typeEntiteSupport typeEntiteSupport
   * @param identifiantPorteur identifiantPorteur
   * @param indicateurPersonneMorale IndicateurPersonneMorale
   * @param codeChronoDRC CodeChronoDRC
   * @returns Réponse
   */
  public getCompletudeDossierReglementaireClient(
    typeEntiteSupport: string,
    identifiantPorteur: string,
    indicateurPersonneMorale?: string,
    codeChronoDRC?: string
  ): Observable<RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse> {
    return this.myWayHttpClient.get(`${this.env.urlRest}/classeurclient/v1/dossierReglementaireClient/`, {
      params: {
        typeEntiteSupport: `${typeEntiteSupport}`,
        identifiantPorteur: `${identifiantPorteur}`
        // 'indicateurPersonneMorale': `${indicateurPersonneMorale}`,
        // 'codeChronoDRC': `${codeChronoDRC}`
      }
    });
    // return of(RessourceMockClasseurclientV1DossierReglementaireClient.infoDRCVideMock);
  }

  /**
   * Méthode DELETE permettant le transfert des DRC
   * @param codeEtablissement CodeEtablissement
   * @param identifiantCRDU Numéro CRDU
   * @param identifiantPersonne IdentifiantPersonne
   * @param identifiantProfessionnel Identifiant professionnel
   * @returns
   */
  public deleteDossierReglementaireClient(
    codeEtablissement: string,
    identifiantCRDU?: string,
    identifiantPersonne?: number,
    identifiantProfessionnel?: number
  ): Observable<void> {
    return this.myWayHttpClient.delete(`${this.env.urlRest}/classeurclient/v1/dossierReglementaireClient/`, {
      params: {
        codeEtablissement: `${codeEtablissement}`,
        identifiantCRDU: `${identifiantCRDU}`,
        identifiantPersonne: `${identifiantPersonne}`,
        identifiantProfessionnel: `${identifiantProfessionnel}`
      }
    });
  }
}
