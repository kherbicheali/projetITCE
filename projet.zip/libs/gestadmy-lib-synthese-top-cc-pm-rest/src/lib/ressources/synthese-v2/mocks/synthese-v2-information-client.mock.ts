import { RessourceSyntheseV2InformationClient } from '../modeles/synthese-v2-information-client.modele';

export namespace RessourceMockSyntheseV2InformationClient {
  export const infoClientRestMock: RessourceSyntheseV2InformationClient.IInformationClient = {
    coordonnees: {
      adresses: [
        {
          codeTypeAdresse: '1',
          libelleTypeAdresse: 'Adresse principale',
          ligne2: null,
          ligne3: null,
          ligne4: '19 RUE CHARLES TULEU',
          ligne5: null,
          ligne6: '95160 MONTMORENCY',
          codeRetourPTT: null
        },
        {
          codeTypeAdresse: '4',
          libelleTypeAdresse: 'Adresse de correspondance',
          ligne2: null,
          ligne3: null,
          ligne4: '30 T RUE GARIBALDI',
          ligne5: null,
          ligne6: '93400 ST OUEN',
          codeRetourPTT: null
        }
      ],
      telephones: [],
      eMails: [
        {
          codeSupportEMail: '2',
          codeNatureEMail: '10',
          libelleNatureEMail: 'Perso',
          adresseEMail: 'qexwuEhoohn',
          indicateurAdressePreferee: true,
          indicateurTypeClient: '1',
          numeroClient: 63376315
        },
        {
          codeSupportEMail: '2',
          codeNatureEMail: '99',
          libelleNatureEMail: 'MSI',
          adresseEMail: '750945832@DUAMSI.FR',
          indicateurAdressePreferee: false,
          indicateurTypeClient: '1',
          numeroClient: 63376315
        }
      ],
      identifiantTypeFraicheur: 'R02',
      dateFraicheur: '2015-05-24',
      codeEtatFraicheur: '2',
      coordonneesRepresentantLegal: [],
      indicateurOptInTelephone: false,
      indicateurOptinMail: false
    },
    titreSousTitre: {
      designationCourteClient: 'MADAME EXWYE FEXWOYC',
      dateDeNaissance: '1960-04-23',
      codeTypeSituationFamille: '2',
      libelleSituationFamille: 'MARIE',
      codeCategorieSocioProfessionnel: '311A',
      libelleProfession: 'KINESITHERAPEUTE',
      libelleCSP: 'MEDECINS LIBERAUX SPECIALISTES',
      identifiantEDSDomiciliation: 76,
      typeEDSDomiciliation: '003',
      libelleEDSDomiciliation: 'SAINT OUEN',
      identifiantEDSSuiviPar: 454829,
      typeEDSSuiviPar: '001',
      libelleEDSSuiviPar: 'MR AGENCE 8421 DE CLIENTELE',
      dateEntreeEnRelation: '1980-05-22',
      typeSegmentationMarche: '102102',
      codeSegmentationMarche: 'MN',
      libelleSegmentationMarche: 'Pro Lib',
      typeSegmentationRelation: 'BC',
      dateCalculSegmentationRelation: '2008-10-31',
      codeSegmentationRelation: 'PrHDG',
      libelleSegmentationRelation: 'Premium Haut de Gamme',
      codeSegmentationActive: 'BPe',
      libelleSegmentationActive: 'Bancarisé Principal équipé',
      typeUnivers: 'SU',
      codeUnivers: 'BepCA',
      dateCalculSegmentationActive: '2020-11-30',
      codeSuiviGP: null,
      libelleSuiviGP: null,
      identifiantEDSSuiviGP: 0,
      typeEDSSuiviGP: null,
      libelleEDSSuiviGP: null,
      descriptionSuiviGP: null,
      dateDebutSuiviGP: null,
      listeDetailMarche: [
        {
          codeEtablissement: '17515',
          numeroClient: 63376315,
          codeTypeSegmentationMarche: 'MN',
          codeSegmentationMarche: '102102',
          libelleSegmentationMarche: 'PRO : Professions libérales, relation bancaire à titre professionnel',
          libelleCourtSegmentationMarche: 'Pro Lib',
          dateCalculSegmentationMarche: '2008-10-31',
          indicateurForcageSegmentation: null,
          codeSegmentationForcee: null,
          libelleSegmentationForcee: null,
          libelleCourtSegmentationForcee: null,
          dateForcageSegmentation: '2008-10-31'
        }
      ],
      detailSuiviPar: {
        ligne1: 'PTF : CCPA PRO ASSO 076',
        ligne2: "RATTACHE A L'AGENCE SAINT OUEN",
        ligne3: 'AFFECTE A   MR AGENCE 8421 DE',
        ligne4: 'CHARGE D AFFAIRES PRO ASSO 1'
      },
      listeDetailSegmentationActive: [
        {
          numeroClient: 63376315,
          libelleClient: 'NIMYCPXYC FEXWOYC',
          typeSegmentationParticulier: 'SA',
          codeSegmentationParticulier: 'BPe',
          codeUniversSegmentation: 'BepCA',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'Bancarisé Principal équipé',
          descriptionSegmentation1:
            // tslint:disable-next-line: max-line-length
            'Clients de 26 ans et plus avec flux créditeurs externes sur CDD >=800€ en moyenne mensuelle sur 12 mois glissants ET plus de 15 opérations débitrices externes sur CDD en moyenne mensuelle sur 12 mois glissants',
          descriptionSegmentation2: 'ET au moins 3 Univers de détention couverts'
        },
        {
          numeroClient: 63808885,
          libelleClient: 'NIMYCPXYC FUNYT',
          typeSegmentationParticulier: 'SA',
          codeSegmentationParticulier: 'BPe',
          codeUniversSegmentation: 'BEpCa',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'Bancarisé Principal équipé',
          descriptionSegmentation1:
            // tslint:disable-next-line: max-line-length
            'Clients de 26 ans et plus avec flux créditeurs externes sur CDD >=800€ en moyenne mensuelle sur 12 mois glissants ET plus de 15 opérations débitrices externes sur CDD en moyenne mensuelle sur 12 mois glissants',
          descriptionSegmentation2: 'ET au moins 3 Univers de détention couverts'
        },
        {
          numeroClient: 65145037,
          libelleClient: 'NIMYCPXYC OJKEN JDY',
          typeSegmentationParticulier: 'SA',
          codeSegmentationParticulier: 'BPe',
          codeUniversSegmentation: 'BEPCa',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'Bancarisé Principal équipé',
          descriptionSegmentation1:
            // tslint:disable-next-line: max-line-length
            'Clients de 26 ans et plus avec flux créditeurs externes sur CDD >=800€ en moyenne mensuelle sur 12 mois glissants ET plus de 15 opérations débitrices externes sur CDD en moyenne mensuelle sur 12 mois glissants',
          descriptionSegmentation2: 'ET au moins 3 Univers de détention couverts'
        },
        {
          numeroClient: 66927662,
          libelleClient: 'VFY NMY',
          typeSegmentationParticulier: null,
          codeSegmentationParticulier: null,
          codeUniversSegmentation: null,
          dateCalculSegmentation: null,
          libelleSegmentation: null,
          descriptionSegmentation1: null,
          descriptionSegmentation2: null
        }
      ],
      listeDetailSegmentationPro: [
        {
          numeroClient: 63376315,
          libelleClient: 'NIMYCPXYC FEXWOYC',
          typeSegmentationProfessionnelle: 'BP',
          codeSegmentationProfessionnelle: 'PLR**',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'PLR Partiellement Capté',
          descriptionSegmentation1:
            // tslint:disable-next-line: max-line-length
            'Client Prof. Lib. Réglementée au potentiel partiellement capté générant un niveau de flux et de PNB moyens au sein de son segment clientèle ; profil type CPA en double relation faiblement Equipé',
          descriptionSegmentation2: "Parfaire la connaissance client pour mieux répondre à ses besoins et l'équiper"
        },
        {
          numeroClient: 63808885,
          libelleClient: 'NIMYCPXYC FUNYT',
          typeSegmentationProfessionnelle: 'BP',
          codeSegmentationProfessionnelle: 'PLR**',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'PLR Partiellement Capté',
          descriptionSegmentation1:
            // tslint:disable-next-line: max-line-length
            'Client Prof. Lib. Réglementée au potentiel partiellement capté générant un niveau de flux et de PNB moyens au sein de son segment clientèle ; profil type CPA en double relation faiblement Equipé',
          descriptionSegmentation2: "Parfaire la connaissance client pour mieux répondre à ses besoins et l'équiper"
        },
        {
          numeroClient: 65145037,
          libelleClient: 'NIMYCPXYC OJKEN JDY',
          typeSegmentationProfessionnelle: 'BP',
          codeSegmentationProfessionnelle: 'SML**',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'Small PRO Partiellement Capté',
          descriptionSegmentation1:
            // tslint:disable-next-line: max-line-length
            'Client Small Pro au potentiel partiellement capté générant un niveau moyen de flux et de PNB du segment clientèle ; profil type client peu actif non équipé et en double relation',
          descriptionSegmentation2: 'Parfaire la connaissance client pour mieux équiper'
        },
        {
          numeroClient: 66927662,
          libelleClient: 'VFY NMY',
          typeSegmentationProfessionnelle: null,
          codeSegmentationProfessionnelle: null,
          dateCalculSegmentation: null,
          libelleSegmentation: null,
          descriptionSegmentation1: null,
          descriptionSegmentation2: null
        }
      ],
      listeDetailSegmentationRelation: [
        {
          numeroClient: 63376315,
          libelleClient: 'NIMYCPXYC FEXWOYC',
          typeSegmentationParticulier: 'BC',
          codeSegmentationParticulier: 'PrHDG',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'Premium Haut de Gamme',
          descriptionSegmentation1: 'Relation ayant une surface financière > 75 KEuros OU des flux confiés > 75 KEuros',
          descriptionSegmentation2: null
        },
        {
          numeroClient: 63808885,
          libelleClient: 'NIMYCPXYC FUNYT',
          typeSegmentationParticulier: 'BC',
          codeSegmentationParticulier: 'PrHDG',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'Premium Haut de Gamme',
          descriptionSegmentation1: 'Relation ayant une surface financière > 75 KEuros OU des flux confiés > 75 KEuros',
          descriptionSegmentation2: null
        },
        {
          numeroClient: 65145037,
          libelleClient: 'NIMYCPXYC OJKEN JDY',
          typeSegmentationParticulier: 'BC',
          codeSegmentationParticulier: 'PrHDG',
          dateCalculSegmentation: '2020-11-30',
          libelleSegmentation: 'Premium Haut de Gamme',
          descriptionSegmentation1: 'Relation ayant une surface financière > 75 KEuros OU des flux confiés > 75 KEuros',
          descriptionSegmentation2: null
        },
        {
          numeroClient: 66927662,
          libelleClient: 'VFY NMY',
          typeSegmentationParticulier: null,
          codeSegmentationParticulier: null,
          dateCalculSegmentation: null,
          libelleSegmentation: null,
          descriptionSegmentation1: null,
          descriptionSegmentation2: null
        }
      ],
      codeReperePro: null,
      libelleReperePro: null,
      villeNaissance: 'PARIS 15E ARRONDISSEMENT',
      paysNaissance: 'FRANCE',
      codeInseeNaissance: '75115',
      dateDeces: null,
      nationalite: 'FRANCAISE'
    },
    entretien: {
      codeMediaEntretien: null,
      libelleMediaEntretien: null,
      codeMotifEntretien: null,
      libelleMotifEntretien: null,
      codeCanalEntretien: null,
      libelleCanalEntretien: null,
      codeSensEntretien: null,
      libelleSensEntretien: null,
      dateEntretien: null,
      codeMediaProchainEntretien: null,
      libelleMotifProchainEntretien: null,
      dateProchainEntretien: null,
      indicateurExistenceProchainRDV: null,
      libelleMediaProchainEntretien: null
    },
    opportunite: {
      numeroPersonne: null,
      designationCourteClient: null,
      nombreOpportunitesClient: null,
      commentaireOpportunite: null,
      nombreDVetPropositionClient: null
    },
    alerte: {
      codeEtatCompletudeDRC: null,
      indicateurAlerteDRC: null,
      libelleEtatDRC: null,
      indicateurNPAI: null,
      codeClientFragile: null,
      libelleClientFragile: null,
      scoreVigilance: null,
      libelleScoreVigilance: null,
      codeEckert: null,
      dateDeces: null,
      indicateurOpposition: null,
      codeContentieux: null,
      montantContentieux: null,
      indicateurATD: null,
      indicateurReclamation: null,
      indicateurInterditBancaire: null,
      codePresenceRPM: null,
      libellePresenceRPM: null,
      nombreRejetMAD: null,
      indicateurReglementaireEpargne: null,
      indicateurAlerteLEP: null,
      indicateurAlertePEL: null,
      listeDetailReglementaireEpargne: [],
      listeDetailAlerteRPM: [],
      listeDetailDRC: [],
      codeCapaciteJuridique: null,
      libelleCapaciteJuridique: null,
      indicateurContentieux: null,
      indicateurRecouvrementAmiable: null,
      listeDetailAlerteMAD: [],
      codeTopCC: null,
      libelleTopCC: null,
      listeOffresInstance: [],
      indicateurGAE: null
    },
    indicateur: {
      codeEtatCompletudeDRC: null,
      indicateurAlerteDRC: null,
      libelleEtatDRC: null,
      niveauRisqueInvestisseur: null,
      libelleNiveauRisqueInvestisseur: null,
      dateMesureRisqueInvestisseur: null,
      competenceFinanciere: null,
      dateDernierQCF: null,
      indicateurSocietaire: null,
      codeSLE: null,
      libelleSLE: null,
      dateDerniereEnquete: null,
      codeNiveauSatisfaction: null,
      libelleNiveauSatisfaction: null,
      codeAppartenanceReseau: null,
      libelleAppartenanceReseau: null,
      scoreVigilance: null,
      libelleScoreVigilance: null,
      noteBaleII: null,
      detailNoteBaleII: null,
      codeStatutPPE: null,
      libelleStatutPPE: null,
      listeDetailEnqueteSatisfaction: [],
      indicateurEngagementDom: null,
      libelleEngagementDom: null,
      listeDetailEngagementDom: [],
      detailCompetenceFinanciere: null,
      codeTopCC: null,
      libelleTopCC: null,
      codeEtatClientScoring: null,
      libelleEtatClientScoring: null,
      detailPrecibleCreditConso: null
    }
  };
}
