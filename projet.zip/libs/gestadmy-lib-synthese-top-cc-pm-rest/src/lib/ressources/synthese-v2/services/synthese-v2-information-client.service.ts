import { Inject, Injectable } from '@angular/core';
import { ENVIRONMENT, Environment } from '@myway/env';
import { RequestHttpAgentService } from '@ptmyway-stc-v2/request-http-agent';
import { Observable } from 'rxjs';
import { RessourceSyntheseV2InformationClient } from '../modeles/synthese-v2-information-client.modele';

@Injectable({
  providedIn: 'root'
})
export class SyntheseV2InformationClientService {
  constructor(private requestHttpAgentService: RequestHttpAgentService, @Inject(ENVIRONMENT) private env: Environment) {}

  public getInformationClient(
    codeEtablissement: string,
    numeroClient: number,
    indicateurTousBlocs: boolean,
    indicateurCoordonnees: boolean,
    indicateurTitreSousTitre: boolean
  ): Observable<RessourceSyntheseV2InformationClient.IInformationClient> {
    return this.requestHttpAgentService.get(`${this.env.urlRest}/synthese/v2/informationClient/`, {
      codeEtablissement: `${codeEtablissement}`,
      numeroClient: `${numeroClient}`,
      indicateurTousBlocs: `${indicateurTousBlocs}`,
      indicateurCoordonnees: `${indicateurCoordonnees}`,
      indicateurTitreSousTitre: `${indicateurTitreSousTitre}`
    });
    // return of(RessourceMockSyntheseV2InformationClient.infoClientRestMock);
  }
}
