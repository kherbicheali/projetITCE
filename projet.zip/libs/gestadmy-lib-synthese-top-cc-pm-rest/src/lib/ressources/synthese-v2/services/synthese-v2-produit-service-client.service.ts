import { Inject, Injectable } from '@angular/core';
import { ENVIRONMENT, Environment } from '@myway/env';
import { RequestHttpAgentService } from '@ptmyway-stc-v2/request-http-agent';
import { Observable } from 'rxjs';
import { RessourceSyntheseV2ProduitServiceClient } from '../modeles/synthese-v2-produit-service-client.modele';

@Injectable({
  providedIn: 'root'
})
export class SyntheseV2ProduitServiceClientService {
  constructor(private requestHttpAgentService: RequestHttpAgentService, @Inject(ENVIRONMENT) private env: Environment) {}

  public getProduitServiceClient(
    codeEtablissement: string,
    numeroClient: number
  ): Observable<RessourceSyntheseV2ProduitServiceClient.IProduitServiceClient> {
    return this.requestHttpAgentService.get(`${this.env.urlRest}/synthese/v2/produitServiceClient/`, {
      codeEtablissement: `${codeEtablissement}`,
      numeroClient: `${numeroClient}`
    });
  }
}
