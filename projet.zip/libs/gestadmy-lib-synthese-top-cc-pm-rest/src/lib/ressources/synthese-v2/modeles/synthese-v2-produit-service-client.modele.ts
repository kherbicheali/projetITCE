export namespace RessourceSyntheseV2ProduitServiceClient {
  export interface IEntiteTitulaire {
    /**
     * Numéro de l'entité titulaire à laquelle est rattaché le produit
     */
    numeroET: number;
    /**
     * Désignation de l'entité titulaire
     */
    designationCourte: string;
    /**
     * Code du mode de composition :
     * 1          mode simple
     * 2          mode joint entre époux
     * 3          mode joint entre tiers
     * 4          mode indivision
     */
    codeModeComposition: string;
    /**
     * Libellé du mode de composition de l'entité titulaire
     */
    libelleModeComposition: string;
    /**
     * Détermine si l'entité titulaire est privée ou professionnelle :
     * '1'        PRIVE
     * '2'        PROFESSIONNEL
     * '3'        PROFESSIONNEL REGLEMENTE
     * '4'        SUCCESSION
     * '5'        VERSEMENT DIRECT
     * '6'        CONFIDENTIEL PRIVE
     */
    codeUsage: string;
    /**
     * Définit l'état de la personne ou de l'entité titulaire
     * à une date donnée dans la gestion administrative
     * des personnes :
     * '0'        Actif
     * '1'        Cloturé
     */
    codeEtat: string;
    /**
     * Identifiant de l'Elément De Structure de géré par
     */
    identifiantEDSGerePar: number;
    /**
     * Référence externe de l'Elément De Structure de géré par
     */
    referenceExterneEDSGerePar: number;
    /**
     * Type d'Elément De Structure de géré par
     */
    typeEDSGerePar: string;
    /**
     * Libellé de l'Elément De Structure de géré par
     */
    libelleEDSGerePar: string;
    /**
     * Identifiant de l'Elément De Structure de domicilié à
     */
    identifiantEDSDomicilieA: number;
    /**
     * Référence externe de l'Elément De Structure de domicilié à
     */
    referenceExterneEDSDomicilieA: number;
    /**
     * Type d'Elément De Structure de domicilié à
     */
    typeEDSDomicilieA: string;
    /**
     * Libellé de l'Elément De Structure de domicilié à
     */
    libelleEDSDomicilieA: string;
    /**
     * Numéro téléphone adresse
     */
    numeroTelephoneDomicileET: string;
    /**
     * Permet d'indiquer
     * si l'entité titulaire a été détectée douteuse à
     * la suite d'incident de paiement sur un crédit :
     * 0          Entité titulaire saine
     * 1          Entité titulaire douteuse
     */
    indicateurDouteux: number;
    /**
     * Précise la "qualité" du client bancaire particulier
     */
    codeCotationBancaire: string;
    /**
     * Spécifie le type d'indivision:
     * 1          Mode indivision successorale
     * 2          Mode indivision conventionnel avec solidarité
     * 3          Mode indivision conventionnel sans solidarité
     */
    sousCodeModeComposition: string;
    /**
     * Détermine la valeur calculée d'un type de note
     * attribuée à une entité donnée.
     */
    noteCalculee: string;
    /**
     * Permet d'établir notamment le TimeStamp du calcul de la
     * note
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    timestampNotation: string;
    /**
     * Numéro de SIREN pour les entreprises
     */
    numeroSIREN: string;
    /**
     * Numéro de SIRET pour les entreprises
     */
    numeroSIRET: string;
    listeCompte: Array<ICompte>;
    compteurCompte: ICompteur;
    listeEpargne: Array<IEpargne>;
    compteurEpargne: ICompteur;
    listeCredit: Array<ICredit>;
    compteurCredit: ICompteur;
    listeAssurance: Array<IAssurance>;
    compteurAssurance: ICompteur;
    listePrevoyance: Array<IPrevoyance>;
    compteurPrevoyance: ICompteur;
    services: IService;
    compteurService: ICompteur;
    compteurToutUnivers: ICompteur;
    /**
     * Détermine si l'entité titulaire est privée ou professionnelle :
     * '1'        PRIVE
     * '2'        PROFESSIONNEL
     * '3'        PROFESSIONNEL REGLEMENTE
     * '4'        SUCCESSION
     * '5'        VERSEMENT DIRECT
     * '6'        CONFIDENTIEL PRIVE
     */
    libelleUsage: string;
  }

  export interface ICompte {
    partieCommuneCompte: IPartieCommuneCompte;
  }

  export interface IEpargne {
    partieCommuneEpargne: IPartieCommuneEpargne;
  }

  export interface ICredit {
    partieCommuneCredit: IPartieCommuneCredit;
  }

  export interface IAssurance {
    partieCommuneAssurance: IPartieCommuneAssurance;
  }

  export interface IPrevoyance {
    partieCommunePrevoyance: IPartieCommunePrevoyance;
  }

  export interface IPartieCommuneCompte {
    /**
     * Code devise du produit
     */
    codeDevise: string;
    /**
     * Code de l'établissement auquel est rattaché le produit
     */
    codeEtablissement: string;
    /**
     * Code guichet du produit
     */
    codeGuichet: string;
    /**
     * Numéro de l'entité titulaire à laquelle est rattaché le produit
     */
    numeroET: number;
    /**
     * Code du type du produit
     */
    codeProduit: string;
    /**
     * Identifiant du type du produit
     */
    identifiantTypeProduit: number;
    /**
     * Libellé du produit
     */
    libelleTypeProduit: string;
    /**
     * Numéro de compte du produit
     */
    numeroCompte: string;
    /**
     * Indique si le produit est en opposition ou non
     */
    indicateurOpposition: boolean;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Identifiant du produit père dans le cadre d'une relation d'association ou de composition
     */
    numeroProduitPere: number;
    /**
     * 'F'        Forfaitaire
     * 'U'        Unitaire
     */
    codeTypeOffre: string;
    /**
     * Numéro de l'offre si le produit fait partit d'une offre
     */
    numeroOffre: number;
    /**
     * Clé du RIB
     */
    clefRIB: string;
    /**
     * Code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Solde en cours du compte
     */
    solde: number;
    /**
     * montant du decouvert
     */
    montantDecouvert: number;
    /**
     * Somme des encours des cartes du compte
     */
    encoursCarte: number;
    /**
     * Montant reprenant le total des échéances prêts
     * crédécureuil en Impayé ayant pour compte de
     * prélèvement un compte donné
     */
    cumulMontantImpaye: number;
    /**
     * Cumul des réserves d'encaissement en
     * monnaie de tenue de compte.
     */
    cumulReserveEncaissement: number;
    /**
     * Indique si le produit a été créé dans la journée
     */
    indicateurNouveauProduit: boolean;
    /**
     * Libellé de personnalisation du compte
     * Texte libre facultatif
     * permet de distinguer plusieurs compte du même type  appartenant à
     * un même client
     */
    libellePersonnalise: string;
    /**
     * Indique si le produit fait partit d'une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Code produit national
     */
    codeProduitNational: string;
    /**
     * Sous code du produit
     */
    sousCodePS: string;
    /**
     * Code de la devise de tenue de compte
     */
    codeDeviseTenueCompte: string;
    /**
     * Libellé de la devise de tenue de compte
     */
    libelleDeviseTenueCompte: string;
    /**
     * Solde en devise de tenue de compte
     */
    soldeDeviseTenueCompte: number;
    /**
     * Indique si le compte fait partit d'une offre famille
     */
    indicateurOffreFamille: boolean;
    /**
     * Numéro de l'offre famille si il y a
     */
    numeroOffreFamille: number;
    /**
     * Type de titulaire dans l'offre famille :
     * P = Parent
     * E = Enfant
     */
    typeTitulaireOffreFamille: string;
    /**
     * Date d'ouverture de l'offre
     * Type date au format yyyy-MM-dd
     */
    dateOuvertureOffre: string;
    /**
     * Indique si le produit est en interdit bancaire
     */
    indicateurInterditBancaire: boolean;
    /**
     * Date de cloture du produit
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le produit détient une carte à débis differé
     */
    indicateurPresenceCarteDD: boolean;
    /**
     * Date d'ouverture du contrat
     * Type date au format yyyy-MM-dd
     */
    dateOuvertureContrat: string;
    /**
     * Montant des soldes fusionnés
     */
    montantSoldeFusionne: number;
    /**
     * Solde disponible
     */
    soldeDisponible: number;
    /**
     * Code établissement du compte maitre de fusion
     */
    codeEtablissementCompteMaitre: string;
    /**
     * Code guichet du compte maitre de fusion
     */
    codeGuichetCompteMaitre: string;
    /**
     * Numéro du compte maitre de fusion
     */
    numeroCompteMaitre: string;
    /**
     * Indique si le produit est nanti
     */
    indicateurNantissement: boolean;
    /**
     * Libellé du type de découvert
     */
    libelleTypeDecouvert: string;
    /**
     * Code du type de découvert
     */
    codeTypeDecouvert: string;
    /**
     * Indique si le produit est lié à une adresse spéciale de communication  pour le RMP
     */
    indicateurRMPSpecialCom: boolean;
    /**
     * 'F' = le compte participe
     * 'G' = le compte est maitre
     */
    codeTypeFusion: string;
  }

  export interface IPartieCommuneEpargne {
    /**
     * Code devise du produit
     */
    codeDevise: string;
    /**
     * Code de l'établissement auquel est rattaché le produit
     */
    codeEtablissement: string;
    /**
     * Code guichet du produit
     */
    codeGuichet: string;
    /**
     * Numéro de l'entité titulaire à laquelle est rattaché le produit
     */
    numeroET: number;
    /**
     * Code du type du produit
     */
    codeProduit: string;
    /**
     * Identifiant du type du produit
     */
    identifiantTypeProduit: number;
    /**
     * Libellé du produit
     */
    libelleTypeProduit: string;
    /**
     * Numéro de compte du produit
     */
    numeroCompte: string;
    /**
     * Indique si le produit est en opposition ou non
     */
    indicateurOpposition: boolean;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Identifiant du produit père dans le cadre d'une relation d'association ou de composition
     */
    numeroProduitPere: number;
    /**
     * 'F'        Forfaitaire
     * 'U'        Unitaire
     */
    codeTypeOffre: string;
    /**
     * Numéro de l'offre si le produit fait partit d'une offre
     */
    numeroOffre: number;
    /**
     * Clé du RIB
     */
    clefRIB: string;
    /**
     * Code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Solde en cours du compte
     */
    solde: number;
    /**
     * Date d'ouverture du produit
     * Type date au format yyyy-MM-dd
     */
    dateOuverture: string;
    /**
     * Montant à verser par période par le client sur le produit
     */
    montantEcheance: number;
    /**
     * Périodicité des versements
     */
    periodiciteEcheance: string;
    /**
     * Date de prévision du prochain versement
     * Type date au format yyyy-MM-dd
     */
    dateProchaineEcheance: string;
    /**
     * Taux d'Intérêts sur le contrat
     */
    tauxInterets: number;
    /**
     * Indique si le produit a été créé dans la journée
     */
    indicateurNouveauProduit: boolean;
    /**
     * Code produit national
     */
    codeProduitNational: string;
    /**
     * Sous code du produit
     */
    sousCodePS: string;
    /**
     * Code de la devise de tenue de compte
     */
    codeDeviseTenueCompte: string;
    /**
     * Libellé de la devise de tenue de compte
     */
    libelleDeviseTenueCompte: string;
    /**
     * Solde en devise de tenue de compte
     */
    soldeDeviseTenueCompte: number;
    /**
     * Indique si le produit fait partit d'une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Date de cloture du produit
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le produit est nanti
     */
    indicateurNantissement: boolean;
    /**
     * Date de valorisation
     * Type date au format yyyy-MM-dd
     */
    dateValorisation: string;
    /**
     * Numéro de contrat assurance vie
     */
    numeroContrat: string;
    /**
     * Indique si le produit est lié à une adresse spéciale de communication  pour le RMP
     */
    indicateurRMPSpecialCom: boolean;
    /**
     * Code état du contrat :
     * '1'        Actif
     * '2'        Bloqué
     * '3'        Fermé
     */
    codeEtatContrat: string;
    /**
     * Montant cession de l'année en court
     */
    montantCession: number;
    /**
     * Date d'échéance
     * Type date au format yyyy-MM-dd
     */
    dateEcheance: string;
    /**
     * Date d'arreté
     * Type date au format yyyy-MM-dd
     */
    dateArrete: string;
    /**
     * Nombre de part
     */
    nombrePart: number;
    /**
     * Libellé nature SCPI
     */
    libelleNature: string;
    /**
     * Montant de l'estimation de rachat
     */
    montantEstimationRachat: number;
    /**
     * Date de rachat
     * Type date au format yyyy-MM-dd
     */
    dateRachat: string;
    /**
     * Valeur de rachat d'une part
     */
    valeurUnitaireRachatPart: number;
    /**
     * Indique si un remboursement anticipé est en cours
     */
    indicateurRemboursementAnticipe: boolean;
    /**
     * Date de début du remboursement anticipé
     * Type date au format yyyy-MM-dd
     */
    dateDebutRemboursementAnticipe: string;
    /**
     * Date de fin du remboursement anticipé
     * Type date au format yyyy-MM-dd
     */
    dateFinRemboursementAnticipe: string;
    /**
     * Code de l'établissement d'origine du produit
     */
    codeEtablissementOrigine: string;
    /**
     * Libellé de l'établissement d'origine du produit
     */
    libelleEtablissementOrigine: string;
    /**
     * Date de la demande de transfert
     * Type date au format yyyy-MM-dd
     */
    dateDemande: string;
    /**
     * Détermine le gestionnaire du compte titres
     */
    codeGestionnaireCompte: string;
    /**
     * Libellé du code gestionnaire du comptes titres :
     * '1'        Gestionnaire NATIXIS
     * '2'        Gestionnaire CACEIS
     * '3'        Parts Sociales
     * '4'        Gestionnaire NATIXIS Grands Investisseurs
     * '5'        Gestionnaire sous Mandat
     * '6'        Gestionnaire NATIXIS Life
     * '7'        Gestionnaire sous mandat NATIXIS Life
     */
    libelleGestionnaireCompte: string;
    /**
     * INFORMATIONS CLIENT
     * alimentees lors de l ouverture, avenant, cloture
     * de compte titres
     */
    informationLibre: string;
  }

  export interface IPartieCommuneCredit {
    /**
     * Code devise du produit
     */
    codeDevise: string;
    /**
     * Code de l'établissement auquel est rattaché le produit
     */
    codeEtablissement: string;
    /**
     * Code guichet du produit
     */
    codeGuichet: string;
    /**
     * Numéro de l'entité titulaire à laquelle est rattaché le produit
     */
    numeroET: number;
    /**
     * Code du type du produit
     */
    codeProduit: string;
    /**
     * Identifiant du type du produit
     */
    identifiantTypeProduit: number;
    /**
     * Libellé du produit
     */
    libelleTypeProduit: string;
    /**
     * Numéro de compte du produit
     */
    numeroCompte: string;
    /**
     * Indique si le produit est en opposition ou non
     */
    indicateurOpposition: boolean;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Motif du crédit
     * ex: Crédit Auto
     */
    motif: string;
    /**
     * Statut du crédit
     * ex: en amortissement
     */
    statut: string;
    /**
     * Montant initial du crédit
     */
    montantInitial: number;
    /**
     * part du capital emprunté restant à rembourser au prêteur à un instant T
     */
    capitalRestantDu: number;
    /**
     * Date d'effet du contrat
     * Type date au format yyyy-MM-dd
     */
    dateEffet: string;
    /**
     * Date de fin du contrat
     * Type date au format yyyy-MM-dd
     */
    dateFin: string;
    /**
     * Durée restante du contrat en mois
     */
    dureeRestante: number;
    /**
     * Montant de versement par échéance
     */
    montantEcheance: number;
    /**
     * Périodicité de l'échéance de remboursement
     */
    periodiciteEcheance: string;
    /**
     * Montant des impayés du client sur ce contrat
     */
    montantImpaye: number;
    /**
     * Code produit national
     */
    codeProduitNational: string;
    /**
     * Sous code du produit
     */
    sousCodePS: string;
    /**
     * Libellé du type de financement (ex : Habitat)
     */
    libelleFinancement: string;
    /**
     * Libellé de la phase du crédit
     */
    libellePhase: string;
    /**
     * Montant disponible sur les reserves d'argent
     */
    montantDisponible: number;
    /**
     * Détermine une offre type de crédit CEFI
     */
    codeOffreCefi: string;
    /**
     * Numéro du contrat
     */
    numeroContrat: string;
    /**
     * Taux du crédit
     */
    taux: number;
    /**
     * Indique si le produit a été créé dans la journée
     */
    indicateurNouveauProduit: boolean;
    /**
     * Montant des créances gelées
     */
    montantCreanceGelee: number;
    identifiantEnveloppe: string;
    montantRestantAVerser: number;
    identifiantAlis: string;
    numeroInterneCompte: string;
    libelleOrganisme: string;
    dateArrete: string;
    montantGaranti: number;
    libelleEtablissementPilote: string;
    codeEtatDossier: string;
    libelleEtatDossier: string;
    montantTotalVerse: number;
    /**
     * 'ENC ' pour l'encaissement
     * 'VAL ' pour l'escompte en valeur
     * 'COM ' pour l'escompte commercial
     * 'FIN ' pour l'escompte financier
     * ' 1nn' pour les escomptes commerciaux (nn = 00 à 99)
     * ' 2nn' pour les escomptes financiers  (nn = 00 à 99).
     */
    codeCategoriePapier: string;
    /**
     * Définition l'objet du crédit
     */
    libelleTypeObjetCommercial: string;
    /**
     * Code établissement du compte sur lequel l'échéance du crédit est prélevée
     */
    codeEtabComptePrelevement: string;
    /**
     * Code guichet du compte sur lequel l'échéance du crédit est prélevée
     */
    codeGuichetComptePrelevement: string;
    /**
     * Numéro du compte sur lequel l'échéance du crédit est prélevée
     */
    numeroComptePrelevement: string;
    /**
     * Clé RIB du compte sur lequel l'échéance du crédit est prélevée
     */
    cleRIBComptePrelevement: string;
    /**
     * Libellé garanti
     */
    libelleGaranti: string;
    /**
     * Identifiant du compte
     */
    identifiantCompte: string;
    /**
     * Libellé court du produit
     */
    libelleCourtProduit: string;
    /**
     * Date d'échéance
     * Type date au format yyyy-MM-dd
     */
    dateEcheance: string;
    /**
     * Taux équivalent rapporté à la période
     */
    tauxInteretPalier: number;
    /**
     * Indique si le produit est affichable en vue client :
     * 'O' = Affichable
     * 'N' = non affichable
     */
    indicateurVueClient: boolean;
    /**
     * Identifiant du dossier dans lequel se trouve le crédit
     */
    identifiantDossier: string;
    /**
     * Libellé du dossier dans lequel se trouve le crédit
     */
    libelleDossier: string;
    /**
     * Indique si il s'agit d'un dossier ou d'un crédit
     */
    codeDossierCredit: string;
    /**
     * Code état de la réserve de crédit IZIVENTE:
     * '2' = instruction en cours
     * '3' = mis en force
     */
    codeEtatReserve: string;
    /**
     * Libellé état de la réserve de crédit IZIVENTE:
     * '2' = instruction en cours
     * '3' = mis en force
     */
    libelleEtatReserve: string;
    /**
     * 'C'        Engagement par trésorerie
     * 'E'        Engagement par signature
     */
    codeTypeConcours: string;
  }

  export interface IPartieCommuneAssurance {
    /**
     * Code devise du produit
     */
    codeDevise: string;
    /**
     * Code de l'établissement auquel est rattaché le produit
     */
    codeEtablissement: string;
    /**
     * Code guichet du produit
     */
    codeGuichet: string;
    /**
     * Numéro de l'entité titulaire à laquelle est rattaché le produit
     */
    numeroET: number;
    /**
     * Code du type du produit
     */
    codeProduit: string;
    /**
     * Identifiant du type du produit
     */
    identifiantTypeProduit: number;
    /**
     * Libellé du produit
     */
    libelleTypeProduit: string;
    /**
     * Numéro de compte du produit
     */
    numeroCompte: string;
    /**
     * Indique si le produit est en opposition ou non
     */
    indicateurOpposition: boolean;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Code de la police d'assurance
     */
    codePolice: string;
    /**
     * Date d'effet de l'assurance
     * Type date au format yyyy-MM-dd
     */
    dateEffet: string;
    /**
     * Montant garanti pour une assurance décès
     */
    montantGaranti: number;
    /**
     * Indique si le produit a été créé dans la journée
     */
    indicateurNouveauProduit: boolean;
    /**
     * Libellé de la police d'assurance
     */
    libellePolice: string;
    /**
     * Numéro du contrat
     */
    numeroContrat: string;
    /**
     * Montant de la prime d'assurance IARD
     */
    montantPrimeAssurance: number;
    /**
     * Code produit national
     */
    codeProduitNational: string;
    /**
     * Sous code du produit
     */
    sousCodePS: string;
    /**
     * Libellé du type d'assurance
     */
    libelleContrat: string;
    /**
     * Libellé de la formule d'assurance
     */
    libelleFormule: string;
    /**
     * Code déterminant un type de formule
     */
    codeFormule: string;
    /**
     * Code déterminant le Segment envoyé par un flux
     */
    codeSegmentFlux: string;
    /**
     * Daet de fin d'effet
     * Type date au format yyyy-MM-dd
     */
    dateFinEffet: string;
    /**
     * Précise la situation d'un contrat :
     * '0'        devis
     * '1'        contrat en cours
     * '2'        contrat mis en demeure
     * '3'        contrat suspendu
     * '4'        contentieux
     * '6'        contrat résilié
     * '7'        résilié non paiement
     * '9'        AFN sans effet
     */
    codeSituationContrat: string;
    /**
     * Précise la situation d'un contrat :
     * '0'        devis
     * '1'        contrat en cours
     * '2'        contrat mis en demeure
     * '3'        contrat suspendu
     * '4'        contentieux
     * '6'        contrat résilié
     * '7'        résilié non paiement
     * '9'        AFN sans effet
     */
    libelleSituationContrat: string;
    /**
     * Code établissement du compte de prélèvement
     */
    codeEtablissementPrelevement: string;
    /**
     * Code guichet du compte de prélèvement
     */
    codeGuichetPrelevement: string;
    /**
     * Numéro du compte de prélèvement
     */
    numeroComptePrelevement: string;
    /**
     * Clé RIB du compte de prélèvement
     */
    cleRIBPrelevement: string;
    /**
     * RIB complet du compte de prélèvement
     */
    comptePrelevement: string;
    /**
     * Nombre de salarié
     */
    nombreSalarie: string;
    /**
     * Date d'opération
     * Type date au format yyyy-MM-dd
     */
    dateOperation: string;
    /**
     * Date d’arrêté
     * Type date au format yyyy-MM-dd
     */
    dateArrete: string;
    /**
     * Référence interne MySys du produit
     */
    referenceInterne: string;
  }

  export interface IPartieCommunePrevoyance {
    /**
     * Code devise du produit
     */
    codeDevise: string;
    /**
     * Code de l'établissement auquel est rattaché le produit
     */
    codeEtablissement: string;
    /**
     * Code guichet du produit
     */
    codeGuichet: string;
    /**
     * Numéro de l'entité titulaire à laquelle est rattaché le produit
     */
    numeroET: number;
    /**
     * Code du type du produit
     */
    codeProduit: string;
    /**
     * Identifiant du type du produit
     */
    identifiantTypeProduit: number;
    /**
     * Libellé du produit
     */
    libelleTypeProduit: string;
    /**
     * Numéro de compte du produit
     */
    numeroCompte: string;
    /**
     * Indique si le produit est en opposition ou non
     */
    indicateurOpposition: boolean;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Identifiant du produit père dans le cadre d'une relation d'association ou de composition
     */
    numeroProduitPere: number;
    /**
     * 'F'        Forfaitaire
     * 'U'        Unitaire
     */
    codeTypeOffre: string;
    /**
     * Numéro de l'offre si le produit fait partit d'une offre
     */
    numeroOffre: number;
    /**
     * Code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Solde en cours du compte
     */
    solde: number;
    /**
     * Police d'assurance prévoyance
     */
    police: string;
    /**
     * Date d'effet de l'assurance prévoyance
     * Type date au format yyyy-MM-dd
     */
    dateEffet: string;
    /**
     * Indique si le produit a été créé dans la journée
     */
    indicateurNouveauProduit: boolean;
    /**
     * Numéro du contrat
     */
    numeroContrat: string;
    /**
     * Code produit national
     */
    codeProduitNational: string;
    /**
     * Sous code du produit
     */
    sousCodePS: string;
    /**
     * Date de fin d'effet
     * Type date au format yyyy-MM-dd
     */
    dateFinEffet: string;
    /**
     * Date de derniere valorisation
     * Type date au format yyyy-MM-dd
     */
    dateDerniereValorisation: string;
    /**
     * Précise la situation d'un contrat :
     * '0'        devis
     * '1'        contrat en cours
     * '2'        contrat mis en demeure
     * '3'        contrat suspendu
     * '4'        contentieux
     * '6'        contrat résilié
     * '7'        résilié non paiement
     * '9'        AFN sans effet
     */
    codeSituationContrat: string;
    /**
     * Précise la situation d'un contrat :
     * '0'        devis
     * '1'        contrat en cours
     * '2'        contrat mis en demeure
     * '3'        contrat suspendu
     * '4'        contentieux
     * '6'        contrat résilié
     * '7'        résilié non paiement
     * '9'        AFN sans effet
     */
    libelleSituationContrat: string;
    /**
     * Indique si ce produit peut avoir un montant de garanti
     */
    indicateurMontantGaranti: boolean;
  }

  export interface ICompteur {
    /**
     * Numéro de l'entité titulaire comptabilisé
     */
    numeroET: number;
    /**
     * Code permettant d'identifier l'univers comptabilisé
     */
    codeUnivers: string;
    /**
     * Nombre de produits ouverts pour l'univers et l'entité titulaire
     */
    nombreProduitOuvert: number;
    /**
     * Nombre de produits fermés pour l'univers et l'entité titulaire
     */
    nombreProduitFerme: number;
    /**
     * Nombre de produits devis pour l'univers et l'entité titulaire
     */
    nombreProduitDevis: number;
    /**
     * Cumul des soldes des produits ouverts pour l'univers et l'entité titulaire
     */
    cumulSolde: number;
    /**
     * Cumul des impayés des produits ouverts pour l'univers et l'entité titulaire
     */
    cumulImpayes: number;
    /**
     * Cumul des cantonnements des produits ouverts pour l'univers et l'entité titulaire
     */
    cumulCantonnement: number;
    /**
     * Cumul des gel surendettement des produits ouverts pour l'univers et l'entité titulaire
     */
    cumulGelSurendettement: number;
    /**
     * Cumul de la trésorerie du client (PRO)
     */
    cumulTresorerie: number;
    /**
     * Cumul des montants de collecte du client (PRO)
     */
    cumulCollecte: number;
    /**
     * Cumul des crédits du client (PRO)
     */
    cumulCredit: number;
    /**
     * Cumul des encours de carte
     */
    cumulEnCoursCarte: number;
  }

  export interface IGroupeEntiteTitulaire {
    listeEntiteTitulaire: Array<IEntiteTitulaire>;
    /**
     * Nombre de produit actif tout univers et toute entité titulaire
     */
    compteurTotal: ICompteur;
    /**
     * Nombre de produit clos tout univers et toute entité titulaire
     */
    compteurToutETCompte: ICompteur;
    compteurToutETEpargne: ICompteur;
    compteurToutETCredit: ICompteur;
    compteurToutETAssurance: ICompteur;
    compteurToutETPrevoyance: ICompteur;
    compteurToutETService: ICompteur;
  }

  export interface IProduitServiceClient {
    entiteTitulairePrive: IGroupeEntiteTitulaire;
    entiteTitulairePro: IGroupeEntiteTitulaire;
    banqueADistanceEtDigitale: IBanqueADistanceEtDigitale;
    repartitionEpargne: IRepartitionEpargne;
    listeEnCoursPlacement: Array<IEnCoursPlacement>;
  }

  export interface IChequier {
    /**
     * Libellé du service
     */
    libelle: string;
    /**
     * Code de l'établissement du service
     */
    codeEtablissement: string;
    /**
     * Code du guichet du service
     */
    codeGuichet: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Clé RIB du service, calculé dans la ressource
     */
    clefRIB: string;
    /**
     * Indique l'état du produit :
     * '0'        Produit/Service ouvert
     * '1'        Cloture demandée
     * '2'        Cloture en cours
     * '3'        Produit/Service fermé
     * '8'        Produit/Service en cours d'ouverture
     * '9'        Versements non autorisés
     * 'A'        En attente d'activation par le client
     */
    codeEtat: string;
    /**
     * Indique si le mode d'envoi des chéquiers est manuel ou automatique :
     * 'O'        Paramètres de renouvellement automatique pour un type
     * 'N'        de chéquier donné
     * 'D'        Paramètres par défaut du compte
     */
    indicateurRenouvellementAuto: string;
    /**
     * Défini le mode de routage des chéquier
     */
    libelleRoutage: string;
    /**
     * "Auto (*libelleRoutage*)" si indicateurRenouvellementAuto est à O
     * "Manuel (*libelleRoutage*)" si  indicateurRenouvellementAuto est à N
     * "(*libelleRoutage*)" si indicateurRenouvellementAuto est à D
     */
    libelleRenouvellement: string;
    /**
     * Indique si le service a été créé dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'offre dans laquelle est inclus le service
     */
    numeroOffre: number;
    /**
     * Libellé de l'offre
     */
    libelleOffre: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Code definissant le service. "KCHE" pour lesz chéquiers.
     */
    codeProduit: string;
    /**
     * Identifiant du type de l'offre dans laquelle le service est inclus
     */
    identifiantOffre: number;
    /**
     * Libellé personnalisé du compte de dépot
     */
    libellePersonnaliseCDD: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Numéro de l'entité titulaire à laquelle le service est rattaché
     */
    numeroET: number;
  }

  export interface IService {
    listeCarte: Array<ICarte>;
    listeChequier: Array<IChequier>;
    listeOptimisationTresorerie: Array<IOptimisationTresorerie>;
    listeCoffreFortNumerique: Array<ICoffreFortNumerique>;
    listeCoffre: Array<ICoffre>;
    listeVirement: Array<IVirement>;
    listeAutreService: Array<IAutreService>;
    listeContratVision: Array<IContratVision>;
    listeAlerteEcureuil: Array<IAlerteEcureuil>;
    listeWebProtexion: Array<IWebProtexion>;
    listeCertificatNumerique: Array<ICertificatNumerique>;
    listeCiDailly: Array<ICiDailly>;
    listeAbonnementTelephonePRO: Array<IAbonnementTelephonePRO>;
    listeAbonnementInternetPRO: Array<IAbonnementInternetPRO>;
    listeMonetique: Array<IMonetique>;
    listeEpargneSalariale: Array<IEpargneSalariale>;
    listeRMPNumerise: Array<IRMPNumerise>;
  }

  export interface ICarte {
    /**
     * Libellé du service
     */
    libelle: string;
    /**
     * Code de l'établissement du service
     */
    codeEtablissement: string;
    /**
     * Code du guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du compte de prélèvement
     */
    codeProduitCompte: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Clé RIB du service, calculé dans la ressource
     */
    clefRIB: string;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Indique si le service a été créé dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Composé de "Dans l'offre " + libellé de l'offre
     */
    libelleOffre: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Code definissant le service.
     */
    codeProduit: string;
    /**
     * Identifiant du type de l'offre dans laquelle le service est inclus
     */
    identifiantOffre: number;
    /**
     * Numéro de la carte
     */
    numeroCarte: string;
    /**
     * Date d'expiration de la carte
     * Type date au format yyyy-MM-dd
     */
    dateExpirationG: string;
    /**
     * Désignation du porteur de la carte
     */
    designationPorteur: string;
    /**
     * Indique si le client est titulaire de la carte :
     * True -> Titulaire
     * False -> Autre titulaire
     */
    indicateurTitulaire: boolean;
    /**
     * précise si les paiements effectués par une carte
     * donnée sont débités immédiatement ou différés au
     * mois suivant :
     * 'I'        carte à débit immédiat
     * 'D'        carte à débit différé
     */
    codeTypeDebit: string;
    /**
     * En cours sur la carte à débit différée
     */
    enCours: number;
    /**
     * Indique si l'option E-Carte est activée
     * True -> Option E-Carte activée
     * False -> Option E-Carte non activée
     */
    indicateurECarteBleue: boolean;
    /**
     * Indique si la carte est activée :
     * True -> Active
     * False -> A activer
     */
    indicateurActivation: boolean;
    /**
     * Date d'activation de la carte
     * Type date au format yyyy-MM-dd
     */
    dateActivation: string;
    /**
     * Code produit national du service
     */
    codeProduitNational: string;
    /**
     * XXXX XXXX XXXX et les 4 derniers caractères du numéro de carte
     */
    numeroCarteMasque: string;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Idenbfiant definissant le type de service
     */
    identifiantTypeService: number;
    /**
     * Date d'expiration au format MMSSAA
     */
    dateExpirationC: number;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Numero de l'offre dans laquelle le produit est inclus
     */
    numeroOffre: number;
    /**
     * Date d'expiration au format MM/AA
     */
    expireLe: string;
    /**
     * Date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * 'P'        Porteur
     * 'D'        Demandeur
     */
    codePorteur: string;
    /**
     * Libellé personnalisé du cdd support de la carte
     */
    libellePersonnaliseCDD: string;
  }

  export interface IOptimisationTresorerie {
    /**
     * Code de l'établissement du compte débité
     */
    codeEtablissementDebit: string;
    /**
     * Code du guichet du compte deéité
     */
    codeGuichetDebit: string;
    /**
     * Code produit du compte débité
     */
    codeProduitDebit: string;
    /**
     * Numéro du compte débité
     */
    numeroCompteDebit: string;
    /**
     * Cléf RIB du compte débité
     */
    clefRIBDebit: string;
    /**
     * Libellé du service
     */
    libelle: string;
    /**
     * Numéro de l'entité titulaire à laquelle appartient le service
     */
    numeroET: number;
    /**
     * Code de l'établissement du compte crédité
     */
    codeEtablissementCredit: string;
    /**
     * Code du guichet du compte crédité
     */
    codeGuichetCredit: string;
    /**
     * Code produit du compte crédité
     */
    codeProduitCredit: string;
    /**
     * Numéro du compte crédité
     */
    numeroCompteCredit: string;
    /**
     * Cléf RIB du compte crédité
     */
    clefRIBCredit: string;
    /**
     * Identifiant de l'offre dans laquelle le service est inclus
     */
    identifiantOffre: number;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été souscrit dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Numéro de l'offre dans laquelle le service est inclus
     */
    numeroOffre: number;
    /**
     * Code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Montant transferé par le service
     */
    montantTransfert: number;
    /**
     * Montant du seuil de déclenchement du transfert
     */
    seuilDeclenchement: number;
    /**
     * Code de la periodicité
     */
    codePeriodicite: string;
    /**
     * Périodicité du transfert
     */
    libellePeriodicite: string;
    /**
     * Idenbfiant definissant le type de service
     */
    identifiantTypeService: number;
    /**
     * Libellé de l'offre dans laquelle le service est inclus
     */
    libelleOffre: string;
    dateOuverture: string;
  }

  export interface ICoffreFortNumerique {
    /**
     * Numéro du coffre
     */
    numeroCoffre: string;
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Numéro de l'entité titulaire
     */
    numeroET: number;
    /**
     * Numéro de l'offre contenant le service
     */
    numeroOffre: number;
    /**
     * Code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Identifiant de l'offre contenant le service
     */
    identifiantOffre: number;
    /**
     * Libelle de l'offre contenant le service
     */
    libelleOffre: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * Sous-code du service
     */
    sousCodeService: string;
    /**
     * Date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si il existe une opposition
     */
    indicateurOpposition: boolean;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le coffre est:
     * vide -> false
     * Alimenté -> true
     */
    statut: boolean;
    /**
     * Identifiant du coffre
     */
    identifiantCoffre: string;
    /**
     * Indique si le service a été créé dans la journée
     */
    indicateurNouveauService: boolean;
  }

  export interface IAutreService {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    /**
     * Code du type de service
     */
    codeTypeService: string;
  }

  export interface ICoffre {
    /**
     * code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Numéro de l'entité titulaire à laquelle le service est rattaché
     */
    numeroET: number;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Numéro du coffre
     */
    numeroCoffre: string;
    /**
     * Identifie le type de coffre:
     * A-Z
     */
    codeTypeCoffre: string;
    /**
     * Numéro de la salle où se situe le coffre
     */
    numeroSalleDuCoffre: number;
    /**
     * Indique si il s'agit d'un petit, moyen ou grand coffre
     */
    tailleCoffre: string;
    /**
     * Identifiant de l'EDS dans laquelle est situé le coffre
     */
    identifiantEDSDomiciliation: number;
    /**
     * Désignation de l'EDS dans laquelle est situé le coffre
     */
    designationEDSDomiciliation: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Date de cloture
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
  }

  export interface IVirement {
    /**
     * Libellé du service
     */
    libelle: string;
    /**
     * Code de l'établissement du service
     */
    codeEtablissement: string;
    /**
     * Code du guichet du service
     */
    codeGuichet: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Clé RIB du service, calculé dans la ressource
     */
    clefRIB: string;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Indique si le service a été créé dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Composé de "Dans l'offre " + libellé de l'offre
     */
    libelleOffre: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Code definissant le service.
     */
    codeProduit: string;
    /**
     * Identifiant du type de l'offre dans laquelle le service est inclus
     */
    identifiantOffre: number;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Idenbfiant definissant le type de service
     */
    identifiantTypeService: number;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Numero de l'offre dans laquelle le produit est inclus
     */
    numeroOffre: number;
    /**
     * Date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Numéro du service virement
     */
    numeroVirement: string;
  }

  export interface IContratVision {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroContrat: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de fin du service
     * Type date au format yyyy-MM-dd
     */
    dateEcheance: string;
    /**
     * libellé du contrat
     */
    libelleContrat: string;
    /**
     * Tarif annuel
     */
    tarifAnnuel: number;
    /**
     * Montant de la commission CE annuelle
     */
    montantCommissionAnnuelle: number;
    /**
     * Montant du chiffre d'affaire assurable
     */
    montantChiffreAffaireAssurable: number;
    /**
     * Code produit national
     */
    codeNational: string;
    dateCloture: string;
  }

  export interface IBanqueADistanceEtDigitale {
    /**
     * Indique l'état du service Banque à Distance :
     * '0'        actif
     * '1'        bloqué suite 5 tentatives d'accès erronées
     * '2'        bloqué suite 3 réponses Q/R secrètes erronées
     * '3'        bloqué suite 3 saisies sceau électronique erronées
     * '9'        clôturé
     */
    codeEtatBaD: string;
    /**
     * Indique l'état du service Banque à Distance :
     * '0'        actif
     * '1'        bloqué suite 5 tentatives d'accès erronées
     * '2'        bloqué suite 3 réponses Q/R secrètes erronées
     * '3'        bloqué suite 3 saisies sceau électronique erronées
     * '9'        clôturé
     */
    libelleEtatBaD: string;
    /**
     * Identifiant du service Banque à Distance
     */
    identifiantBaD: string;
    /**
     * Date de dernière connexion au service Banque à Distance du client
     */
    dateDerniereConnexionBaD: string;
    /**
     * Indique l'état du service MSI :
     * 'A'        Active
     * 'S'        Suspendue
     * 'C'        Close
     * 'N'       Non souscrit
     */
    codeEtatMSI: string;
    /**
     * Libellé dependant du codeEtatMSI :
     * 'A'        Active
     * 'S'        Suspendue
     * 'C'        Close
     * 'N'       Non souscrit
     */
    libelleEtatMSI: string;
    /**
     * Indique l'état du service e-document :
     * 'S'        Souscrit
     * 'N'        Non souscrit
     * 'R'        Refusé
     * 'P'        Refusé depuis plus d'un an
     * 'C'        Clos
     */
    codeEtatEDocument: string;
    /**
     * Libellé dépendant de codeEtatEDocument :
     * 'S'        Souscrit
     * 'N'        Non souscrit
     * 'R'        Refusé
     * 'P'        Refusé depuis plus d'un an
     * 'C'        Clos
     */
    libelleEtatEDocument: string;
    /**
     * Date de souscription ou de refus selon l'état
     * Type date au format yyyy-MM-dd
     */
    dateSouscriptionEDocument: string;
    /**
     * Date de dernier refus e-document
     * Type date au format yyyy-MM-dd
     */
    dateDernierRefusEDocument: string;
    /**
     * Date de cloture du service e-document
     * Type date au format yyyy-MM-dd
     */
    dateClotureEDocument: string;
    /**
     * Indique si le client a souscrit l'OPT'In SMS
     */
    indicateurSouscriptionOPTInSMS: boolean;
    /**
     * Indique si le client a souscrit l'OPT'In SMS
     */
    libelleSouscriptionOptInSMS: string;
    /**
     * Indique si le client a souscrit l'OPT'In Mail
     */
    indicateurSouscriptionOPTInMail: boolean;
    /**
     * Indique si le client a souscrit l'OPT'In Mail
     */
    libelleSouscriptionOptInMail: string;
    /**
     * Indique l'état du service :
     * true = Actif
     * False = Inactif
     */
    codeEtatPayLib: boolean;
    /**
     * Indique l'état du service SOL SMS
     */
    codeEtatSOLSMS: string;
    /**
     * Indique l'état du service SOL SMS
     */
    libelleEtatSOLSMS: string;
    /**
     * Indique l'état du service SOL CAP
     */
    codeEtatSOLCAP: string;
    /**
     * Indique l'état du service SOL CAP
     */
    libelleEtatSOLCAP: string;
    /**
     * Indique l'état du service Sécur' Pass
     */
    codeEtatSecurPass: string;
    /**
     * Indique l'état du service Sécur' Pass
     */
    libelleEtatSecurPass: string;
    /**
     * Indique si le service SOL est bloqué
     */
    codeBlocageSOL: string;
    /**
     * Indique si le service Paiement mobile est actif
     */
    indicateurPaiementMobile: boolean;
    paiementMobilesSpecifiques: Array<IPaiementMobileSpecifique>;
  }

  export interface IEDocument {
    /**
     * Indique si le service est actif ou clos
     */
    codeEtatService: string;
    /**
     * Indique si le client a refusé le service
     */
    indicateurRefus: string;
    /**
     * Date de souscription
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * Date de refus
     * Type date au format yyyy-MM-dd
     */
    dateRefus: string;
    /**
     * Date de clôture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
  }

  export interface IAlerteEcureuil {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre dans laquelle le service est inclus
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Liste des numéros de téléphones associées au service
     */
    listeNumeroTelephone: Array<ITelephoneAlerteEcureuil>;
    /**
     * Code du type de service
     */
    codeTypeService: string;
  }

  export interface ITelephoneAlerteEcureuil {
    /**
     * Numéro de telephone de contact
     */
    numeroTelephone: string;
    /**
     * Numéro de l'alerte Ecureuil concerné
     */
    numeroCompte: string;
    /**
     * 'B'      Bloqué
     * 'V'      Valide
     */
    codeStatut: string;
    /**
     * Indique si le client consulté est titulaire de l'alerte Ecureuil
     */
    indicateurTitulaire: boolean;
  }

  export interface IPaiementMobileSpecifique {
    /**
     * Libellé du service de paiement mobile
     */
    libelleService: string;
    /**
     * Indique si le service est actif
     */
    indicateurActivationService: boolean;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
  }

  export interface IWebProtexion {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    /**
     * Numéro de l'usager principal
     */
    numeroUsagerPrincipal: number;
    /**
     * Designation de l'usager principal
     */
    designationUsagerPrincipal: string;
    /**
     * Libellé de l'origine du blocage
     */
    libelleOrigineBlocage: string;
  }

  export interface ICertificatNumerique {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroSerie: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateFinValiditeCertificat: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    /**
     * Numéro du client porteur du certificat
     */
    numeroPorteur: number;
    /**
     * Désignation du porteur du certificat sous la forme monsieur/madame nom prenom
     */
    designationPorteur: string;
  }

  export interface ICiDailly {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    codeFinancement: string;
    libelleFinancement: string;
  }

  export interface IAbonnementTelephonePRO {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    /**
     * Identifiant du client abonné
     */
    identifiantClient: string;
  }

  export interface IAbonnementInternetPRO {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    /**
     * Identifiant du client souscripteur
     */
    identifiantClient: string;
    /**
     * Code statut de l'abonnement
     */
    codeStatutAbonnement: string;
    /**
     * Date de dernière connexion au service
     * Type date au format yyyy-MM-dd
     */
    dateDerniereConnexion: string;
    /**
     * Numéro de l'administrateur
     */
    numeroAdministrateur: number;
    /**
     * Désignation de l'administrateur
     */
    designationAdministrateur: string;
    /**
     * Numéro de l'utilisateur Principal
     */
    numeroUtilisateurPrincipal: number;
    /**
     * Désignation de l'utilisateur principal
     */
    designationUtilisateurPrincipal: string;
    libelleRoleUtilisateur: string;
    libelleOption: string;
    libelleEtatAbonnement: string;
    dateEtatAbonnement: string;
    libelleOperation: string;
    libelleOrigineBlocage: string;
  }

  export interface IDonneeEntreprise {
    /**
     * Numéro de l'entité titulaire à laquelle est rattaché le produit
     */
    numeroET: number;
    /**
     * Numéro de SIREN pour les entreprises
     */
    numeroSIREN: string;
    /**
     * Numéro de SIRET pour les entreprises
     */
    numeroSIRET: string;
  }

  export interface ICumulRepartition {
    /**
     * Cumul des soldes des assurances vie
     */
    assuranceVie: number;
    /**
     * Cumul des soldes des épargnes liquides
     */
    epargneLiquide: number;
    /**
     * Cumul des soldes des épargnes logement
     */
    epargneLogement: number;
    /**
     * Cumul des soldes des comptes titre
     */
    titre: number;
    /**
     * Cumul de la trésorerie
     */
    tresorerie: number;
    /**
     * Cumul des soldes des épargne contractuelles
     */
    epargneContractuelle: number;
    /**
     * Cumul des soldes des épargnes autre
     */
    autreEpargne: number;
  }

  export interface IRepartitionEpargne {
    vueCollaborateur: ICumulRepartition;
    avoirsVueClient: ICumulRepartition;
    epargneVueClient: ICumulRepartition;
  }

  export interface IEnCoursPlacement {
    /**
     * Code famille de produit
     */
    codeFamille: string;
    /**
     * Code sous-famille de produit
     */
    codeSousFamille: string;
    /**
     * Cumul par sous-famille de produit
     */
    cumulParSousFamille: number;
    /**
     * Pourcentage par sous-famille de produit
     */
    pourcentageSousFamille: number;
    /**
     * Libellé de la sous famille
     */
    libelleSousFamille: string;
  }

  export interface IMonetique {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    /**
     * Libellé du type de contrat monétique
     */
    libelleTypeContrat: string;
    /**
     * Liste des options souscrites pour le contrat
     */
    listeLibelleOption: Array<string>;
    /**
     * Code établissement du compte de versement
     */
    codeEtablissementVersement: string;
    /**
     * Code guichet du compte de versement
     */
    codeGuichetVersement: string;
    /**
     * Numéro de compte de versement
     */
    numeroCompteVersement: string;
    /**
     * Clé RIb du compte de versement
     */
    cleRIBVersement: string;
  }

  export interface IEpargneSalariale {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    /**
     * Date d'arrêté
     * Type date au format yyyy-MM-dd
     */
    dateArrete: string;
    /**
     * Libellé court du contrat
     */
    libelleCourtContrat: string;
    /**
     * Capital restant dû
     */
    capitalRestantDu: number;
    /**
     * libellé de l'établissement pilote
     */
    libelleEtablissementPilote: string;
    libelleCourtNomenclature: string;
  }

  export interface IRMPNumerise {
    /**
     * Code de l'établissement
     */
    codeEtablissement: string;
    /**
     * Code guichet du service
     */
    codeGuichet: string;
    /**
     * Code produit du service
     */
    codeProduit: string;
    /**
     * Numéro de compte du service
     */
    numeroCompte: string;
    /**
     * Cléf RIB
     */
    clefRIB: string;
    /**
     * Libellé du service
     */
    libelleService: string;
    /**
     * Identifiant du type de service
     */
    identifiantTypeService: number;
    /**
     * Numero de l'offre dans laquelle est le service
     */
    numeroOffre: number;
    /**
     * Identifiant de l'offre dans laquelle est le service
     */
    identifiantOffre: number;
    /**
     * Libellé de l'offre dans laquelle est le service
     */
    libelleOffre: string;
    /**
     * Indique si le produit fait partit d'une offre ou non:
     * True -> Hors Offre
     * False -> dans une offre
     */
    indicateurHorsOffre: boolean;
    /**
     * Indique si le service a été ouvert dans la journée
     */
    indicateurNouveauService: boolean;
    /**
     * Indique si il existe une opposition sur le service
     */
    indicateurOpposition: boolean;
    /**
     * Numéro de l'entité titulaire de rattachement
     */
    numeroET: number;
    /**
     * Indique l'état du produit :
     * '3'        Produit/Service fermé
     * 'A'        Devis/Simulation
     * Autre    Ouvert/Actif
     */
    codeEtat: string;
    /**
     * code état de l'offre
     */
    codeEtatOffre: string;
    /**
     * Date de souscription du service
     * Type date au format yyyy-MM-dd
     */
    dateSouscription: string;
    /**
     * date de cloture du service
     * Type date au format yyyy-MM-dd
     */
    dateCloture: string;
    /**
     * Indique si le service doit apparaitre dans le bloc Banque à Distance
     */
    indicateurBaD: boolean;
    /**
     * Détermine le média support de l'acte de gestion
     * 'A'        automatique
     * 'P'        Poste de travail (agence)
     * 'V'        Vente multi-canal
     * 'W'       Internet fixe
     * 'S'        Internet en mode sécurisé
     * 'X'        Internet mobile
     * 'M'        Enrôlement des mineurs
     */
    codeCanal: string;
    /**
     * Détermine le média support de l'acte de gestion
     * 'A'        automatique
     * 'P'        Poste de travail (agence)
     * 'V'        Vente multi-canal
     * 'W'       Internet fixe
     * 'S'        Internet en mode sécurisé
     * 'X'        Internet mobile
     * 'M'        Enrôlement des mineurs
     */
    libelleCanal: string;
    /**
     * Date de début de validité
     * Type date au format yyyy-MM-dd
     */
    dateDebutValidite: string;
  }
}
