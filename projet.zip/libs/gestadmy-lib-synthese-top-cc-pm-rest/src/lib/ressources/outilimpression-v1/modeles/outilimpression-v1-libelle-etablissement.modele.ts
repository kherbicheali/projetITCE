export namespace RessourceOutilimpressionV1LibelleEtablissement {
  export interface ILibelleEtablissement {
    /**
     * restitue le nom de l'établissement en minuscule ex: "Caisse d'Epargne"
     */
    libelleMinuscule: string;
    /**
     * restitue le nom de l'établissement en majuscule ex: "CAISSE D'EPARGNE"
     */
    libelleMajuscule: string;
    /**
     * Determine le genre du nom d'établissement : "F" : Féminin / "M" : Masculin / "N" : Neutre
     */
    genreNomEtablissement: string;
    /**
     * URL de l'établissement ex: "www.credit-cooperatif.com"
     */
    url: string;
    /**
     * Nom du service internet ex: "DIRECT ECUREUIL"
     */
    nomServiceInternet: string;
    /**
     * Libellé avec les articles "de la" et "du" en minuscule
     */
    articleMinusculeDeLaDu: string;
    /**
     * Libellé avec les articles "a la" et "au" en minuscule
     */
    articleMinusculeALaAu: string;
    /**
     * Libellé avec les articles "la" et "le" en minuscule
     */
    articleMinusculeLaLe: string;
    /**
     * Libellé avec les articles "sa" et "son" en minuscule
     */
    adjectifMinusucleSaSon: string;
    /**
     * Libellé avec les articles "de la" et "du" en majuscule
     */
    articleMajusculeDeLaDu: string;
    /**
     * Libellé avec les articles "a la" et "au" en majuscule
     */
    articleMajusculeALaAu: string;
    /**
     * Libellé avec les articles "la" et "le" en majuscule
     */
    articleMajusculeLaLe: string;
    /**
     * Libellé avec les articles "sa" et "son" en majuscule
     */
    adjectifMajusculeSaSon: string;
    /**
     * Article "de la" et "du" sur le réseau ex : "du réseau des Caisse d'Epargne"
     */
    articleReseauDeLaDu: string;
    /**
     * Restitue le libellé du service relation clientèle avec les articles  "de la" ou "du" ou "de son"
     */
    articleServiceRelCliDeLaDuDeSon: string;
    /**
     * Restitue le libellé du service relation clientèle avec les articles  "à la" ou "au" ou "à son"
     */
    articleServiceRelCliALaAuASon: string;
    /**
     * Code etablissement
     */
    codeEtablissement: string;
    /**
     * Article la/le à mettre devant le nom d'établissement
     */
    articleLaLe: string;
    /**
     * Article a la/au à mettre devant le nom d'établissement
     */
    articleALaAu: string;
    /**
     * Article de la/du à mettre devant le nom d'établissement
     */
    articleDeLaDu: string;
    /**
     * Libellé long de l'établissement
     */
    etablissementLibelleLong: string;
  }
}
