import { Inject, Injectable } from '@angular/core';
import { ENVIRONMENT, Environment } from '@myway/env';
import { RequestHttpAgentService } from '@ptmyway-stc-v2/request-http-agent';
import { Observable } from 'rxjs';
import { RessourceOutilimpressionV1LibelleEtablissement } from '../modeles/outilimpression-v1-libelle-etablissement.modele';

/**
 * La ressource libelle etablissement permet de gerer les libelles d'édition des établissement
 */
@Injectable({
  providedIn: 'root'
})
export class OutilimpressionV1LibelleEtablissementService {
  constructor(private requestHttpAgentService: RequestHttpAgentService, @Inject(ENVIRONMENT) private env: Environment) {}

  /**
   * Cette méthode permet de restituer les différent libellé d'édition associé au établissement
   * @param codeEtablissement Identifiant d'un Etablissement du RCE.
   * Correspond au code Banque sous lequel une Caisse ou un Etablissement du réseau CE est répertoriée par la Banque de France.
   * @returns Retourne l'ensemble des libellé d'édition associé à un établissement
   */
  public getLibelleEtablissement(
    codeEtablissement: string
  ): Observable<RessourceOutilimpressionV1LibelleEtablissement.ILibelleEtablissement> {
    return this.requestHttpAgentService.get(`${this.env.urlRest}/outilimpression/v1/libelleEtablissement/`, {
      codeEtablissement: `${codeEtablissement}`
    });
  }
}
