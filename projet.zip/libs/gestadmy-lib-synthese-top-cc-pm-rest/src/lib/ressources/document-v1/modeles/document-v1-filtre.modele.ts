export namespace RessourceDocumentV1Filtre {
  export interface IAttributaire {
    /**
     * CodeTypeAttrb
     */
    codeType: string;
    /**
     * IdntAttrb
     */
    id: string;
    /**
     * IdntAttrSecn
     */
    idSecondaire: string;
  }

  export interface IFiltrerDocumentInput {
    contexteFiltre: IContexteFiltre;
    criteresRestitutionFiltre: ICriteresRestitutionFiltre;
    criteresRechercheFiltre: ICriteresRechercheFiltre;
  }

  export interface IContexteFiltre {
    codeEtablissement: string;
    sujets: Array<string>;
  }

  export interface ICriteresRestitutionFiltre {
    /**
     * C ou D
     */
    ordreTri: string;
    nbDocumentMax: number;
    topAnnotation: boolean;
    /**
     * Date sur laquelle porte le tri. Valeurs possibles:
     * 1 : Date de création FileNet
     * 2 : Date de gestion
     * 3 : Date de numérisation
     * 4 : Date de délivrance
     */
    codeDateTri: string;
  }

  export interface ICriteresRechercheFiltre {
    attributaire: IAttributaire;
  }

  export interface IFiltrerDocumentOutput {
    indicateurCompletude: string;
    nombreDocuments: number;
    documents: Array<IDocumentFiltre>;
  }

  export interface IDocumentFiltre extends IBaseDocument {
    nomFichier: string;
    tailleDocument: number;
  }

  export interface IBaseDocument {
    codeEtablissement: string;
    idDocument: string;
    idLot: string;
    codeApplication: string;
    moyenAcquisition: string;
    origineAcquisition: string;
    agentAcquisition: string;
    codeNature: string;
    libelleNature: string;
    typeAttributaire: string;
    idAttributaire: string;
    idAttributaireSecondaire: string;
    dateCreation: string;
    dateModification: string;
    dateDelivrance: string;
    dateNumerisation: string;
    dateCollecte: string;
    datePeremption: string;
    dateFinValidite: string;
    numeroUnitePhysique: string;
    positionUnitePhysique: number;
    intituleAttributaire: string;
    dateAttributaire: string;
    referencePosteFonctionAcquisition: string;
    descriptionDocument: string;
    codeTypeStockage: string;
    codeAccessibilite: number;
    topAnnotation: boolean;
    methodeSignature: string;
  }

  export interface IPostFiltrerDocumentInput {
    donneesContextuelles: IDonneesContextuelles;
    critereFiltreDocument: ICritereFiltreDocument;
    criterePeriode: ICriteresPeriodeFiltre;
    critereRestitution: ICriteresRestitutionFiltre;
  }

  export interface IDonneesContextuelles {
    /**
     * code Etablissement
     */
    codeEtablissement: string;
    /**
     * code application GED
     */
    codeApplication: string;
    /**
     * liste des sujets
     */
    listeSujets: Array<string>;
    /**
     * liste des natures
     */
    listeNatures: Array<string>;
  }

  export interface ICritereFiltreDocument {
    /**
     * User d'acquistion d'acquisition du document
     */
    utilisateurAcquisition: string;
    /**
     * Donne l'espace où sera réalisé la recherche :
     * 0 : Espace d'archivage et transitoire
     * 1 : Espace d'archivage
     * 2 : Espace transitoire
     * 3 : Espace temporaire
     */
    codeTypeStockage: string;
    /**
     * attributaires de recherche
     */
    listeAttributaires: Array<IAttributaire>;
    /**
     * represente EDS de l'utilisateur
     */
    referencePosteFonctionnelAcq: string;
  }

  export interface ICriteresPeriodeFiltre {
    /**
     * Date sur laquelle porte la période de recherche
     * 1  : Date de création FileNet
     * 2  : Date de gestion
     * 3  : Date de numérisation
     * 4  : Date de délivrance
     */
    codeDateFiltre: string;
    /**
     * Borne inférieure
     * Type date au format yyyy-MM-dd
     */
    dateDebutPeriode: string;
    /**
     * Borne supérieure
     * Type date au format yyyy-MM-dd
     */
    dateFinPeriode: string;
  }
}
