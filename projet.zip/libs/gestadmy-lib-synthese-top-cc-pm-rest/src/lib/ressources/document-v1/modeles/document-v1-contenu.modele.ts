export namespace RessourceDocumentV1Contenu {
  export interface IProprietesDoc {
    /**
     * CodeEtablissement
     */
    codeEtablissement: string;
    /**
     * IdntPJ
     */
    idDocument: string;
    /**
     * IdntLot
     */
    idLot: string;
    /**
     * IdntCmpstApplf
     */
    codeApplication: string;
    /**
     * CodeTypeModeAcqs
     */
    moyenAcquisition: string;
    /**
     * CodeTypeOrigAcqs
     */
    origineAcquisition: string;
    /**
     * RefrAgntAcqs
     */
    agentAcquisition: string;
    /**
     * CodeTypeNatrDoc
     */
    codeNature: string;
    /**
     * LibelleNatrDoc
     */
    libelleNature: string;
    /**
     * CodeTypeAttrb
     */
    typeAttributaire: string;
    /**
     * IdntAttrb
     */
    idAttributaire: string;
    /**
     * IdntAttrSecn
     */
    idAttributaireSecondaire: string;
    /**
     * DateCrtn
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateCreation: string;
    /**
     * DateModification
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateModification: string;
    /**
     * DateDeliv
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateDelivrance: string;
    /**
     * DateNumr
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateNumerisation: string;
    /**
     * DateColt
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateCollecte: string;
    /**
     * DatePerm
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    datePeremption: string;
    /**
     * DateFinVald
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateFinValidite: string;
    /**
     * NumUnitePhysique
     */
    numeroUnitePhysique: string;
    /**
     * PosUnitePhysique
     */
    positionUnitePhysique: number;
    /**
     * InttAttr
     */
    intituleAttributaire: string;
    /**
     * DateAttr
     * Type date au format yyyy-MM-dd'T'HH:mm:ss.SSSZ
     */
    dateAttributaire: string;
    /**
     * RefrPosteFoncAcqs
     */
    referencePosteFonctionAcquisition: string;
    /**
     * DescDoc
     */
    descriptionDocument: string;
    /**
     * CodeTypeStck
     */
    codeTypeStockage: string;
    /**
     * CodeForcAccs
     */
    codeAccessibilite: number;
    /**
     * CodeTypeSign
     */
    methodeSignature: string;
    /**
     * TopAnnotation
     */
    topAnnotation: boolean;
  }

  export interface IConsulterDocumentOutput {
    fichier: IFichier;
    details: IDetails;
    annotations: Array<IAnnotation>;
  }

  export interface IFichier {
    nom: string;
    taille: number;
    contenu: string;
  }

  // tslint:disable-next-line: no-empty-interface
  export interface IDetails extends IProprietesDoc {}

  export interface IAnnotation {
    id: string;
    contenu: string;
  }

  export interface IConsulterDocumentInput {
    /**
     * CodeEtablissement
     */
    codeEtablissement: string;
    /**
     * IdntCmpstApplf
     */
    codeApplication: string;
    /**
     * IdntPJ
     */
    idDocument: string;
    /**
     * IndicRecupDoc
     */
    indicateurDocument: boolean;
    /**
     * IndicRecupDetl
     */
    indicateurDetails: boolean;
    /**
     * IndicPrscAnnt
     */
    indicePresenceAnnotation: boolean;
    /**
     * IndicRecupAnnt
     */
    indiceRecuperationAnnotation: boolean;
  }
}
