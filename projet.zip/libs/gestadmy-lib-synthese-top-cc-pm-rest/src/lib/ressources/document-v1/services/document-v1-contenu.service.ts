import { Inject, Injectable } from '@angular/core';
import { ENVIRONMENT, Environment } from '@myway/env';
import { RequestHttpAgentService } from '@ptmyway-stc-v2/request-http-agent';
import { Observable } from 'rxjs';
import { RessourceDocumentV1Contenu } from '../modeles/document-v1-contenu.modele';

@Injectable({
  providedIn: 'root'
})
export class DocumentV1ContenuService {
  constructor(private requestHttpAgentService: RequestHttpAgentService, @Inject(ENVIRONMENT) private env: Environment) {}

  public getDocument(codeApplication: string, idDocument: string): Observable<RessourceDocumentV1Contenu.IConsulterDocumentOutput> {
    return this.requestHttpAgentService.get(`${this.env.urlRest}/document/v1/contenu/`, {
      codeApplication: `${codeApplication}`,
      idDocument: `${idDocument}`
    });
  }
}
