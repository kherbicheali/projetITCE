import { Inject, Injectable } from '@angular/core';
import { ENVIRONMENT, Environment } from '@myway/env';
import { RequestHttpAgentService } from '@ptmyway-stc-v2/request-http-agent';
import { Observable } from 'rxjs';
import { RessourceDocumentV1Filtre } from '../modeles/document-v1-filtre.modele';

@Injectable({
  providedIn: 'root'
})
export class DocumentV1FiltreService {
  constructor(private requestHttpAgentService: RequestHttpAgentService, @Inject(ENVIRONMENT) private env: Environment) {}

  public getDocumentsFiltres(
    codeApplication: string,
    idPersonne: string,
    codeTypePersonne: string
  ): Observable<RessourceDocumentV1Filtre.IFiltrerDocumentOutput> {
    return this.requestHttpAgentService.get(`${this.env.urlRest}/document/v1/filtre/`, {
      codeApplication: `${codeApplication}`,
      idPersonne: `${idPersonne}`,
      codeTypePersonne: `${codeTypePersonne}`
    });
  }
}
