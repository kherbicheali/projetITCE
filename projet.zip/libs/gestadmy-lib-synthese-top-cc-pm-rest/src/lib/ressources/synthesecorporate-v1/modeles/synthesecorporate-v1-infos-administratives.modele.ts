/* tslint:disable:max-line-length */
export namespace RessourceSynthesecorporateV1InfosAdministratives {
  export interface InfosAdmin {
    /**
     * Le code établissement / le numéro de l'établissement / numéro agence CE du client.
     */
    codeEtablissement: string;
    /**
     * Le numéro de personne / identifiant client.
     */
    numeroPersonne: number;
    /**
     * La raison sociale
     */
    raisonSociale: string;
    /**
     * Le numéro SIREN.
     */
    numeroSiren: string;
    /**
     * Infos personne mise en suivi
     */
    suiviPar: string;
    /**
     * permet d'aiguiller vers les QR concernées.
     *
     * 0 : Personne connue comme client
     * 1 : Personne connue comme Tiers
     * 2 : Personne connue comme prospect
     * 3 : Personne connue comme Prospect enrichi
     */
    codeTypePersonne: string;
    codeMarche: CodeMarche;
    /**
     * AdresseSiege
     */
    adresses: Adresse;
    /**
     * interlocuteurPrincipal
     */
    interlocuteurPrincipal: InterlocuteurPrincipal;
    segmentRelationnelle: SegmentRelationnelle;
    /**
     * le code catégorie juridique INSEE
     */
    codeJuridique: string;
    /**
     * L'état de la personne (Clôturée / Active), ce champ peut prendre deux valeurs :
     *    - 0 pour personne active
     *    - 1 pour personne clôturée
     */
    etatPersonne: string;
    /**
     * Le Libelle Code NAF rev2 INSEE
     */
    libelleCodeNAF: string;
    /**
     * Le code NAF INSEE
     */
    codeNAF: string;
    /**
     * Le Libellé Elément Structure
     */
    libelleElementStructure: string;
    /**
     * L'Identifiant externe client
     */
    identifiantExterneClient: string;
    /**
     * La date de la première entrée en relation
     * Type date au format yyyy-MM-dd
     */
    datePremiereEntreeRelation: string;
    /**
     * Dénomination commerciale se rapportant à un fonds de commerce exploité par une société ou assimilée Dénomination vis à vis de la clientèle. Peut correspondre à l'enseigne. Une société peut avoir un nom commercial différent pour chacun des fonds de commerce qu'elle exploite Exemples : La Samaritaine, But ...
     */
    nomCommercialProfessionnel: string;
    /**
     * Numéro d'identification de la relation économique dans le SI d'un Etablissement sur la plateforme Mysys Une relation économique est le regroupement de plusieurs personnes ayant un lien familial et/ou économique entre elles.
     */
    idtRelationEconomique: number;
    /**
     * Désignation de la relation formaté en fonction de la composition du dossier ME
     */
    libelleIntituleRelation: string;
  }
  export interface AdresseSiege {
    /**
     * La ligne 2 permet d'indiquer le point de remise ou un complément d'identification du destinataire. La ligne 2 correspond à tout ce qui est situé à l'intérieur d'un bâtiment, cela peut être l'indication d'étage, d'appartement, de porte, de numéro de boite aux lettres, etc.
     */
    ligne2Adresse: string;

    /**
     * La ligne 3 permet d'indiquer le point de remise (informations complémentaires de distribution). La ligne 3 correspond à tout ce qui est à l'extérieur du bâtiment (entrée, bâtiment, bloc, tour etc.)
     */
    ligne3Adresse: string;

    /**
     * La ligne 4 permet d'identifier la voie de destination. Peut comprendre, le numéro dans la voie, type et nom de voie, le nom d'une résidence ou d'un ensemble immobilier qui ne peut être assimilé à une commune ou à un lieu-dit, un service X, une boîte postale ou un numéro de CEDEX.
     */
    ligne4Adresse: string;

    /**
     * La ligne 5 permet d'identifier la destination. Peut comprendre, le nom d'un quartier, d'un lieu-dit, d'un hameau, le nom d'un ensemble immobilier pouvant être assimilé à une commune ou à un lieu-dit et possédant plusieurs voies internes.
     */
    ligne5Adresse: string;

    /**
     * La ligne 6 permet d'identifier la destination. Peut comprendre, le numéro de code postal et nom de la localité, le numéro de code spécifique et nom de la localité complétés éventuellement par la mention CEDEX.
     */
    ligne6Adresse: string;

    /**
     * Cette propriété permet de distinguer le type d'adresse.
     */
    typeAdresse: string;

    /**
     * Numéro chrono professionnel
     */
    numPro: number;

    /**
     * Numéro chrono lieu activité
     */
    numLieuAct: number;
  }
  export interface InterlocuteurPrincipal {
    /**
     * La Désignation courte
     */
    designationCourte: string;

    /**
     * L'Adresse E-MAIL
     */
    adresseEmail: string;

    /**
     * Le Numéro téléphone 1
     */
    telephoneFixe: string;

    /**
     * Le Numéro téléphone 2
     */
    telephonePortable: string;

    /**
     * Libellé type de role d'interlocuteur
     */
    typeRole: string;
  }
  export interface AdresseCorrespondance {
    /**
     * La ligne 2 permet d'indiquer le point de remise ou un complément d'identification du destinataire. La ligne 2 correspond à tout ce qui est situé à l'intérieur d'un bâtiment, cela peut être l'indication d'étage, d'appartement, de porte, de numéro de boite aux lettres, etc.
     */
    ligne2Adresse: string;

    /**
     * La ligne 3 permet d'indiquer le point de remise (informations complémentaires de distribution). La ligne 3 correspond à tout ce qui est à l'extérieur du bâtiment (entrée, bâtiment, bloc, tour etc.)
     */
    ligne3Adresse: string;

    /**
     * La ligne 4 permet d'identifier la voie de destination. Peut comprendre, le numéro dans la voie, type et nom de voie, le nom d'une résidence ou d'un ensemble immobilier qui ne peut être assimilé à une commune ou à un lieu-dit, un service X, une boîte postale ou un numéro de CEDEX.
     */
    ligne4Adresse: string;

    /**
     * La ligne 5 permet d'identifier la destination. Peut comprendre, le nom d'un quartier, d'un lieu-dit, d'un hameau, le nom d'un ensemble immobilier pouvant être assimilé à une commune ou à un lieu-dit et possédant plusieurs voies internes.
     */
    ligne5Adresse: string;

    /**
     * La ligne 6 permet d'identifier la destination. Peut comprendre, le numéro de code postal et nom de la localité, le numéro de code spécifique et nom de la localité complétés éventuellement par la mention CEDEX.
     */
    ligne6Adresse: string;

    /**
     * Cette propriété permet de distinguer le type d'adresse.
     */
    typeAdresse: string;

    /**
     * Numéro chrono professionnel
     */
    numPro: number;

    /**
     * Numéro chrono lieu activité
     */
    numLieuAct: number;
  }
  export interface CodeMarche {
    /**
     * Code Marché de la personne.
     * Exemple : MN 101102 / Particuliers : Particuliers non Professionnels MN 102102 / Professionnels : Professions Libérales MN 206101 / Professionnels Privé : Promoteurs
     */
    codeMarche: string;

    /**
     * Libellé de désignation d'un segment clientèle.
     */
    libelleLongCodeMarche: string;

    /**
     * Libellé court de la segmentation clientèle pour affichage sur le poste de travail. Libellé à caractère confidentiel pour ne pas être interprété par la clientèle.
     */
    libelleCourtCodeMarche: string;

    /**
     * Ce libellé permet de restituer le libellé de la famille du code marché.
     * Exemple :
     * 101 : Particuliers
     */
    libelleFamilleCodeMarche: string;
  }
  export interface Adresse {
    adresseSiege: AdresseSiege;

    adresseCorrespondance: AdresseCorrespondance;
  }
  export interface SegmentRelationnelle {
    /**
     * Le code segment
     */
    codeSegment: string;

    /**
     * Libellé de désignation d'un segment clientèle.
     */
    libelleLongSegment: string;

    /**
     * Libellé court de la segmentation clientèle pour affichage sur le poste de travail. Libellé à caractère confidentiel pour ne pas être interprété par la clientèle.
     */
    libelleCourtSegment: string;

    /**
     * Ce libellé permet de restituer le libellé de la famille du code marché.
     * Exemple :
     * 101 : Particuliers
     */
    libelleFamilleSegment: string;
  }
  export interface Interlocuteur {
    /**
     * La Désignation courte
     */
    designationCourte: string;

    /**
     * L'Adresse E-MAIL
     */
    adresseEmail: string;

    /**
     * Le Numéro téléphone 1
     */
    telephoneFixe: string;

    /**
     * Le Numéro téléphone 2
     */
    telephonePortable: string;

    /**
     * Ce champ représente le type d'interlocuteur.
     * Il peut prendre comme valeur:
     * *  'P' pour interlocuteur principal de la personne moral ou PRO.
     * *  'U' pour interlocuteur défini comme utilisateur espace Unique.
     * * 'C' interlocuteur principal & utilisateur Espace Unique.
     */
    typeInterlocuteur: string;

    /**
     * Libellé type de role d'interlocuteur
     */
    typeRole: string;
  }
}
