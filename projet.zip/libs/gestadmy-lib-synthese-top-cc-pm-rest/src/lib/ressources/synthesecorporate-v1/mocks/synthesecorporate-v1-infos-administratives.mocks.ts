// tslint:disable-next-line: max-line-length
import { RessourceSynthesecorporateV1InfosAdministratives } from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';

export namespace RessourceMockSynthesecorporateV1InfosAdministratives {
  export const infoAdminitrativesRestMock: RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin = {
    codeEtablissement: '13135',
    numeroPersonne: 9052457,
    raisonSociale: 'SOYCXNO BOVNY',
    numeroSiren: '936380062',
    suiviPar: 'BRUNO BOURGEOIS DE LA REPUBLIQUE',
    codeTypePersonne: '0',
    codeNAF: '2030Z',
    libelleCodeNAF: null,
    datePremiereEntreeRelation: '1995-04-28',
    identifiantExterneClient: '3111586098',
    libelleElementStructure: 'PME PMI COMPTES HGA ET LA SUITE ICI',
    nomCommercialProfessionnel: 'SOYCXNO BOVNY',
    libelleGroupeLocal: 'TEST',
    codeMarche: {
      codeMarche: 'MN',
      libelleLongCodeMarche: 'ENT : GE - Grandes Entreprises (50 M\u0080 <= CA < 100 M\u0080)',
      libelleCourtCodeMarche: 'GE 50-100M\u0080',
      libelleFamilleCodeMarche: 'PME-PMI'
    },
    adresses: {
      adresseSiege: {
        ligne2Adresse: null,
        ligne3Adresse: 'ZONE INDUSTRIELLE',
        ligne4Adresse: '1    RUE DENIS PAPIN',
        ligne5Adresse: null,
        ligne6Adresse: '09100 PAMIERS',
        typeAdresse: '1',
        numPro: 1,
        numLieuAct: 1
      },
      adresseCorrespondance: {
        ligne2Adresse: null,
        ligne3Adresse: 'ZONE INDUSTRIELLE',
        ligne4Adresse: '1    RUE DENIS PAPIN',
        ligne5Adresse: null,
        ligne6Adresse: '09100 PAMIERS',
        typeAdresse: '1',
        numPro: 1,
        numLieuAct: 1
      }
    },
    interlocuteurPrincipal: {
      designationCourte: 'MR BENOIT MAES',
      adresseEmail: 'XXX@YY.COM',
      telephoneFixe: '00270561679745',
      telephonePortable: '0611111111',
      typeRole: 'TEST'
    },
    segmentRelationnelle: {
      codeSegment: 'BM',
      libelleLongSegment: 'A Développer',
      libelleCourtSegment: 'A_DEVP',
      libelleFamilleSegment: null
    },
    codeJuridique: '5710',
    etatPersonne: '0'
  };
}
