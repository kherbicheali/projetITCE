/* istanbul ignore file */
import { Inject, Injectable } from '@angular/core';
import { Environment, ENVIRONMENT } from '@myway/env';
import { RequestHttpAgentService } from '@ptmyway-stc-v2/request-http-agent';
import { Observable } from 'rxjs';
import { RessourceSynthesecorporateV1InfosAdministratives } from '../modeles/synthesecorporate-v1-infos-administratives.modele';

/**
 * Cette ressource permet de restituer, de mettre à jour les informations relatives aux données administratives d'un client.
 * Pour le segment relationnel, nous utilisons un code en entrée de la Qr D440.
 * Cette QR nous permet de remonter les informations du segment relationnel d'un client.
 * Car la Qr D440 est aussi utilisée par d'autres ressources  dans d'autres projets.
 * Ainsi pour permettre à la Qr de distinguer les appels provenant de la ressource infosAdministrative,
 * nous avons fixé par défaut la valeur de la rubrique  D440.DCSU7A.CODLTS à 99.
 */
@Injectable({
  providedIn: 'root'
})
export class SynthesecorporateV1InfosAdministrativesService {
  constructor(private requestHttpAgentService: RequestHttpAgentService, @Inject(ENVIRONMENT) private env: Environment) {}

  /**
   * Méthode de restitution des informations administratives
   * @param codeEtablissement Identifiant d'un Etablissement correspond au code Banque sous lequel
   * une Caisse ou un Etablissement du réseau CE est répertoriée par la Banque de France.
   * @param identifiantPersonne Numéro d'identification dans le SI d'un Etablissement.
   * @param modeTraitement si modeTraitement = "M" lancement des traitements en multiThread
   * @returns Renvoie les informations administratives.
   */
  public getInfosAdmin(
    codeEtablissement: string,
    identifiantPersonne: number,
    modeTraitement?: string
  ): Observable<RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin> {
    return this.requestHttpAgentService.get(`${this.env.urlRest}/synthesecorporate/v1/infosAdministratives/`, {
      codeEtablissement: `${codeEtablissement}`,
      identifiantPersonne: `${identifiantPersonne}`
    });
    // Bouchon
    // return of(RessourceMockSynthesecorporateV1InfosAdministratives.infoAdminitrativesRestMock);
  }
}
