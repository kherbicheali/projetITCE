module.exports = {
  name: 'gestadmy-app-synthese-top-cc-pm',
  preset: '../../jest-angular.config.js',
  coverageDirectory: '../../coverage/apps/gestadmy-app-synthese-top-cc-pm',
  snapshotSerializers: ['jest-preset-angular/build/AngularSnapshotSerializer.js', 'jest-preset-angular/build/HTMLCommentSerializer.js'],
  coveragePathIgnorePatterns: ['apps/gestadmy-app-synthese-top-cc-pm/src/environments/*']
};
