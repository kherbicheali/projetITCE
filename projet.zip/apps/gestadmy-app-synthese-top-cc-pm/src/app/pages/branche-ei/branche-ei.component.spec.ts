import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { DialogService, NotificationService } from '@myway/ui';
import { NgxsModule, Store } from '@ngxs/store';
import { ErrorMessage } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { of } from 'rxjs';
import { PROCESSUS_LISA_SORTIE } from '../../shared/constantes/lisa.constantes';
import { IContexte } from '../../shared/modeles/contexte.model';
import { AbstractMockObservableService } from '../../shared/services/utils/abstract-mock-observable.service';
import { HeaderUtilsService } from '../../shared/services/utils/header-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { DonneesAdministrativesState } from '../../shared/states/donnees-administratives/donnees-administratives.state';
import { BrancheEIComponent } from './branche-ei.component';

class LisaAgentMockService extends AbstractMockObservableService {
  next(param: { exitValue: number }) {
    return this;
  }
}

describe('BrancheEIComponent', () => {
  let fixture: ComponentFixture<BrancheEIComponent>;
  let component: BrancheEIComponent;
  let notificationService: NotificationService;
  const lisaAgentServiceStub = new LisaAgentMockService();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BrancheEIComponent],
      imports: [NgxsModule.forRoot([ContexteState])],
      providers: [
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {} }
        },
        {
          provide: LisaAgentService,
          useValue: lisaAgentServiceStub
        },
        {
          provide: NotificationService,
          useValue: { openInfo: () => {} }
        },
        {
          provide: ContexteState,
          useValue: { getContent: () => {}, isLoaded: () => {} }
        },
        {
          provide: DonneesAdministrativesState,
          useValue: { isLoading: () => {} }
        },
        {
          provide: HeaderUtilsService,
          useValue: { getTitle: () => {}, onHeaderActionClicked: () => {} }
        },
        {
          provide: Router,
          useValue: { navigate: () => {} }
        },
        {
          provide: DialogService,
          useValue: { openStandard: () => {} }
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();

    notificationService = TestBed.inject(NotificationService);
    lisaAgentServiceStub.error = null;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrancheEIComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'dataContexte$', { writable: true });
    component.dataContexte$ = of(mockDonneesContexte);
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it('init component sans contexte', () => {
    const spyStore = spyOn(component['store'], 'dispatch');
    component.dataContexte$ = of(undefined);
    component.ngOnInit();
    expect(spyStore).not.toHaveBeenCalled();
  });

  it('init component choix redirection top cc pm deja fait', () => {
    const spyStore = spyOn(component['store'], 'dispatch');
    component.dataContexte$ = of(mockDonneesContexteAvecChoix);
    component.ngOnInit();
    expect(spyStore).not.toHaveBeenCalled();
  });

  it('init component avec contexte', () => {
    const spyStore = spyOn(component['store'], 'dispatch');
    component.ngOnInit();
    expect(spyStore).toHaveBeenCalled();
  });

  it("debranche vers le sortie de l'application avec succès", () => {
    lisaAgentServiceStub.content = {};
    const spyNotifService = jest.spyOn(notificationService, 'openInfo');
    const spyLisa = jest.spyOn(lisaAgentServiceStub, 'next');
    component.quitterApplication();
    fixture.detectChanges();
    expect(spyLisa).toHaveBeenCalledWith({ exitValue: PROCESSUS_LISA_SORTIE });
    expect(spyNotifService).not.toHaveBeenCalledWith('Erreur de sortie du processus');
  });

  it("debranche vers le sortie de l'application en erreur", () => {
    lisaAgentServiceStub.error = { libelle: '' } as ErrorMessage;
    const spyNotifService = jest.spyOn(notificationService, 'openInfo');

    const spyLisa = jest.spyOn(lisaAgentServiceStub, 'next');
    component.quitterApplication();
    fixture.detectChanges();
    expect(spyLisa).toHaveBeenCalledWith({ exitValue: PROCESSUS_LISA_SORTIE });
    expect(spyNotifService).toHaveBeenCalledWith('Erreur de sortie du processus');
  });
});

const mockDonneesContexte: IContexte = {
  identifiantPersonne: '9038489',
  codeEtablissement: '13135',
  estPersonnePhysique: true,
  choixTopCCPM: false
} as IContexte;

const mockDonneesContexteAvecChoix: IContexte = {
  identifiantPersonne: '9038489',
  codeEtablissement: '13135',
  estPersonnePhysique: true,
  choixTopCCPM: true
} as IContexte;
