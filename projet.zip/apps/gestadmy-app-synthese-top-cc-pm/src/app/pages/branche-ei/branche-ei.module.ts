import { NgModule } from '@angular/core';
import { MatRadioModule } from '@angular/material/radio';
import { MyWayFooterModule, MyWayHeaderModule, MyWayLabelModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { BrancheEIComponent } from './branche-ei.component';
import { ModaleChoixEIModule } from './modale-choix/modale-choix-ei.module';

@NgModule({
  declarations: [BrancheEIComponent],
  imports: [SharedModule, MyWayHeaderModule, MyWayFooterModule, MatRadioModule, MyWayLabelModule, ModaleChoixEIModule]
})
export class BrancheEIModule {}
