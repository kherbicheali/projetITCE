import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DialogService, IFooterActions, NotificationService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ErrorMessage } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PROCESSUS_LISA_SORTIE } from '../../shared/constantes/lisa.constantes';
import { IContexte } from '../../shared/modeles/contexte.model';
import { HeaderUtilsService } from '../../shared/services/utils/header-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { LoadCouleurTopCCPP } from '../../shared/states/couleur-top-cc-pp/couleur-top-cc-pp.actions';
import { LoadDonneesAdministratives } from '../../shared/states/donnees-administratives/donnees-administratives.actions';
import { DonneesAdministrativesState } from '../../shared/states/donnees-administratives/donnees-administratives.state';
import { LoadDonneesTopCC } from '../../shared/states/donnees-top-cc/donnees-top-cc.actions';
import { ModaleChoixEIComponent } from './modale-choix/modale-choix-ei.component';

@Component({
  templateUrl: './branche-ei.component.html',
  styleUrls: ['./branche-ei.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BrancheEIComponent implements OnInit, OnDestroy {
  @Select(ContexteState.getContent) dataContexte$: Observable<IContexte>;
  @Select(ContexteState.isLoaded) isContexteLoaded$: Observable<boolean>;
  @Select(DonneesAdministrativesState.isLoading) donneesAdminIsLoading$: Observable<boolean>;
  private unsubscribe$ = new Subject<void>();
  public estPersonnePhysique: boolean;
  public choixDebranchementTopCC: string;
  public footerActions: IFooterActions[];

  constructor(
    private store: Store,
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    public headerUtilsService: HeaderUtilsService,
    private router: Router,
    private modal: DialogService
  ) {}

  ngOnInit() {
    this.footerActions = [
      { label: 'Annuler', class: 'btn-secondary' },
      { label: 'Valider', class: 'btn-primary' }
    ];

    this.dataContexte$.pipe(takeUntil(this.unsubscribe$)).subscribe((result: IContexte) => {
      if (result) {
        if (result.estPersonnePhysique && !result.choixTopCCPM) {
          this.estPersonnePhysique = result.estPersonnePhysique;
          this.store.dispatch(
            new LoadDonneesAdministratives(result.codeEtablissement, result.identifiantPersonne, this.estPersonnePhysique)
          );
          this.store.dispatch(new LoadDonneesTopCC(result.codeEtablissement, result.identifiantPersonne, this.estPersonnePhysique));
          this.store.dispatch(new LoadCouleurTopCCPP(result.codeEtablissement, result.identifiantPersonne));
          this.modal.openStandard<ModaleChoixEIComponent>(ModaleChoixEIComponent, { width: '50rem' });
        } else {
          this.router.navigate(['main-page']);
        }
      }
    });
  }

  public quitterApplication() {
    this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_SORTIE }).subscribe(
      (result: LisaCallbackResult) => {},
      (erreur: ErrorMessage) => {
        this.notification.openInfo('Erreur de sortie du processus');
      }
    );
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
