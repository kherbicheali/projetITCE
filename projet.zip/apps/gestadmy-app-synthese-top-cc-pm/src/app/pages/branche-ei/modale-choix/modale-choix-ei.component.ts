import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DialogRef, NotificationService } from '@myway/ui';
import { Select } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { ErrorMessage, StorageLevel } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ERREUR_REST_COULEUR_TOPCC_PM, ERREUR_REST_COULEUR_TOPCC_PP } from '../../../shared/constantes/ihm.constantes';
import { CONTEXTE_CHOIX_TOPCC_PM, PROCESSUS_LISA_SORTIE, PROCESSUS_TOPCC_PP } from '../../../shared/constantes/lisa.constantes';
import { IDonneesTopCC } from '../../../shared/modeles/donnees-top-cc.modele';
import { CouleurTopCCPPState } from '../../../shared/states/couleur-top-cc-pp/couleur-top-cc-pp.state';
import { DonneesTopCCState } from '../../../shared/states/donnees-top-cc/donnees-top-cc.state';

@Component({
  selector: 'gestadmy-modale-choix-ei',
  templateUrl: './modale-choix-ei.component.html',
  styleUrls: ['./modale-choix-ei.component.scss']
})
export class ModaleChoixEIComponent implements OnInit, OnDestroy {
  private estFermeAvecCroix: boolean;
  public couleurTopCCPM: string;
  public couleurTopCCPP: string;
  @Select(DonneesTopCCState.getContent) donneesTopCC$: Observable<IDonneesTopCC>;
  @Select(DonneesTopCCState.isLoading) isLoadingTopCCPM$: Observable<boolean>;
  @Select(DonneesTopCCState.getError) errorTopCCPM$: Observable<HttpErrorResponse>;
  @Select(CouleurTopCCPPState.getContent) couleurTopCCPP$: Observable<string>;
  @Select(CouleurTopCCPPState.isLoading) isLoadingTopCCPP$: Observable<boolean>;
  @Select(CouleurTopCCPPState.getError) errorTopCCPP$: Observable<HttpErrorResponse>;
  private unsubscribe$ = new Subject<void>();
  public texteErreurRestCouleurTopCCPM: string = ERREUR_REST_COULEUR_TOPCC_PM;
  public texteErreurRestCouleurTopCCPP: string = ERREUR_REST_COULEUR_TOPCC_PP;

  constructor(
    private dialogRef: DialogRef,
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    private router: Router,
    private contextAgentService: ContextAgentService
  ) {}

  ngOnInit() {
    this.estFermeAvecCroix = true;

    this.donneesTopCC$.pipe(takeUntil(this.unsubscribe$)).subscribe((resultPM: IDonneesTopCC) => {
      if (resultPM) {
        this.couleurTopCCPM = resultPM.couleurTopCC ? resultPM.couleurTopCC : 'B';
      }
    });

    this.couleurTopCCPP$.pipe(takeUntil(this.unsubscribe$)).subscribe((resultPP: string) => {
      this.couleurTopCCPP = resultPP ? resultPP : 'B';
    });
  }

  debranchementTopCCPM() {
    this.estFermeAvecCroix = false;
    this.dialogRef.close();
    this.contextAgentService
      .addToContext({
        key: CONTEXTE_CHOIX_TOPCC_PM,
        value: 'O',
        storageLevel: StorageLevel.Process
      })
      .subscribe(() => {
        this.router.navigate(['main-page']);
      });
  }

  debranchementTopCCPP() {
    this.estFermeAvecCroix = false;
    this.lisaAgentService.next({ exitValue: PROCESSUS_TOPCC_PP }).subscribe(
      (result: LisaCallbackResult) => {},
      (erreur: ErrorMessage) => {
        this.notification.openInfo('Erreur de débranchement vers la Synthèse Top CC Particulier');
      }
    );
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
    if (this.estFermeAvecCroix) {
      this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_SORTIE }).subscribe(
        (result: LisaCallbackResult) => {},
        (erreur: ErrorMessage) => {
          this.notification.openInfo('Erreur de sortie du processus');
        }
      );
    }
  }
}
