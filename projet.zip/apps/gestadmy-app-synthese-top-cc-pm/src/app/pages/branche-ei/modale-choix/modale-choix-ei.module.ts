import { NgModule } from '@angular/core';
import { MyWayBadgeModule, MyWayCardModule, MyWayDialogModule, MyWaySvgIconModule } from '@myway/ui';
import { SharedModule } from '../../../shared/shared.module';
import { ModaleChoixEIComponent } from './modale-choix-ei.component';

@NgModule({
  declarations: [ModaleChoixEIComponent],
  imports: [SharedModule, MyWayDialogModule, MyWayBadgeModule, MyWayCardModule, MyWaySvgIconModule]
})
export class ModaleChoixEIModule {}
