import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import {
  DocumentV1ContenuService,
  DocumentV1FiltreService,
  RessourceDocumentV1Filtre,
  RessourceTiersCorporateV1CorporateTiersLies,
  TiersCorporateV1CorporateTiersLiesService,
  ClasseurclientV1RechercheService,
  RessourceClasseurclientV1Recherche,
  ClasseurclientV1DossierReglementaireClientService,
  RessourceClasseurclientV1DossierReglementaireClient
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { DialogService, NotificationService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { ErrorMessage, IAuthentificationInfo, StorageLevel } from '@ptmyway-stc-v2/core-common';
import { HabilitationAgentService } from '@ptmyway-stc-v2/habilitation-agent';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { LIBELLE_BOUTON_VALIDER, LIBELLE_COULEUR_TOPCC_BLANC } from '../../shared/constantes/ihm.constantes';
import {
  NEXT_CLASSEUR_CLIENT,
  NEXT_DIGITALSHARE,
  NEXT_SORTIE,
  PROCESSUS_LISA_DIGITAL_SHARE,
  PROCESSUS_LISA_SORTIE
} from '../../shared/constantes/lisa.constantes';
import { IContexte } from '../../shared/modeles/contexte.model';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { DataUtilsService } from '../../shared/services/utils/data-utils.service';
import { HeaderUtilsService } from '../../shared/services/utils/header-utils.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { LoadDonneesAdministratives } from '../../shared/states/donnees-administratives/donnees-administratives.actions';
import { DonneesAdministrativesState } from '../../shared/states/donnees-administratives/donnees-administratives.state';
import { LoadDonneesClientParticulier } from '../../shared/states/donnees-client-particulier/donnees-client-particulier.actions';
import { LoadDonneesCorporate } from '../../shared/states/donnees-corporate/donnees-corporate.actions';
import { DonneesCorporateState } from '../../shared/states/donnees-corporate/donnees-corporate.state';
import { LoadDonneesEai } from '../../shared/states/donnees-eai/donnees-eai.actions';
import { DonneesEaiState } from '../../shared/states/donnees-eai/donnees-eai.state';
import { LoadDonneesLiens } from '../../shared/states/donnees-liens/donnees-liens.actions';
import { DonneesLiensState } from '../../shared/states/donnees-liens/donnees-liens.state';
import { LoadDonneesNatureRelation } from '../../shared/states/donnees-nature-relation/donnees-nature-relation.actions';
import { DonneesNatureRelationState } from '../../shared/states/donnees-nature-relation/donnees-nature-relation.state';
import { LoadDonneesTopCC, ValiderDonneesTopCC } from '../../shared/states/donnees-top-cc/donnees-top-cc.actions';
import { DonneesTopCCState } from '../../shared/states/donnees-top-cc/donnees-top-cc.state';
import { ModaleValidationComponent } from './modale-validation/modale-validation.component';
import { IAlerte } from '../../shared/modeles/alerte.modele';
import { IParamGenerate } from '@ptmyway-stc-v2/impression-common';
import { FicheRevueDocumentService } from '../../shared/gcedoc/fiche-revue';

@Component({
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MainPageComponent implements OnInit, OnDestroy {
  private codeEtablissement: string;
  private identifiantPersonne: string;
  private identifiantAgent: string;
  private estPersonnePhysique: boolean;
  @Select(ContexteState.getContent) dataContexte$: Observable<IContexte>;
  @Select(ContexteState.isLoaded) isContexteLoaded$: Observable<boolean>;
  @Select(DonneesCorporateState.isLoading) isLoadingCorporate$: Observable<boolean>;
  @Select(DonneesNatureRelationState.isLoading) isLoadingNature$: Observable<boolean>;
  @Select(DonneesTopCCState.isLoading) isLoadingTopCCPM$: Observable<boolean>;
  @Select(DonneesAdministrativesState.isLoading) isLoadingAdmin$: Observable<boolean>;
  @Select(DonneesLiensState.isLoading) isLoadingLiens$: Observable<boolean>;
  @Select(DonneesEaiState.isLoading) isLoadingEAI$: Observable<boolean>;
  @Select(DonneesTopCCState.getError) errorTopCCPM$: Observable<HttpErrorResponse>;
  @Select(DonneesCorporateState.getError) errorCorporate$: Observable<HttpErrorResponse>;
  @Select(DonneesNatureRelationState.getError) errorNature$: Observable<HttpErrorResponse>;
  @Select(DonneesEaiState.getError) errorEAI$: Observable<HttpErrorResponse>;
  @Select(DonneesLiensState.getError) errorLiens$: Observable<HttpErrorResponse>;
  @Select(DonneesAdministrativesState.getError) errorAdmin$: Observable<HttpErrorResponse>;

  private isCouleurTopCCLoading: boolean;
  private isDonneesCorporateLoading: boolean;
  private isDonneesNatureLoading: boolean;
  private isDonneesAdminLoading: boolean;
  private isDonneesEAILoading: boolean;
  private isDonneesLiensLoading: boolean;
  private unsubscribe$ = new Subject<void>();
  public validationEnCours: boolean;
  public modaleOuverte: boolean;
  private couleurTopCC: string;
  private erreurStateBlocs: boolean;
  public isDigitalShareDisabled: boolean;
  public estHabiliteDigitalShare: boolean;
  private dernierCracc: RessourceDocumentV1Filtre.IDocumentFiltre;
  public isBoutonRecuperationCraccDisabled: boolean;
  public authentificationInfo: IAuthentificationInfo;

  constructor(
    private store: Store,
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    private contextAgentService: ContextAgentService,
    private lisaUtilsService: LisaUtilsService,
    private alertesTopCCService: AlertesTopCCService,
    private changeDetectionRef: ChangeDetectorRef,
    public headerUtilsService: HeaderUtilsService,
    private modal: DialogService,
    private tiersCorporateV1CorporateTiersLiesService: TiersCorporateV1CorporateTiersLiesService,
    private habilitationAgentService: HabilitationAgentService,
    private documentV1Filtre: DocumentV1FiltreService,
    private documentV1Contenu: DocumentV1ContenuService,
    private dataUtilsService: DataUtilsService,
    private classeurclientV1RechercheService: ClasseurclientV1RechercheService,
    private classeurClientv1DossierReglementaireClientService: ClasseurclientV1DossierReglementaireClientService
  ) {}

  ngOnInit() {
    this.isDigitalShareDisabled = true;
    this.isBoutonRecuperationCraccDisabled = true;
    this.changeDetectionRef.detectChanges();
    this.dataContexte$.pipe(takeUntil(this.unsubscribe$)).subscribe((result: IContexte) => {
      if (result) {
        this.codeEtablissement = result.codeEtablissement;
        this.identifiantPersonne = result.identifiantPersonne;
        this.estPersonnePhysique = result.estPersonnePhysique;
        this.identifiantAgent = result.identifiantAgent;
        this.authentificationInfo = result.authentificationInfo;

        if (this.codeEtablissement && this.identifiantPersonne) {
          this.controleDossierDRCExistant();
          this.store.dispatch(new LoadDonneesAdministratives(this.codeEtablissement, this.identifiantPersonne, this.estPersonnePhysique));
          this.store.dispatch(new LoadDonneesCorporate(this.codeEtablissement, this.identifiantPersonne, this.estPersonnePhysique));
          if (!this.estPersonnePhysique) {
            this.store.dispatch(new LoadDonneesLiens(this.codeEtablissement, this.identifiantPersonne));
            this.store.dispatch(new LoadDonneesEai(this.codeEtablissement, this.identifiantPersonne));
          } else {
            this.store.dispatch(new LoadDonneesClientParticulier(this.codeEtablissement, this.identifiantPersonne));
          }
          this.store.dispatch(new LoadDonneesNatureRelation(this.codeEtablissement, this.identifiantPersonne));
          this.store.dispatch(new LoadDonneesTopCC(result.codeEtablissement, result.identifiantPersonne, this.estPersonnePhysique));

          this.documentV1Filtre
            .getDocumentsFiltres('PDC', this.dataUtilsService.leftPadWithZero(this.identifiantPersonne, 9), '2')
            .subscribe((listeDocument: RessourceDocumentV1Filtre.IFiltrerDocumentOutput) => {
              this.dernierCracc = listeDocument.documents.find(doc => {
                return doc.codeNature === 'CRVA';
              });
              if (this.dernierCracc) {
                this.isBoutonRecuperationCraccDisabled = false;
                this.changeDetectionRef.detectChanges();
              }
            });
        }
      }
    });

    this.isLoadingTopCCPM$.subscribe((isLoading: boolean) => {
      this.isCouleurTopCCLoading = isLoading;
      if (!this.isCouleurTopCCLoading) {
        const snapshotTopCC = this.store.selectSnapshot(DonneesTopCCState.getContent);
        if (snapshotTopCC) {
          this.couleurTopCC = snapshotTopCC.couleurTopCC;

          this.tiersCorporateV1CorporateTiersLiesService
            .getAdminUPBAD(this.codeEtablissement, +this.identifiantPersonne)
            .pipe(takeUntil(this.unsubscribe$))
            .subscribe((retourDigitalShare: RessourceTiersCorporateV1CorporateTiersLies.IRestitutionAdminUPBAD) => {
              if (
                this.couleurTopCC !== LIBELLE_COULEUR_TOPCC_BLANC &&
                retourDigitalShare &&
                retourDigitalShare.listeAdminUPBAD &&
                retourDigitalShare.listeAdminUPBAD.length > 0
              ) {
                retourDigitalShare.listeAdminUPBAD.forEach((abonnement: RessourceTiersCorporateV1CorporateTiersLies.IAdminUPBAD) => {
                  if (abonnement.typeAbonnementBad === '2' || abonnement.typeAbonnementBad === '1') {
                    this.isDigitalShareDisabled = false;
                    this.changeDetectionRef.detectChanges();
                  }
                });
              } else {
                this.isDigitalShareDisabled = true;
                this.changeDetectionRef.detectChanges();
              }
            });
        }
      }
    });

    this.isLoadingCorporate$.subscribe((isLoading: boolean) => {
      this.isDonneesCorporateLoading = isLoading;
    });
    this.isLoadingNature$.subscribe((isLoading: boolean) => {
      this.isDonneesNatureLoading = isLoading;
    });
    this.isLoadingAdmin$.subscribe((isLoading: boolean) => {
      this.isDonneesAdminLoading = isLoading;
    });
    if (!this.estPersonnePhysique) {
      this.isLoadingEAI$.subscribe((isLoading: boolean) => {
        this.isDonneesEAILoading = isLoading;
      });
      this.isLoadingLiens$.subscribe((isLoading: boolean) => {
        this.isDonneesLiensLoading = isLoading;
      });
    }

    this.erreurStateBlocs = false;
    this.errorAdmin$.subscribe((err: HttpErrorResponse) => {
      if (err) {
        this.erreurStateBlocs = true;
      }
    });
    this.errorCorporate$.subscribe((err: HttpErrorResponse) => {
      if (err) {
        this.erreurStateBlocs = true;
      }
    });
    if (!this.estPersonnePhysique) {
      this.errorEAI$.subscribe((err: HttpErrorResponse) => {
        if (err) {
          this.erreurStateBlocs = true;
        }
      });
      this.errorLiens$.subscribe((err: HttpErrorResponse) => {
        if (err) {
          this.erreurStateBlocs = true;
        }
      });
    }
    this.errorNature$.subscribe((err: HttpErrorResponse) => {
      if (err) {
        this.erreurStateBlocs = true;
      }
    });
    this.errorTopCCPM$.subscribe((err: HttpErrorResponse) => {
      if (err) {
        this.erreurStateBlocs = true;
      }
    });

    this.habilitationAgentService
      .estHabilite({
        code: ['SHPI05'],
        domaine: 'mysys'
      })
      .subscribe(
        mapHabilitation => {
          this.estHabiliteDigitalShare = mapHabilitation.get('SHPI05');
        },
        (erreur: ErrorMessage) => {
          this.estHabiliteDigitalShare = false;
        }
      );
  }

  public definirBoutonsFooter() {
    let boutonsFooter = [
      { label: 'Annuler', class: 'btn-secondary' },
      { label: LIBELLE_BOUTON_VALIDER, class: 'btn-primary', disabled: true }
    ];
    if (
      !this.isCouleurTopCCLoading &&
      !this.isDonneesCorporateLoading &&
      !this.isDonneesNatureLoading &&
      !this.isDonneesAdminLoading &&
      ((!this.estPersonnePhysique && !this.isDonneesEAILoading && !this.isDonneesLiensLoading) || this.estPersonnePhysique)
    ) {
      boutonsFooter = [
        { label: 'Annuler', class: 'btn-secondary' },
        {
          label: LIBELLE_BOUTON_VALIDER,
          class: 'btn-primary',
          disabled:
            this.alertesTopCCService.filtrerListeAlertesBloquantes().length !== 0 ||
            this.validationEnCours ||
            this.modaleOuverte ||
            this.couleurTopCC === '' ||
            this.couleurTopCC === null ||
            this.couleurTopCC === undefined ||
            this.erreurStateBlocs
        }
      ];
    }
    return boutonsFooter;
  }

  /** Actions des boutons "Valider" et "Annuler" du footer */
  onFooterActionClicked(index: number): void {
    if (index === 0) {
      this.navigationLisa(NEXT_SORTIE);
    } else {
      this.modaleOuverte = true;
      this.validationEnCours = true;
      this.modal.openFullSize<ModaleValidationComponent>(ModaleValidationComponent).subscribe((retour: string) => {
        if (retour === 'Valider') {
          this.modaleOuverte = false;
          this.validationEnCours = false;
          this.changeDetectionRef.detectChanges();

          this.documentV1Filtre
            .getDocumentsFiltres('PDC', this.dataUtilsService.leftPadWithZero(this.identifiantPersonne, 9), '2')
            .subscribe((listeDocument: RessourceDocumentV1Filtre.IFiltrerDocumentOutput) => {
              this.dernierCracc = listeDocument.documents.find(doc => {
                return doc.codeNature === 'CRVA';
              });
              if (this.dernierCracc) {
                this.isBoutonRecuperationCraccDisabled = false;
                this.changeDetectionRef.detectChanges();
              }
            });
        } else {
          this.modaleOuverte = false;
          this.validationEnCours = false;

          this.changeDetectionRef.detectChanges();
        }
      });
    }
  }

  public getDocumentCracc() {
    this.documentV1Contenu.getDocument('PDC', this.dernierCracc.idDocument).subscribe(
      result => {
        const byteCharacters = atob(result.fichier.contenu);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], {
          type: 'application/pdf'
        });
        const navigator: any = window.navigator;
        if (navigator && navigator.msSaveOrOpenBlob) {
          // Si navigateur est IE
          navigator.msSaveOrOpenBlob(blob, 'compteRenduActualisationCc.pdf');
        } else {
          // Si autre navigateur
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          document.body.appendChild(a);
          a.setAttribute('style', 'display: none');
          a.href = url;
          a.download = 'compteRenduActualisationCc.pdf';
          a.click();
          window.URL.revokeObjectURL(url);
          a.remove();
        }
      },
      (erreur) /* istanbul ignore next */ => {
        this.modal.info({
          titleHeader: 'Erreur lors de la récupération du Compte-Rendu Actualisation Connaissance Client',
          messageError: erreur.error?.libelle ? erreur.error.libelle : erreur.message ? erreur.message : ''
        });
        console.log('Erreur lors de la récupération du Compte-Rendu Actualisation Connaissance Client : ' + JSON.stringify(erreur));
      }
    );
  }

  public navigationLisa(destination: string) {
    if (destination === NEXT_SORTIE) {
      this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_SORTIE }).subscribe(
        (result: LisaCallbackResult) => {},
        (erreur: ErrorMessage) => {
          this.notification.openInfo('Erreur de sortie du processus');
        }
      );
    } else if (destination === NEXT_DIGITALSHARE) {
      const keyValuesToAdd: Map<string, any> = new Map<string, any>([
        ['identifiantPersonne', this.identifiantPersonne],
        ['motif', 'TOPCC']
      ]);
      this.contextAgentService
        .addListToContext({
          keyValues: keyValuesToAdd,
          storageLevel: StorageLevel.Process
        })
        .subscribe(
          () => {
            this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_DIGITAL_SHARE }).subscribe(
              (result: LisaCallbackResult) => {},
              (erreur: ErrorMessage) => {
                this.notification.openInfo("Erreur de lancement de l'application Digital Share");
              }
            );
          },
          (erreur: ErrorMessage) => {
            this.notification.openInfo("Erreur d'enregistrement dans le contexte");
          }
        );
    } else if (destination === NEXT_CLASSEUR_CLIENT) {
      this.lisaUtilsService.debrancherVersClasseurClient(this.identifiantPersonne);
    }
  }

  public controleDossierDRCExistant() {
    this.classeurclientV1RechercheService
      .getDossier(this.dataUtilsService.leftPadWithZero(this.identifiantPersonne, 9))
      .subscribe((dossierDRC: RessourceClasseurclientV1Recherche.IRechercherDossierOutput) => {
        if (!dossierDRC?.dossiers?.find(dossier => dossier.codeReferenceExterne === '00')?.idDossier) {
          this.creerDossierDRC();
        }
      });
  }

  public creerDossierDRC() {
    this.classeurClientv1DossierReglementaireClientService
      .putDossierReglementaireClient(<RessourceClasseurclientV1DossierReglementaireClient.DonneesEntree>{
        codeEtablissement: this.codeEtablissement,
        identifiantPersonne: +this.dataUtilsService.leftPadWithZero(this.identifiantPersonne, 9),
        numeroEntiteTitulaire: 0,
        typeDossierReglementaireClient: 'PA',
        identifiantElementStructure: this.authentificationInfo.rattachement.identifiantEds,
        typeElementStructure: this.authentificationInfo.rattachement.typeEds,
        referenceExterneEDS: +this.authentificationInfo.rattachement.referenceExterneEds,
        codeINSEE: '',
        codeCapaciteJuridique: '0',
        indicateurClientBancaire: true,
        modeForce: 'N',
        personnesLiees: 'N',
        aspirationAuto: 'O'
      })
      .subscribe(
        () => {},
        () => {
          this.ajoutAlerteDRCManquant();
        }
      );
  }

  public ajoutAlerteDRCManquant(): void {
    const alerteDRCManquant: IAlerte = {
      message: 'Création DRC impossible',
      isBloquante: true,
      isCreationDRCImpossible: true
    };
    this.alertesTopCCService.ajouterAlerte(alerteDRCManquant);
    this.changeDetectionRef.detectChanges();
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
