import { NgModule } from '@angular/core';
import { MyWayFooterModule, MyWayHeaderModule, MyWayImageButtonModule, MyWayNotificationModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { BlocAlertesModule } from '../../ui/bloc-alertes/bloc-alertes.module';
import { BlocInformationsGeneralesModule } from '../../ui/bloc-informations-generales/bloc-informations-generales.module';
import { BlocInformationsJuridiquesModule } from '../../ui/bloc-informations-juridiques/bloc-informations-juridiques.module';
import { BlocStatutTopCcModule } from '../../ui/bloc-statut-top-cc/bloc-statut-top-cc.module';
import { MainPageComponent } from './main-page.component';
import { ModaleValidationModule } from './modale-validation/modale-validation.module';
@NgModule({
  declarations: [MainPageComponent],
  imports: [
    SharedModule,
    MyWayHeaderModule,
    MyWayFooterModule,
    BlocInformationsGeneralesModule,
    BlocInformationsJuridiquesModule,
    BlocStatutTopCcModule,
    BlocAlertesModule,
    MyWayImageButtonModule,
    MyWayNotificationModule,
    ModaleValidationModule
  ]
})
export class MainPageModule {}
