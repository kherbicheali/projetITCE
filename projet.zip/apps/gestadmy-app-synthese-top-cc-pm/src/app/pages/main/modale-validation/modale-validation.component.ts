import { Component, OnInit } from '@angular/core';
import { DialogRef, DialogService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ImpressionAgentService } from '@ptmyway-stc-v2/impression-agent';
import { IParamGenerate } from '@ptmyway-stc-v2/impression-common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MEDIA_ABSENT, NO_CONTACT_PRINCIPAL } from '../../../shared/constantes/ihm.constantes';
import { FicheRevueDocumentService } from '../../../shared/gcedoc/fiche-revue';
import { IContexte } from '../../../shared/modeles/contexte.model';
import { IDonneesClientParticulier } from '../../../shared/modeles/donnees-client-particulier.modele';
import { DonneesCorporateModele } from '../../../shared/modeles/donnees-corporate.modele';
import { INominationsReglementaires } from '../../../shared/modeles/donnees-liens.modele';
import { InformationsAdministrativesModele as modelDataAdmin } from '../../../shared/modeles/informations-administratives.modele';
import { ContexteState } from '../../../shared/states/contexte/contexte.state';
import { LoadDonneesAdministratives } from '../../../shared/states/donnees-administratives/donnees-administratives.actions';
import { DonneesAdministrativesState } from '../../../shared/states/donnees-administratives/donnees-administratives.state';
import { DonneesClientParticulierState } from '../../../shared/states/donnees-client-particulier/donnees-client-particulier.state';
import { LoadDonneesCorporate } from '../../../shared/states/donnees-corporate/donnees-corporate.actions';
import { DonneesCorporateState } from '../../../shared/states/donnees-corporate/donnees-corporate.state';
import { LoadDonneesEai } from '../../../shared/states/donnees-eai/donnees-eai.actions';
import { LoadDonneesLiens } from '../../../shared/states/donnees-liens/donnees-liens.actions';
import { DonneesLiensState } from '../../../shared/states/donnees-liens/donnees-liens.state';
import { LoadDonneesNatureRelation } from '../../../shared/states/donnees-nature-relation/donnees-nature-relation.actions';
import { ValiderDonneesTopCC, LoadDonneesTopCC } from '../../../shared/states/donnees-top-cc/donnees-top-cc.actions';

@Component({
  selector: 'gestadmy-modale-validation',
  templateUrl: './modale-validation.component.html',
  styleUrls: ['./modale-validation.component.scss']
})
export class ModaleValidationComponent implements OnInit {
  public estPersonnePhysique: boolean;
  @Select(DonneesAdministrativesState.getContent) donneesAdministrative$: Observable<modelDataAdmin.IDonneesAdministratives>;
  @Select(DonneesCorporateState.getActiviteEconomique) donneesActiviteEconomique$: Observable<DonneesCorporateModele.IActiviteEconomique>;
  @Select(DonneesLiensState.getNominationsReglementaires) donneesNominationsReglementaires$: Observable<INominationsReglementaires[]>;
  @Select(DonneesClientParticulierState.getContent) donneesClientPart$: Observable<IDonneesClientParticulier>;
  public coordonnees: modelDataAdmin.IDonneesAdministratives;
  public adresseSiege: string;
  private unsubscribe$ = new Subject<void>();
  public chiffreAffaire: string;
  public exercice: string;
  public contexte: IContexte;
  public listeNominationsReglementaires: INominationsReglementaires[];
  public donneesClientPart: IDonneesClientParticulier;
  public telephonePm: string;
  public textNoContactPrincipal: string;

  constructor(
    private dialogRef: DialogRef,
    private store: Store,
    private impressionAgentService: ImpressionAgentService,
    private ficheRevueDocumentService: FicheRevueDocumentService,
    private dialogService: DialogService
  ) {}

  ngOnInit() {
    this.textNoContactPrincipal = NO_CONTACT_PRINCIPAL;

    this.contexte = this.store.selectSnapshot(ContexteState.getContent);
    this.estPersonnePhysique = this.contexte.estPersonnePhysique;

    this.donneesAdministrative$.pipe(takeUntil(this.unsubscribe$)).subscribe((data: modelDataAdmin.IDonneesAdministratives) => {
      if (data) {
        this.coordonnees = JSON.parse(JSON.stringify(data));
        this.telephonePm =
          data.telephonePortablePm && data.telephonePortablePm !== MEDIA_ABSENT
            ? data.telephonePortablePm
            : data.telephoneFixePm && data.telephoneFixePm !== MEDIA_ABSENT
            ? data.telephoneFixePm
            : MEDIA_ABSENT;
        if (data.adressePrincipale) {
          this.adresseSiege = '';
          this.adresseSiege += data.adressePrincipale.ligne2 ? data.adressePrincipale.ligne2 : '';
          this.adresseSiege += data.adressePrincipale.ligne3
            ? (this.adresseSiege.length !== 0 ? ', ' : '') + data.adressePrincipale.ligne3
            : '';
          this.adresseSiege += data.adressePrincipale.ligne4
            ? (this.adresseSiege.length !== 0 ? ', ' : '') + data.adressePrincipale.ligne4
            : '';
          this.adresseSiege += data.adressePrincipale.ligne5
            ? (this.adresseSiege.length !== 0 ? ', ' : '') + data.adressePrincipale.ligne5
            : '';
          this.adresseSiege += data.adressePrincipale.ligne6
            ? (this.adresseSiege.length !== 0 ? ', ' : '') + data.adressePrincipale.ligne6
            : '';
        }
      }
    });

    this.donneesNominationsReglementaires$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((listeNominations: INominationsReglementaires[]) => {
        if (listeNominations) {
          this.listeNominationsReglementaires = listeNominations;
        }
      });

    this.donneesActiviteEconomique$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((activiteEco: DonneesCorporateModele.IActiviteEconomique) => {
        if (activiteEco) {
          this.chiffreAffaire = activiteEco.chiffreAffaire;
          this.exercice = activiteEco.anneeDernierBilan;
        }
      });

    if (this.estPersonnePhysique) {
      this.donneesClientPart$.pipe(takeUntil(this.unsubscribe$)).subscribe((donneesClientPart: IDonneesClientParticulier) => {
        if (donneesClientPart) {
          this.donneesClientPart = donneesClientPart;
        }
      });
    }
  }

  valider() {
    this.store
      .dispatch(new ValiderDonneesTopCC(this.contexte.codeEtablissement, this.contexte.identifiantPersonne, this.contexte.identifiantAgent))
      .subscribe(
        () => {
          this.genereFicheRevue();

          this.store.dispatch(
            new LoadDonneesAdministratives(this.contexte.codeEtablissement, this.contexte.identifiantPersonne, this.estPersonnePhysique)
          );
          this.store.dispatch(
            new LoadDonneesCorporate(this.contexte.codeEtablissement, this.contexte.identifiantPersonne, this.estPersonnePhysique)
          );
          if (!this.estPersonnePhysique) {
            this.store.dispatch(new LoadDonneesLiens(this.contexte.codeEtablissement, this.contexte.identifiantPersonne));
          }
          this.store.dispatch(new LoadDonneesNatureRelation(this.contexte.codeEtablissement, this.contexte.identifiantPersonne));
          this.store.dispatch(new LoadDonneesEai(this.contexte.codeEtablissement, this.contexte.identifiantPersonne));
          this.store.dispatch(
            new LoadDonneesTopCC(this.contexte.codeEtablissement, this.contexte.identifiantPersonne, this.estPersonnePhysique)
          );
        },
        err => {
          this.store.dispatch(
            new LoadDonneesTopCC(this.contexte.codeEtablissement, this.contexte.identifiantPersonne, this.estPersonnePhysique)
          );
        }
      );
  }

  public genereFicheRevue() {
    const generateParams = {} as IParamGenerate;
    generateParams.generationParams = this.ficheRevueDocumentService.createArchiveSetting();
    // tslint:disable-next-line: max-line-length
    generateParams.generationParams.optionals.archiving.aQstnCreateDoc.document.documentProperties.idntAttrb = `${this.contexte.identifiantPersonne}`.padStart(
      9,
      '0'
    );
    generateParams.generationParams.optionals.archiving.aQstnCreateDoc.contextData.institutionCode = this.contexte.codeEtablissement;
    generateParams.data = this.ficheRevueDocumentService.createDocument(
      this.contexte,
      this.coordonnees,
      this.chiffreAffaire,
      this.exercice,
      this.adresseSiege,
      this.listeNominationsReglementaires,
      this.donneesClientPart
    );
    this.impressionAgentService.generate(generateParams).subscribe(
      result => {
        console.log(`[generatePrint result] => ${JSON.stringify(result)}`);
        this.dialogRef.close('Valider');
      },
      (erreur) /* istanbul ignore next */ => {
        this.dialogService.info({
          titleHeader: 'Erreur lors de la génération du Compte-Rendu Actualisation Connaissance Client',
          messageError: erreur.error?.libelle
            ? erreur.error.libelle
            : erreur.message
            ? erreur.message
            : erreur.libelle
            ? erreur.libelle
            : ''
        });
        console.log('Erreur lors de la génération du document gce doc : ' + JSON.stringify(erreur));
      }
    );
  }

  annuler() {
    this.dialogRef.close();
  }

  /* istanbul ignore next */
  public getLibellePatrimoineImmo(valeurPatrimoineImmo: string) {
    if (Number(valeurPatrimoineImmo) <= 100000) {
      return '0 à 100 000 €';
    } else if (Number(valeurPatrimoineImmo) <= 200000) {
      return '100 001 à 200 000 €';
    } else if (Number(valeurPatrimoineImmo) <= 350000) {
      return '200 001 à 350 000 €';
    } else if (Number(valeurPatrimoineImmo) <= 500000) {
      return '350 001 à 500 000 €';
    } else if (Number(valeurPatrimoineImmo) <= 1000000) {
      return '500 001 à 1 000 000 €';
    } else {
      return 'Plus de 1 000 000 €';
    }
  }

  /* istanbul ignore next */
  public getLibelleEpargne(valeurEpargne: string) {
    if (Number(valeurEpargne) <= 5000) {
      return '0 à 5 000 €';
    } else if (Number(valeurEpargne) <= 25000) {
      return '5 001 à 25 000 €';
    } else if (Number(valeurEpargne) <= 100000) {
      return '25 001 à 100 000 €';
    } else if (Number(valeurEpargne) <= 300000) {
      return '100 001 à 300 000 €';
    } else if (Number(valeurEpargne) <= 500000) {
      return '300 001 à 500 000 €';
    } else {
      return 'Plus de 500 001 €';
    }
  }
}
