import { NgModule } from '@angular/core';
import { MyWayDialogModule, MyWaySeparatorModule, MyWayTileModule } from '@myway/ui';
import { SharedModule } from '../../../shared/shared.module';
import { ModaleValidationComponent } from './modale-validation.component';

@NgModule({
  declarations: [ModaleValidationComponent],
  imports: [SharedModule, MyWayDialogModule, MyWayTileModule, MyWaySeparatorModule]
})
export class ModaleValidationModule {}
