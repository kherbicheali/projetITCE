import { CurrencyPipe, DatePipe, DecimalPipe, registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxsReduxDevtoolsPluginModule } from '@ngxs/devtools-plugin';
import { NgxsLoggerPluginModule } from '@ngxs/logger-plugin';
import { NgxsModule } from '@ngxs/store';
import { PTMAgentModule } from '@oscaiss-pormyway-managers/pormyway-lib-agent';
import { CoreAgentModule } from '@ptmyway-stc-v2/core-agent';
import { HabilitationAgentModule } from '@ptmyway-stc-v2/habilitation-agent';
import { ImpressionAgentModule } from '@ptmyway-stc-v2/impression-agent';
import { LisaAgentModule } from '@ptmyway-stc-v2/lisa-agent';
import { RequestHttpAgentModule } from '@ptmyway-stc-v2/request-http-agent';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrancheEIModule } from './pages/branche-ei/branche-ei.module';
import { MainPageModule } from './pages/main/main-page.module';
import { FicheRevueDocumentService } from './shared/gcedoc/fiche-revue';
import { SharedModule } from './shared/shared.module';
import { ContexteState } from './shared/states/contexte/contexte.state';
import { CouleurTopCCPPState } from './shared/states/couleur-top-cc-pp/couleur-top-cc-pp.state';
import { DonneesAdministrativesState } from './shared/states/donnees-administratives/donnees-administratives.state';
import { DonneesClientParticulierState } from './shared/states/donnees-client-particulier/donnees-client-particulier.state';
import { DonneesCorporateState } from './shared/states/donnees-corporate/donnees-corporate.state';
import { DonneesEaiState } from './shared/states/donnees-eai/donnees-eai.state';
import { DonneesLiensState } from './shared/states/donnees-liens/donnees-liens.state';
import { DonneesNatureRelationState } from './shared/states/donnees-nature-relation/donnees-nature-relation.state';
import { DonneesTopCCState } from './shared/states/donnees-top-cc/donnees-top-cc.state';

registerLocaleData(localeFr);
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule,
    NgxsModule.forRoot(
      [
        DonneesAdministrativesState,
        DonneesCorporateState,
        ContexteState,
        DonneesLiensState,
        DonneesNatureRelationState,
        DonneesEaiState,
        DonneesTopCCState,
        CouleurTopCCPPState,
        DonneesClientParticulierState
      ],
      {
        developmentMode: !environment.production
      }
    ),
    NgxsLoggerPluginModule.forRoot(),
    NgxsReduxDevtoolsPluginModule.forRoot(),
    MainPageModule,
    BrancheEIModule,
    environment.envModule,
    BrowserAnimationsModule,
    CoreAgentModule,
    RequestHttpAgentModule,
    LisaAgentModule.forceContextV1(),
    PTMAgentModule,
    HabilitationAgentModule,
    ImpressionAgentModule
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'fr-FR' }, DatePipe, CurrencyPipe, DecimalPipe, FicheRevueDocumentService],
  bootstrap: [AppComponent]
})
export class AppModule {}
