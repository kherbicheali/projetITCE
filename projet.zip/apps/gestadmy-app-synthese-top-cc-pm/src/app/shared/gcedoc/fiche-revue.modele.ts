﻿import {
  DocumentPrintBatch,
  GENERATION_ACTION,
  GENERATION_PRINT_ACTION,
  MandatoryGenerationParams,
  MandatoryGenerationPrintParams,
  OptionalGenerationParams,
  OptionalGenerationPrintParams,
  RESTITUTION_VERSION,
  SystemGenerationParams,
  TYPE_FICHIER,
  TYPE_IMAGE
} from '@ptmyway-stc-v2/impression-common';

export interface IcompteRenduActualisationCcEpi {
  genericTitredocument: IgenericTitredocument[];
  identifiantClient: string;
  blocPm: IcompteRenduActualisationCcEpiBlocPm;
  blocEi: IcompteRenduActualisationCcEpiBlocEi;
  libEtablissementCaisse: string;
  libEtablissementCaisse2: string;
  siteWebEtabCaisse: string;
  genericEnteteets: IgenericEnteteets[];
  genericPiedpageets: IgenericPiedpageets[];
  attributeId: string;
  attributeXmlns: string;
  attributeCamel: string;
}

export interface IgenericTitredocument {
  titreDocument: string;
}

export interface IcompteRenduActualisationCcEpiBlocPm {
  raisonSociale: string;
  numeroSiren: string;
  ligneRepresentantLg: IcompteRenduActualisationCcEpiBlocPmLigneRepresentantLg[];
  identiteContactPrincipal: string;
  telFixeContactPrincipal: string;
  telMobileContactPrincipal: string;
  emailContactPrincipal: string;
  telPersonneMorale: string;
  emailPersonneMorale: string;
  adresseSiegeSocial: string;
  chiffreAffaire: string;
  exercice: string;
}

export interface IcompteRenduActualisationCcEpiBlocPmLigneRepresentantLg {
  fonctionLigneRl: string;
  identiteLigneRl: string;
}

export interface IcompteRenduActualisationCcEpiBlocEi {
  nomEi: string;
  prenomsEi: string;
  nomMaritalEi: string;
  nationaliteEi: string;
  telMobileEi: string;
  telFixeEi: string;
  telMobileProEi: string;
  telFixeProEi: string;
  emailEi: string;
  emailProEi: string;
  adresseEi: string;
  categorieSocioProEi: string;
  revenueNetMensuel: string;
  epargnePlacement: string;
  patrimoineImmobilier: string;
  adresseActivitePro: string;
  chiffreAffaires: string;
  exercice: string;
  numeroSiren: string;
}

export interface IgenericEnteteets {
  logoEtablissement: IgenericEnteteetsLogoEtablissement;
  libelleAgence: string;
  coceelAgence: string;
  nodatpAgence: string;
  dateEdition: string;
  heureEdition: string;
  numRefdoc: string;
  codeBarre: string;
  refActe: string;
}

export interface IgenericEnteteetsLogoEtablissement {
  attributeContent: TYPE_IMAGE;
  valueImgJson: string;
}

export interface IgenericPiedpageets {
  b10175: IgenericPiedpageetsB10175[];
  b13135: IgenericPiedpageetsB13135[];
  b13705: IgenericPiedpageetsB13705[];
  b14445: IgenericPiedpageetsB14445[];
  b14505: IgenericPiedpageetsB14505[];
  b15135: IgenericPiedpageetsB15135[];
  b15905: IgenericPiedpageetsB15905[];
  b15965: IgenericPiedpageetsB15965[];
  b16275: IgenericPiedpageetsB16275[];
  b18025: IgenericPiedpageetsB18025[];
  b18279: IgenericPiedpageetsB18279[];
  b43199: IgenericPiedpageetsB43199[];
  b18715: IgenericPiedpageetsB18715[];
  b13335: IgenericPiedpageetsB13335[];
  b17515: IgenericPiedpageetsB17515[];
  b62108: IgenericPiedpageetsB62108[];
  b12579: IgenericPiedpageetsB12579[];
  b13825: IgenericPiedpageetsB13825[];
  b16705: IgenericPiedpageetsB16705[];
  b12135: IgenericPiedpageetsB12135[];
  b14265: IgenericPiedpageetsB14265[];
  b13485: IgenericPiedpageetsB13485[];
  b18315: IgenericPiedpageetsB18315[];
  b11315: IgenericPiedpageetsB11315[];
  b11425: IgenericPiedpageetsB11425[];
  b12548: IgenericPiedpageetsB12548[];
  b30051: IgenericPiedpageetsB30051[];
}

export interface IgenericPiedpageetsB10175 {
  d10175L1: string;
  d10175L2: string;
}

export interface IgenericPiedpageetsB13135 {
  d13135L1: string;
}

export interface IgenericPiedpageetsB13705 {
  d13705L1: string;
}

export interface IgenericPiedpageetsB14445 {
  d14445L1: string;
}

export interface IgenericPiedpageetsB14505 {
  d14505L1: string;
}

export interface IgenericPiedpageetsB15135 {
  d15135L1: string;
}

export interface IgenericPiedpageetsB15905 {
  d15905L1: string;
  d15905L2: string;
}

export interface IgenericPiedpageetsB15965 {
  d15965L1: string;
  d15965L2: string;
}

export interface IgenericPiedpageetsB16275 {
  d16275L1: string;
}

export interface IgenericPiedpageetsB18025 {
  d18025L1: string;
}

export interface IgenericPiedpageetsB18279 {
  d18279L1: string;
  d18279L2: string;
}

export interface IgenericPiedpageetsB43199 {
  d43199L1: string;
  d43199L2: string;
}

export interface IgenericPiedpageetsB18715 {
  d18715L1: string;
}

export interface IgenericPiedpageetsB13335 {
  d13335L1: string;
}

export interface IgenericPiedpageetsB17515 {
  d17515L1: string;
}

export interface IgenericPiedpageetsB62108 {
  d62108L1: string;
}

export interface IgenericPiedpageetsB12579 {
  d12579L1: string;
}

export interface IgenericPiedpageetsB13825 {
  d13825L1: string;
}

export interface IgenericPiedpageetsB16705 {
  d16705L1: string;
}

export interface IgenericPiedpageetsB12135 {
  d12135L1: string;
}

export interface IgenericPiedpageetsB14265 {
  d14265L1: string;
}

export interface IgenericPiedpageetsB13485 {
  d13485L1: string;
}

export interface IgenericPiedpageetsB18315 {
  d18315L1: string;
}

export interface IgenericPiedpageetsB11315 {
  d11315L1: string;
}

export interface IgenericPiedpageetsB11425 {
  d11425L1: string;
}

export interface IgenericPiedpageetsB12548 {
  d12548L1: string;
}

export interface IgenericPiedpageetsB30051 {
  d30051L1: string;
}

/* istanbul ignore next */
export class CompteRenduActualisationCcEpi implements IcompteRenduActualisationCcEpi {
  public genericTitredocument: IgenericTitredocument[];
  public identifiantClient: string;
  public blocPm: IcompteRenduActualisationCcEpiBlocPm;
  public blocEi: IcompteRenduActualisationCcEpiBlocEi;
  public libEtablissementCaisse: string;
  public libEtablissementCaisse2: string;
  public lienNoticeEtabCaisse: string;
  public siteWebEtabCaisse: string;
  public genericEnteteets: IgenericEnteteets[];
  public genericPiedpageets: IgenericPiedpageets[];
  public attributeId: string;
  public attributeXmlns: string;
  public attributeCamel: string;

  constructor() {
    this.attributeId = 'compterenduactualisationccepi.docx';
    this.attributeXmlns = 'http://compterenduactualisationccepi.xsd';
    this.attributeCamel = 'O';
  }
}

const today = new Date();
const tomorrow = new Date();

/* istanbul ignore next */
export class CompteRenduActualisationCcEpiArchiveSetting {
  public system: SystemGenerationParams;
  public mandatory: MandatoryGenerationParams;
  public optionals: OptionalGenerationParams;

  constructor() {
    this.system = {
      typeName: 'compteRenduActualisationCcEpi',
      typeFullName: 'compteRenduActualisationCcEpi.compteRenduActualisationCcEpi',
      library: '_02-CLIENT_GESTADM_compteRenduActualisationCcEpi'
    };
    this.mandatory = {
      action: GENERATION_ACTION.archive,
      fileGenerationParams: {
        fileType: TYPE_FICHIER.PDF,
        restitutionVersion: RESTITUTION_VERSION.V180,
        subFolderModel: 'clients/gestadm/gestadmy'
      }
    };
    this.optionals = {
      archiving: {
        gceContextSoapHeader: {
          codeTypeIdntExtn: 'W',
          idntAgnt: 'A0070767',
          idntAgntAcces: 'A0070767',
          idntAgntTech: 'T0070767',
          idntEtabEntt: '13135',
          idntExtnConx: '0070767',
          idntInteEdsAgnt: '0070767',
          refrExtnAgnt: '0070767',
          refrPosteFoncAgnt: '12321',
          typePrflAgnt: '2',
          extendedProperties: '1'
        },
        aQstnCreateDoc: {
          document: {
            documentProperties: {
              codeTypeNatrDoc: 'PACN',
              codeTypeAttrb: '1',
              idntAttrb: '1313500080200123981',
              dateDeliv: new Date(),
              dateNumr: new Date(),
              inttAttr: 'DocTestGceDoc',
              codeTypeStck: 'L'
            },
            documentFile: {
              fileName: 'compteRenduActualisationCcEpi.pdf'
            }
          },
          contextData: {
            institutionCode: '13135',
            requestingApplicationIdentifier: 'PDC'
          }
        }
      }
    };
  }
}

/* istanbul ignore next */
export class CompteRenduActualisationCcEpiGenerateSetting {
  public system: SystemGenerationParams;
  public mandatory: MandatoryGenerationParams;
  public optionals: OptionalGenerationParams;

  constructor() {
    this.system = {
      typeName: 'compteRenduActualisationCcEpi',
      typeFullName: 'compteRenduActualisationCcEpi.compteRenduActualisationCcEpi',
      library: '_02-CLIENT_GESTADM_compteRenduActualisationCcEpi'
    };
    this.mandatory = {
      action: GENERATION_ACTION.getFile,
      fileGenerationParams: {
        fileType: TYPE_FICHIER.PDF,
        restitutionVersion: RESTITUTION_VERSION.V180,
        subFolderModel: 'clients/gestadm/gestadmy'
      }
    };
    this.optionals = {
      fileName: 'compteRenduActualisationCcEpi.pdf'
    };
  }
}

/* istanbul ignore next */
// tslint:disable-next-line: max-classes-per-file
export class CompteRenduActualisationCcEpiGenerateAndArchiveSetting {
  public system: SystemGenerationParams;
  public mandatory: MandatoryGenerationParams;
  public optionals: OptionalGenerationParams;

  constructor() {
    this.system = {
      typeName: 'compteRenduActualisationCcEpi',
      typeFullName: 'compteRenduActualisationCcEpi.compteRenduActualisationCcEpi',
      library: '_02-CLIENT_GESTADM_compteRenduActualisationCcEpi'
    };
    this.mandatory = {
      action: GENERATION_ACTION.archiveAndGetFile,
      fileGenerationParams: {
        fileType: TYPE_FICHIER.PDF,
        restitutionVersion: RESTITUTION_VERSION.V180,
        subFolderModel: 'clients/gestadm/gestadmy'
      }
    };
    this.optionals = {
      archiving: {
        gceContextSoapHeader: {
          codeTypeIdntExtn: 'W',
          idntAgnt: 'A0070767',
          idntAgntAcces: 'A0070767',
          idntAgntTech: 'T0070767',
          idntEtabEntt: '13135',
          idntExtnConx: '0070767',
          idntInteEdsAgnt: '0070767',
          refrExtnAgnt: '0070767',
          refrPosteFoncAgnt: '12321',
          typePrflAgnt: '2',
          extendedProperties: '1'
        },
        aQstnCreateDoc: {
          document: {
            documentProperties: {
              codeTypeNatrDoc: 'PACN',
              codeTypeAttrb: '1',
              idntAttrb: '1313500080200123981',
              dateDeliv: new Date(),
              dateNumr: new Date(),
              datePerm: new Date(tomorrow.setDate(today.getDate() + 1)),
              inttAttr: 'DocTestGceDoc',
              codeTypeStck: 'L'
            },
            documentFile: {
              fileName: 'compteRenduActualisationCcEpi.pdf'
            }
          },
          contextData: {
            institutionCode: '13135',
            requestingApplicationIdentifier: 'PDC'
          }
        }
      }
    };
  }
}

/* istanbul ignore next */
// tslint:disable-next-line: max-classes-per-file
export class CompteRenduActualisationCcEpiPrintSetting {
  public system: SystemGenerationParams;
  public mandatory: MandatoryGenerationPrintParams;
  public optionals: OptionalGenerationPrintParams;

  constructor() {
    this.system = {
      typeName: 'compteRenduActualisationCcEpi',
      typeFullName: 'compteRenduActualisationCcEpi.compteRenduActualisationCcEpi',
      library: '_02-CLIENT_GESTADM_compteRenduActualisationCcEpi'
    };
    this.mandatory = {
      action: GENERATION_PRINT_ACTION.getFile,
      fileName: 'compteRenduActualisationCcEpi.pdf',
      fileGenerationParams: {
        fileType: TYPE_FICHIER.PDF,
        restitutionVersion: RESTITUTION_VERSION.V180,
        subFolderModel: 'clients/gestadm/gestadmy'
      }
    };
    this.optionals = {
      activeXParams: {
        cancel: false,
        save: false,
        preview: false,
        forceDefault: false,
        affred: false,
        rePrint: false,
        blocnbex: false,
        maxcop: 0,
        mincop: 0,
        nbcopiesdef: 1
      }
    };
  }
}

/* istanbul ignore next */
// tslint:disable-next-line: max-classes-per-file
export class CompteRenduActualisationCcEpiArchiveAndPrintSetting {
  public system: SystemGenerationParams;
  public mandatory: MandatoryGenerationPrintParams;
  public optionals: OptionalGenerationPrintParams;

  constructor() {
    this.system = {
      typeName: 'compteRenduActualisationCcEpi',
      typeFullName: 'compteRenduActualisationCcEpi.compteRenduActualisationCcEpi',
      library: '_02-CLIENT_GESTADM_compteRenduActualisationCcEpi'
    };
    this.mandatory = {
      action: GENERATION_PRINT_ACTION.archiveAndGetFile,
      fileName: 'compteRenduActualisationCcEpi.pdf',
      fileGenerationParams: {
        fileType: TYPE_FICHIER.PDF,
        restitutionVersion: RESTITUTION_VERSION.V180,
        subFolderModel: 'clients/gestadm/gestadmy'
      }
    };
    this.optionals = {
      activeXParams: {
        cancel: false,
        save: false,
        preview: false,
        forceDefault: false,
        affred: false,
        rePrint: false,
        blocnbex: false,
        maxcop: 0,
        mincop: 0,
        nbcopiesdef: 1
      },
      archiving: {
        gceContextSoapHeader: {
          codeTypeIdntExtn: 'W',
          idntAgnt: 'A0070767',
          idntAgntAcces: 'A0070767',
          idntAgntTech: 'T0070767',
          idntEtabEntt: '13135',
          idntExtnConx: '0070767',
          idntInteEdsAgnt: '0070767',
          refrExtnAgnt: '0070767',
          refrPosteFoncAgnt: '12321',
          typePrflAgnt: '2',
          extendedProperties: '1'
        },
        aQstnCreateDoc: {
          document: {
            documentProperties: {
              codeTypeNatrDoc: 'PACN',
              codeTypeAttrb: '1',
              idntAttrb: '1313500080200123981',
              dateDeliv: new Date(),
              dateNumr: new Date(),
              datePerm: new Date(tomorrow.setDate(today.getDate() + 1)),
              inttAttr: 'DocTestGceDoc',
              codeTypeStck: 'L'
            },
            documentFile: {
              fileName: 'compteRenduActualisationCcEpi.pdf'
            }
          },
          contextData: {
            institutionCode: '13135',
            requestingApplicationIdentifier: 'PDC'
          }
        }
      }
    };
  }
}

/* istanbul ignore next */
// tslint:disable-next-line: max-classes-per-file
export class CompteRenduActualisationCcEpiPrintBatchSetting {
  public printBatch: DocumentPrintBatch;

  constructor() {
    this.printBatch = {
      ordreNumber: 1,
      file: null,
      idGed: null,
      applicationComponent: 'compAppli',
      institutionCode: '13135',
      printParams: {
        mandatory: {
          fileName: 'compteRenduActualisationCcEpi.pdf'
        },
        optionals: {
          activeXParams: {
            cancel: false,
            forceDefault: false,
            affred: false,
            rePrint: false
          },
          individualActiveXParams: {
            save: false,
            preview: false,
            blocnbex: false,
            maxcop: 0,
            mincop: 0,
            nbcopiesdef: 1
          }
        }
      }
    };
  }
}
