﻿import { DatePipe } from '@angular/common';
import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import { GenerationPrintParams, TYPE_FICHIER, TYPE_IMAGE } from '@ptmyway-stc-v2/impression-common';
import { DATAINCONNU_MASCULIN, MEDIA_ABSENT } from '../constantes/ihm.constantes';
import { IContexte } from '../modeles/contexte.model';
import { IDonneesClientParticulier } from '../modeles/donnees-client-particulier.modele';
import { INominationsReglementaires } from '../modeles/donnees-liens.modele';
import { InformationsAdministrativesModele } from '../modeles/informations-administratives.modele';
import {
  CompteRenduActualisationCcEpi,
  CompteRenduActualisationCcEpiArchiveAndPrintSetting,
  CompteRenduActualisationCcEpiArchiveSetting,
  CompteRenduActualisationCcEpiGenerateAndArchiveSetting,
  CompteRenduActualisationCcEpiGenerateSetting,
  CompteRenduActualisationCcEpiPrintBatchSetting,
  CompteRenduActualisationCcEpiPrintSetting,
  IcompteRenduActualisationCcEpiBlocEi,
  IcompteRenduActualisationCcEpiBlocPm,
  IcompteRenduActualisationCcEpiBlocPmLigneRepresentantLg,
  IgenericEnteteets,
  IgenericEnteteetsLogoEtablissement,
  IgenericPiedpageets,
  IgenericTitredocument
} from './fiche-revue.modele';

/* istanbul ignore next */
@Injectable({
  providedIn: 'root'
})
export class FicheRevueDocumentService {
  private dateDuJour = Date.now();
  constructor(@Inject(LOCALE_ID) public locale: string, private datePipe: DatePipe) {}

  /* GENERATION :  Création des paramètres */
  createGenerateSetting() {
    const generateSetting: CompteRenduActualisationCcEpiGenerateSetting = new CompteRenduActualisationCcEpiGenerateSetting();
    generateSetting.mandatory.fileGenerationParams.fileType = TYPE_FICHIER.PDF;
    return generateSetting;
  }

  /* archiving :  Création des paramètres */
  createArchiveSetting() {
    const archiveSetting: CompteRenduActualisationCcEpiArchiveSetting = new CompteRenduActualisationCcEpiArchiveSetting();
    archiveSetting.optionals.archiving.gceContextSoapHeader.codeTypeIdntExtn = 'W';
    archiveSetting.optionals.archiving.gceContextSoapHeader.idntAgnt = 'A0070767';
    archiveSetting.optionals.archiving.gceContextSoapHeader.idntAgntAcces = 'A0070767';
    archiveSetting.optionals.archiving.gceContextSoapHeader.idntAgntTech = 'T0070767';
    archiveSetting.optionals.archiving.gceContextSoapHeader.idntEtabEntt = '13140';
    archiveSetting.optionals.archiving.gceContextSoapHeader.idntExtnConx = '0070767';
    archiveSetting.optionals.archiving.gceContextSoapHeader.idntInteEdsAgnt = '0070767';
    archiveSetting.optionals.archiving.gceContextSoapHeader.refrExtnAgnt = '0070767';
    archiveSetting.optionals.archiving.gceContextSoapHeader.refrPosteFoncAgnt = '12321';
    archiveSetting.optionals.archiving.gceContextSoapHeader.typePrflAgnt = '2';
    archiveSetting.optionals.archiving.gceContextSoapHeader.extendedProperties = '1';
    archiveSetting.optionals.archiving.aQstnCreateDoc.contextData.institutionCode = '13135';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeModeAcqs = '4';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeOrigAcqs = '3';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeSign = '0';
    archiveSetting.optionals.archiving.aQstnCreateDoc.contextData.requestingApplicationIdentifier = 'PDC';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentFile.fileName = 'compteRenduActualisationCcEpi.pdf';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeNatrDoc = 'CRVA';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeAttrb = '2';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.idntAttrb = '1313500080200123981';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.dateDeliv = new Date();
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.dateNumr = new Date();
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.inttAttr = 'DocTestGceDoc';
    archiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeStck = 'A';
    return archiveSetting;
  }

  /* archiving et GENERATION :  Création des paramètres */
  createGenerateAndArchiveSetting() {
    // tslint:disable-next-line: max-line-length
    const generateAndArchiveSetting: CompteRenduActualisationCcEpiGenerateAndArchiveSetting = new CompteRenduActualisationCcEpiGenerateAndArchiveSetting();
    generateAndArchiveSetting.mandatory.fileGenerationParams.fileType = TYPE_FICHIER.PDF;
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.codeTypeIdntExtn = 'W';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.idntAgnt = 'A0070767';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.idntAgntAcces = 'A0070767';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.idntAgntTech = 'T0070767';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.idntEtabEntt = '13140';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.idntExtnConx = '0070767';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.idntInteEdsAgnt = '0070767';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.refrExtnAgnt = '0070767';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.refrPosteFoncAgnt = '12321';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.typePrflAgnt = '2';
    generateAndArchiveSetting.optionals.archiving.gceContextSoapHeader.extendedProperties = '1';
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.contextData.institutionCode = '13135';
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.contextData.requestingApplicationIdentifier = 'PDC';
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.document.documentFile.fileName = 'ficheRevue.pdf';
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeNatrDoc = 'PACN';
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeAttrb = '1';
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.idntAttrb = '1313500080200123981';
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.dateDeliv = new Date();
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.dateNumr = new Date();
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.inttAttr = 'DocTestGceDoc';
    generateAndArchiveSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeStck = 'L';
    return generateAndArchiveSetting;
  }

  /* IMPRESSION :  Création des paramètres */
  createPrintSetting(): GenerationPrintParams {
    const printSetting: CompteRenduActualisationCcEpiPrintSetting = new CompteRenduActualisationCcEpiPrintSetting();
    return {
      system: printSetting.system,
      mandatory: printSetting.mandatory,
      optionals: {
        activeXParams: {
          cancel: true,
          forceDefault: false,
          affred: false,
          rePrint: false,
          save: true,
          preview: true,
          blocnbex: false,
          maxcop: 1,
          mincop: 1,
          nbcopiesdef: 1
        },
        archiving: {
          aQstnCreateDoc: {
            contextData: {
              institutionCode: '13135',
              requestingApplicationIdentifier: 'PDC'
            },
            document: {
              documentProperties: {
                codeTypeNatrDoc: 'PACN',
                codeTypeAttrb: '1',
                idntAttrb: '1313500080200123981',
                dateDeliv: new Date(),
                dateNumr: new Date(),
                inttAttr: 'DocTestGceDoc',
                codeTypeStck: 'L'
              },
              documentFile: {
                fileName: 'ficheRevue.pdf'
              }
            }
          }
        }
      }
    };
  }

  /* IMPRESSION et archiving :  Création des paramètres */
  createArchiveAndPrintSetting() {
    // tslint:disable-next-line: max-line-length
    const archiveAndPrintSetting: CompteRenduActualisationCcEpiArchiveAndPrintSetting = new CompteRenduActualisationCcEpiArchiveAndPrintSetting();
    archiveAndPrintSetting.mandatory.fileGenerationParams.fileType = TYPE_FICHIER.PDF;
    archiveAndPrintSetting.mandatory.fileName = 'FicheRevue.pdf';
    archiveAndPrintSetting.optionals.activeXParams.cancel = false;
    archiveAndPrintSetting.optionals.activeXParams.forceDefault = false;
    archiveAndPrintSetting.optionals.activeXParams.affred = false;
    archiveAndPrintSetting.optionals.activeXParams.rePrint = false;
    archiveAndPrintSetting.optionals.activeXParams.save = false;
    archiveAndPrintSetting.optionals.activeXParams.preview = false;
    archiveAndPrintSetting.optionals.activeXParams.blocnbex = false;
    archiveAndPrintSetting.optionals.activeXParams.maxcop = 1;
    archiveAndPrintSetting.optionals.activeXParams.mincop = 1;
    archiveAndPrintSetting.optionals.activeXParams.nbcopiesdef = 1;
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.codeTypeIdntExtn = 'W';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.idntAgnt = 'A0070767';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.idntAgntAcces = 'A0070767';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.idntAgntTech = 'T0070767';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.idntEtabEntt = '13140';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.idntExtnConx = '0070767';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.idntInteEdsAgnt = '0070767';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.refrExtnAgnt = '0070767';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.refrPosteFoncAgnt = '12321';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.typePrflAgnt = '2';
    archiveAndPrintSetting.optionals.archiving.gceContextSoapHeader.extendedProperties = '1';
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.contextData.institutionCode = '13135';
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.contextData.requestingApplicationIdentifier = 'PDC';
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.document.documentFile.fileName = 'ficheRevue.pdf';
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeNatrDoc = 'PACN';
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeAttrb = '1';
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.idntAttrb = '1313500080200123981';
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.dateDeliv = new Date();
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.dateNumr = new Date();
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.inttAttr = 'DocTestGceDoc';
    archiveAndPrintSetting.optionals.archiving.aQstnCreateDoc.document.documentProperties.codeTypeStck = 'A';
    return archiveAndPrintSetting;
  }

  /* IMPRESSION par LOT :  Création des paramètres */
  createPrintBatchSetting() {
    const printBatchSetting: CompteRenduActualisationCcEpiPrintBatchSetting = new CompteRenduActualisationCcEpiPrintBatchSetting();
    printBatchSetting.printBatch.ordreNumber = 1;
    printBatchSetting.printBatch.institutionCode = '13135';
    printBatchSetting.printBatch.applicationComponent = undefined;
    printBatchSetting.printBatch.file = 'FLUX pdf base 64';
    printBatchSetting.printBatch.idGed = undefined;
    printBatchSetting.printBatch.printParams.mandatory.fileName = 'FicheRevue.pdf';
    printBatchSetting.printBatch.printParams.optionals.activeXParams.cancel = false;
    printBatchSetting.printBatch.printParams.optionals.activeXParams.forceDefault = false;
    printBatchSetting.printBatch.printParams.optionals.activeXParams.affred = false;
    printBatchSetting.printBatch.printParams.optionals.activeXParams.rePrint = false;
    printBatchSetting.printBatch.printParams.optionals.individualActiveXParams.save = false;
    printBatchSetting.printBatch.printParams.optionals.individualActiveXParams.preview = false;
    printBatchSetting.printBatch.printParams.optionals.individualActiveXParams.blocnbex = false;
    printBatchSetting.printBatch.printParams.optionals.individualActiveXParams.maxcop = 1;
    printBatchSetting.printBatch.printParams.optionals.individualActiveXParams.mincop = 1;
    printBatchSetting.printBatch.printParams.optionals.individualActiveXParams.nbcopiesdef = 1;
    return printBatchSetting;
  }

  /* DOCUMENT : Création */
  createDocument(
    contexte: IContexte,
    coordonnees: InformationsAdministrativesModele.IDonneesAdministratives,
    chiffreAffaire: string,
    exercice: string,
    adresseSiege: string,
    listeNominationsReglementaires: INominationsReglementaires[],
    donneesClientPart: IDonneesClientParticulier
  ) {
    const doc: CompteRenduActualisationCcEpi = new CompteRenduActualisationCcEpi();

    /* Début genericTitredocument */
    const obj0genericTitredocument: IgenericTitredocument = <IgenericTitredocument>{};
    const array0genericTitredocument: IgenericTitredocument[] = new Array();
    obj0genericTitredocument.titreDocument = 'COMPTE-RENDU ACTUALISATION CONNAISSANCE CLIENT';
    array0genericTitredocument.push(obj0genericTitredocument);

    doc.genericTitredocument = array0genericTitredocument;
    /* Fin genericTitredocument */

    /* Début identifiantClient */
    doc.identifiantClient = contexte.identifiantPersonne;
    /* Fin identifiantClient */

    /* Début blocPm */
    if (!contexte.estPersonnePhysique) {
      const obj0FicheRevueBlocPm: IcompteRenduActualisationCcEpiBlocPm = <IcompteRenduActualisationCcEpiBlocPm>{};
      obj0FicheRevueBlocPm.raisonSociale = coordonnees.raisonSociale;
      obj0FicheRevueBlocPm.numeroSiren = coordonnees.numeroSiren;

      const array0FicheRevueBlocPmligneRepresentantLg: IcompteRenduActualisationCcEpiBlocPmLigneRepresentantLg[] = new Array();

      listeNominationsReglementaires.forEach((nomination: INominationsReglementaires) => {
        const obj0FicheRevueBlocPmLigneRepresentantLg: IcompteRenduActualisationCcEpiBlocPmLigneRepresentantLg = <
          IcompteRenduActualisationCcEpiBlocPmLigneRepresentantLg
        >{};
        obj0FicheRevueBlocPmLigneRepresentantLg.fonctionLigneRl = nomination.fonction;
        obj0FicheRevueBlocPmLigneRepresentantLg.identiteLigneRl = nomination.identite;
        array0FicheRevueBlocPmligneRepresentantLg.push(obj0FicheRevueBlocPmLigneRepresentantLg);
      });

      obj0FicheRevueBlocPm.ligneRepresentantLg = array0FicheRevueBlocPmligneRepresentantLg;
      obj0FicheRevueBlocPm.identiteContactPrincipal = coordonnees?.interlocuteurPrincipal?.designation
        ? coordonnees.interlocuteurPrincipal.designation
        : DATAINCONNU_MASCULIN;
      obj0FicheRevueBlocPm.telFixeContactPrincipal = coordonnees?.interlocuteurPrincipal?.medias[0]?.valeur
        ? coordonnees.interlocuteurPrincipal.medias[0].valeur
        : DATAINCONNU_MASCULIN;
      obj0FicheRevueBlocPm.telMobileContactPrincipal = coordonnees?.interlocuteurPrincipal?.medias[1]?.valeur
        ? coordonnees.interlocuteurPrincipal.medias[1].valeur
        : DATAINCONNU_MASCULIN;
      obj0FicheRevueBlocPm.emailContactPrincipal = coordonnees?.interlocuteurPrincipal?.medias[2]?.valeur
        ? coordonnees.interlocuteurPrincipal.medias[2].valeur
        : DATAINCONNU_MASCULIN;
      obj0FicheRevueBlocPm.telPersonneMorale =
        coordonnees.telephonePortablePm && coordonnees.telephonePortablePm !== MEDIA_ABSENT
          ? coordonnees.telephonePortablePm
          : coordonnees.telephoneFixePm && coordonnees.telephoneFixePm !== MEDIA_ABSENT
          ? coordonnees.telephoneFixePm
          : MEDIA_ABSENT;
      obj0FicheRevueBlocPm.emailPersonneMorale = coordonnees.emailPm;
      obj0FicheRevueBlocPm.adresseSiegeSocial = adresseSiege;
      obj0FicheRevueBlocPm.chiffreAffaire = chiffreAffaire;
      obj0FicheRevueBlocPm.exercice = exercice;
      doc.blocPm = obj0FicheRevueBlocPm;
    }
    /* Fin blocPm */

    /* Début blocEi */
    if (contexte.estPersonnePhysique && donneesClientPart) {
      const obj0FicheRevueBlocEi: IcompteRenduActualisationCcEpiBlocEi = <IcompteRenduActualisationCcEpiBlocEi>{};
      obj0FicheRevueBlocEi.nomEi = donneesClientPart.nom;
      obj0FicheRevueBlocEi.prenomsEi = donneesClientPart.prenom;
      obj0FicheRevueBlocEi.nomMaritalEi = donneesClientPart.nomUsage;
      obj0FicheRevueBlocEi.nationaliteEi = donneesClientPart.nationalite;
      obj0FicheRevueBlocEi.telMobileEi = coordonnees.telephonePortablePart;
      obj0FicheRevueBlocEi.telFixeEi = coordonnees.telephoneFixePart;
      obj0FicheRevueBlocEi.telMobileProEi = coordonnees.telephonePortablePm;
      obj0FicheRevueBlocEi.telFixeProEi = coordonnees.telephoneFixePm;
      obj0FicheRevueBlocEi.emailEi = coordonnees.emailPart;
      obj0FicheRevueBlocEi.emailProEi = coordonnees.emailPm;
      obj0FicheRevueBlocEi.adresseEi = donneesClientPart.adresse;
      obj0FicheRevueBlocEi.categorieSocioProEi = donneesClientPart.categorieSocioPro;
      obj0FicheRevueBlocEi.revenueNetMensuel = donneesClientPart.revenusNetMensuels;
      obj0FicheRevueBlocEi.epargnePlacement = this.getLibelleEpargne(donneesClientPart.epargnePlacement);
      obj0FicheRevueBlocEi.patrimoineImmobilier = this.getLibellePatrimoineImmo(donneesClientPart.patrimoineImmobilier);
      obj0FicheRevueBlocEi.adresseActivitePro = adresseSiege;
      obj0FicheRevueBlocEi.chiffreAffaires = chiffreAffaire;
      obj0FicheRevueBlocEi.exercice = exercice;
      obj0FicheRevueBlocEi.numeroSiren = coordonnees.numeroSiren;
      doc.blocEi = obj0FicheRevueBlocEi;
    }
    /* Fin blocEi */

    const libelleUpperFirstLetter =
      contexte.libelleEditiqueEtablissement.articleMinusculeLaLe.charAt(0).toUpperCase() +
      contexte.libelleEditiqueEtablissement.articleMinusculeLaLe.slice(1);
    /* Début libEtablissementCaisse */
    doc.libEtablissementCaisse = libelleUpperFirstLetter;
    /* Fin libEtablissementCaisse */

    /* Début libEtablissementCaisse2 */
    doc.libEtablissementCaisse2 = contexte.libelleEditiqueEtablissement.articleMinusculeLaLe;
    /* Fin libEtablissementCaisse2 */

    /* Début siteWebEtabCaisse */
    doc.siteWebEtabCaisse = contexte.libelleEditiqueEtablissement.url;
    /* Fin siteWebEtabCaisse */

    /* Début genericEnteteets */
    const obj0genericEnteteets: IgenericEnteteets = <IgenericEnteteets>{};
    const array0genericEnteteets: IgenericEnteteets[] = new Array();
    const genericEnteteetsLogoEtablissement: IgenericEnteteetsLogoEtablissement = <IgenericEnteteetsLogoEtablissement>{};
    genericEnteteetsLogoEtablissement.attributeContent = TYPE_IMAGE.Id;
    genericEnteteetsLogoEtablissement.valueImgJson = contexte.codeEtablissement + '.jpg';
    obj0genericEnteteets.logoEtablissement = genericEnteteetsLogoEtablissement;
    obj0genericEnteteets.libelleAgence = contexte.parametresComptables?.rattachement?.libelleEds;
    obj0genericEnteteets.coceelAgence = contexte.parametresComptables?.guichet?.referenceExterneEds;
    obj0genericEnteteets.nodatpAgence = contexte.parametresComptables?.rattachement?.telephone;
    obj0genericEnteteets.dateEdition = this.datePipe.transform(this.dateDuJour, 'shortDate');
    obj0genericEnteteets.heureEdition = this.datePipe.transform(this.dateDuJour, 'mediumTime');
    array0genericEnteteets.push(obj0genericEnteteets);

    doc.genericEnteteets = array0genericEnteteets;
    /* Fin genericEnteteets */

    /* Début genericPiedpageets */
    const obj0genericPiedpageets: IgenericPiedpageets = <IgenericPiedpageets>{};
    const array0genericPiedpageets: IgenericPiedpageets[] = new Array();
    array0genericPiedpageets.push(obj0genericPiedpageets);

    doc.genericPiedpageets = array0genericPiedpageets;
    /* Fin genericPiedpageets */

    /* Début id */
    /* Fin id */

    return doc;
  }

  /* istanbul ignore next */
  public getLibellePatrimoineImmo(valeurPatrimoineImmo: string) {
    if (Number(valeurPatrimoineImmo) <= 100000) {
      return 'Entre 0 et 100 000 €';
    } else if (Number(valeurPatrimoineImmo) <= 200000) {
      return 'Entre 100 001 et 200 000 €';
    } else if (Number(valeurPatrimoineImmo) <= 350000) {
      return 'Entre 200 001 et 350 000 €';
    } else if (Number(valeurPatrimoineImmo) <= 500000) {
      return 'Entre 350 001 et 500 000 €';
    } else if (Number(valeurPatrimoineImmo) <= 1000000) {
      return 'Entre 500 001 et 1 000 000 €';
    } else {
      return 'Plus de 1 000 000 €';
    }
  }

  /* istanbul ignore next */
  public getLibelleEpargne(valeurEpargne: string) {
    if (Number(valeurEpargne) <= 5000) {
      return 'Entre 0 et 5 000 €';
    } else if (Number(valeurEpargne) <= 25000) {
      return 'Entre 5 001 et 25 000 €';
    } else if (Number(valeurEpargne) <= 100000) {
      return 'Entre 25 001 et 100 000 €';
    } else if (Number(valeurEpargne) <= 300000) {
      return 'Entre 100 001 et 300 000 €';
    } else if (Number(valeurEpargne) <= 500000) {
      return 'Entre 300 001 et 500 000 €';
    } else {
      return 'Plus de 500 001 €';
    }
  }
}
