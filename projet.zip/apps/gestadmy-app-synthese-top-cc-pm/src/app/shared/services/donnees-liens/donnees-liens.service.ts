import { DecimalPipe } from '@angular/common';
import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import {
  RessourceTiersConformiteV1PersPolitiqExposee,
  RessourceTiersCorporateV1CorporateTiersLies,
  TiersConformiteV1PersPolitiqExposeeService,
  TiersCorporateV1CorporateTiersLiesService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { forkJoin, Observable, of } from 'rxjs';
import { concatMap, map } from 'rxjs/operators';
import {
  DATAINCONNU,
  PPE_CONTAGION,
  PPE_DECLARATION,
  TYPE_GOUVERNANCE_AUTRE,
  TYPE_GOUVERNANCE_CAPITAL,
  TYPE_GOUVERNANCE_DROIT_VOTE,
  TYPE_GOUVERNANCE_REPRESENTANT_LEGAL,
  TYPE_LIEN_BENEFICIAIRE_EFFECTIF,
  TYPE_LIEN_REPRESENTANT_LEGAL
} from '../../constantes/ihm.constantes';
import { AppEnum } from '../../enums/app-enums';
import { IBeneficiaireEffectif, IDonneesLiens, INominationsReglementaires } from '../../modeles/donnees-liens.modele';

@Injectable({
  providedIn: 'root'
})
export class DonneesLiensService {
  constructor(
    private tiersConformiteV1PersPolitiqExposeeService: TiersConformiteV1PersPolitiqExposeeService,
    private tierscorporateV1CorporateTiersLies: TiersCorporateV1CorporateTiersLiesService,
    private decimalPipe: DecimalPipe,
    @Inject(LOCALE_ID) public locale: string
  ) {}

  getDonneesLiens(codeEtablissement: string, identifiantPersonne: string): Observable<IDonneesLiens> {
    return this.tierscorporateV1CorporateTiersLies.getCorporateTiersLies(codeEtablissement, +identifiantPersonne, 0, '1').pipe(
      concatMap(corporateTiersLies => {
        return forkJoin([
          this.filtrerNominationsReglementaires(codeEtablissement, corporateTiersLies),
          this.filtrerBeneficiairesEffectifs(codeEtablissement, corporateTiersLies)
        ]).pipe(
          map(([listeBE, listeNominations]) => {
            const donneesLien: IDonneesLiens = <IDonneesLiens>{};
            donneesLien.listeNominationsReglementaires = listeBE;
            donneesLien.listeBeneficiairesEffectifs = listeNominations;
            return donneesLien;
          })
        );
      })
    );
  }

  public completerInfosPPE(codeEtablissement: string, listeLiens: any[], appelPourNominations?: boolean) {
    let listeLiensApp: Observable<INominationsReglementaires[]>[] | Observable<IBeneficiaireEffectif[]>[] = null;
    if (listeLiens.length > 0) {
      listeLiensApp = [];
      listeLiens.forEach(lienApp => {
        if (
          (appelPourNominations && lienApp.fonction === AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL) ||
          !appelPourNominations
        ) {
          const observableInfosPersonne = this.tiersConformiteV1PersPolitiqExposeeService
            .getPersProlitiqExposee(codeEtablissement, +lienApp.numeroPersonne)
            .pipe(
              map((infosPPE: RessourceTiersConformiteV1PersPolitiqExposee.IAutoDeclarationPEEPers) => {
                if (infosPPE && infosPPE.detailsSensibilitePersPPE && infosPPE.detailsSensibilitePersPPE.codeStatutPPE) {
                  const codeStatut = infosPPE.detailsSensibilitePersPPE.codeStatutPPE;
                  if (codeStatut !== 'N' && codeStatut !== 'D' && codeStatut !== 'P') {
                    lienApp.ppe = true;
                    if (codeStatut === 'C' || codeStatut === 'O') {
                      lienApp.provenanceStatutPpe = PPE_DECLARATION;
                    } else if (codeStatut === 'L' || codeStatut === 'Q') {
                      lienApp.provenanceStatutPpe = PPE_CONTAGION;
                    }
                  } else {
                    lienApp.ppe = false;
                    lienApp.provenanceStatutPpe = '';
                  }
                } else {
                  lienApp.ppe = false;
                  lienApp.provenanceStatutPpe = '';
                }
                return lienApp;
              })
            );
          listeLiensApp.push(observableInfosPersonne);
        } else {
          listeLiensApp.push(of(lienApp));
        }
      });

      return forkJoin(listeLiensApp);
    } else {
      return of([]);
    }
  }

  private filtrerNominationsReglementaires(
    codeEtablissement: string,
    corporateTiersLies: RessourceTiersCorporateV1CorporateTiersLies.ICorporateTiersLies
  ): Observable<INominationsReglementaires[]> {
    const listeNominations: INominationsReglementaires[] = [];

    const listeCodeTypeNominationsReglementaires = [
      AppEnum.CodeTypeLienNominationReglementaires.COGERANT.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.DIRECTEUR_GENERAL.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.DIRIGEANT.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.GERANT.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.PERS_MORAL_REPRESENTANT_PM.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.PRESIDENT.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.PRESIDENT_FONCTION.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.PRESIDENT_DIRECTEUR_GENERAL.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.TRESORIER.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.TRESORIER_FONCTION.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.MEMBRE_DIRECTOIRE.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.PRESIDENT_DIRECTOIRE.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.MAIRE.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.SECRETAIRE.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.SECRETAIRE_ADJOINT.toString(),
      AppEnum.CodeTypeLienNominationReglementaires.SYNDIC.toString()
    ];
    const listeLienFiltreeNominations = corporateTiersLies.listeLien.filter(
      lien => listeCodeTypeNominationsReglementaires.includes(lien.codeType) && lien.codeSens === 2
    );

    listeLienFiltreeNominations.forEach((nomination: RessourceTiersCorporateV1CorporateTiersLies.ILien) => {
      listeNominations.push(this.nominationsReglementairesRestToApp(nomination));
    });

    return of(listeNominations).pipe(concatMap(nominations => this.completerInfosPPE(codeEtablissement, nominations, true)));
  }

  private filtrerBeneficiairesEffectifs(
    codeEtablissement: string,
    corporateTiersLies: RessourceTiersCorporateV1CorporateTiersLies.ICorporateTiersLies
  ): Observable<IBeneficiaireEffectif[]> {
    const listeCorporateBE: IBeneficiaireEffectif[] = [];
    const listeLienFiltreeBE = corporateTiersLies.listeLien.filter(
      lien => lien.codeType === TYPE_LIEN_BENEFICIAIRE_EFFECTIF && lien.codeSens === 2
    );

    listeLienFiltreeBE.forEach((beneficiaireEffectif: RessourceTiersCorporateV1CorporateTiersLies.ILien) => {
      if (beneficiaireEffectif.tauxDroitVote === 0 && beneficiaireEffectif.pourcentageCapitalistique === 0) {
        if (
          corporateTiersLies.listeLien.find(
            lien =>
              lien.codeType === TYPE_LIEN_REPRESENTANT_LEGAL &&
              lien.identifiantTiersEnRelation === beneficiaireEffectif.identifiantTiersEnRelation
          )
        ) {
          listeCorporateBE.push(this.beneficiaireEffectifRestToApp(beneficiaireEffectif, 3));
        } else {
          listeCorporateBE.push(this.beneficiaireEffectifRestToApp(beneficiaireEffectif, 4));
        }
      } else {
        if (beneficiaireEffectif.tauxDroitVote !== 0) {
          listeCorporateBE.push(this.beneficiaireEffectifRestToApp(beneficiaireEffectif, 1));
        }
        if (beneficiaireEffectif.pourcentageCapitalistique !== 0) {
          listeCorporateBE.push(this.beneficiaireEffectifRestToApp(beneficiaireEffectif, 2));
        }
      }
    });
    return of(listeCorporateBE).pipe(concatMap(listeBE => this.completerInfosPPE(codeEtablissement, listeBE, false)));
  }

  private nominationsReglementairesRestToApp(lien: RessourceTiersCorporateV1CorporateTiersLies.ILien): INominationsReglementaires {
    const nominationApp: INominationsReglementaires = <INominationsReglementaires>{};
    nominationApp.numeroPersonne = '' + lien.identifiantTiersEnRelation;
    nominationApp.fonction = AppEnum.LibelleTypeLienNominationReglementaires[AppEnum.CodeTypeLienNominationReglementaires[lien.codeType]];
    nominationApp.identite = lien.designationCourte ? lien.designationCourte : DATAINCONNU;
    return nominationApp;
  }

  /* istanbul ignore next */
  private beneficiaireEffectifRestToApp(
    lienRest: RessourceTiersCorporateV1CorporateTiersLies.ILien,
    typeDetention: number
  ): IBeneficiaireEffectif {
    const beneficiaireEffectif: IBeneficiaireEffectif = <IBeneficiaireEffectif>{};
    beneficiaireEffectif.numeroPersonne = '' + lienRest.identifiantTiersEnRelation;
    beneficiaireEffectif.identite = lienRest.designationCourte ? lienRest.designationCourte : DATAINCONNU;
    beneficiaireEffectif.role = 'Bénéficiaire effectif';
    switch (typeDetention) {
      case 1: {
        beneficiaireEffectif.pourcentageDetention =
          this.decimalPipe.transform(lienRest.tauxDroitVote + lienRest.tauxDroitVoteIndirect, '1.0-2', this.locale) + '%';
        beneficiaireEffectif.gouvernanceDetention = TYPE_GOUVERNANCE_DROIT_VOTE;
        break;
      }
      case 2: {
        beneficiaireEffectif.pourcentageDetention =
          this.decimalPipe.transform(lienRest.pourcentageCapitalistique + lienRest.pourcentageCapitalIndirect, '1.0-2', this.locale) + '%';
        beneficiaireEffectif.gouvernanceDetention = TYPE_GOUVERNANCE_CAPITAL;

        break;
      }
      case 3: {
        beneficiaireEffectif.pourcentageDetention = '0%';
        beneficiaireEffectif.gouvernanceDetention = TYPE_GOUVERNANCE_REPRESENTANT_LEGAL;
        break;
      }
      case 4: {
        beneficiaireEffectif.pourcentageDetention = '0%';
        beneficiaireEffectif.gouvernanceDetention = TYPE_GOUVERNANCE_AUTRE;
        break;
      }
    }
    return beneficiaireEffectif;
  }
}
