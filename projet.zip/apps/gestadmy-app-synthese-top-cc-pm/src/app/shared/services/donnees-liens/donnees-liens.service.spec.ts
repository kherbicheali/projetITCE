import { DecimalPipe } from '@angular/common';
import { async, TestBed } from '@angular/core/testing';
import {
  RessourceTiersConformiteV1PersPolitiqExposee,
  RessourceTiersCorporateV1CorporateTiersLies,
  TiersConformiteV1PersPolitiqExposeeService,
  TiersCorporateV1CorporateTiersLiesService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { NgxsModule } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { PPE_CONTAGION, PPE_DECLARATION } from '../../constantes/ihm.constantes';
import { AppEnum } from '../../enums/app-enums';
import { INominationsReglementaires } from '../../modeles/donnees-liens.modele';
import { DonneesLiensService } from './donnees-liens.service';

describe('DonneesLiensService', () => {
  let service: DonneesLiensService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgxsModule.forRoot([])],
      providers: [
        DonneesLiensService,
        DecimalPipe,
        { provide: TiersConformiteV1PersPolitiqExposeeService, useClass: MockTiersV3PersPolitiqExposeeService },
        { provide: TiersCorporateV1CorporateTiersLiesService, useClass: MockTiersCorporateV1CorporateTiersLiesService }
      ]
    }).compileComponents();

    service = TestBed.inject(DonneesLiensService);
  }));

  it('should create', () => {
    expect(service).toBeDefined();
  });

  it('completerInfosPPE: avec ppe declaration', () => {
    const listeLienNominations: INominationsReglementaires[] = [
      {
        fonction: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
        identite: '',
        numeroPersonne: '10730153',
        ppe: false,
        provenanceStatutPpe: ''
      }
    ];
    service.completerInfosPPE('', listeLienNominations, true).subscribe(data => {
      expect(data).toEqual(MockRetourCompletudePPEDeclaration);
    });
  });

  it('completerInfosPPE: avec ppe contagion', () => {
    const listeLienNominations: INominationsReglementaires[] = [
      {
        fonction: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
        identite: '',
        numeroPersonne: '10730153',
        ppe: false,
        provenanceStatutPpe: ''
      }
    ];
    const sortiePPEContagion = MockRestPersPolitiqExposee;
    sortiePPEContagion.detailsSensibilitePersPPE.codeStatutPPE = 'Q';
    jest.spyOn(TiersConformiteV1PersPolitiqExposeeService.prototype as any, 'getPersProlitiqExposee').mockResolvedValue(sortiePPEContagion);
    service.completerInfosPPE('', listeLienNominations, true).subscribe(data => {
      expect(data).toEqual(MockRetourCompletudePPEContagion);
    });
  });

  it('completerInfosPPE: sans ppe', () => {
    const listeLienNominations: INominationsReglementaires[] = [
      {
        fonction: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
        identite: '',
        numeroPersonne: '10730153',
        ppe: false,
        provenanceStatutPpe: ''
      }
    ];
    const sortieSansPPE = MockRestPersPolitiqExposee;
    sortieSansPPE.detailsSensibilitePersPPE.codeStatutPPE = 'N';
    jest.spyOn(TiersConformiteV1PersPolitiqExposeeService.prototype as any, 'getPersProlitiqExposee').mockResolvedValue(sortieSansPPE);
    service.completerInfosPPE('', listeLienNominations, true).subscribe(data => {
      expect(data).toEqual(MockRetourCompletudeSansPPE);
    });
  });

  it('completerInfosPPE: Liste Lien vide', () => {
    service.completerInfosPPE('', []).subscribe(data => {
      expect(data).toEqual([]);
    });
  });

  // it('beneficiaireEffectifRestToApp', () => {
  //   let beRest = {
  //     identifiantTiersEnRelation: 10730153,
  //     dateCreation: '2012-12-14',
  //     codeType: '538',
  //     dateMiseAJour: '2012-12-14',
  //     referencePieceJustificative: "Carte d'identité",
  //     dateDebutEffet: '2012-12-14',
  //     dateFinEffet: '2900-01-01',
  //     designationCourte: 'RIQUARD  MURIEL',
  //     codeFamille: 'GR',
  //     codeCaracteristique: '2',
  //     codeQualification: null,
  //     pourcentageCapitalistique: 25,
  //     numero: 0,
  //     libelleType: 'BENEFICIAIRE EFFECTIF',
  //     codeSens: 2,
  //     codePersonnaliteJuridique: '1',
  //     referenceLocataire: null,
  //     tauxDroitVote: 10,
  //     codeCategorieLien: null,
  //     eligibleSponsorFinancier: null,
  //     estSponsorFinancier: null,
  //     pourcentageCapitalIndirect: 0,
  //     tauxDroitVoteIndirect: 0
  //   };

  //   let beRetour = {
  //     numeroPersonne: '10730153',
  //     pourcentageDetention: '10%',
  //     gouvernanceDetention: TYPE_GOUVERNANCE_DROIT_VOTE
  //   };
  //   const resultBEDroitVote = (DonneesLiensService.prototype as any).beneficiaireEffectifRestToApp(beRest, 1);
  //   expect(resultBEDroitVote).toEqual(beRetour);

  //   beRetour.pourcentageDetention = '25%';
  //   beRetour.gouvernanceDetention = TYPE_GOUVERNANCE_CAPITAL;
  //   const resultBECapital = (DonneesLiensService.prototype as any).beneficiaireEffectifRestToApp(beRest, 2);
  //   expect(resultBECapital).toEqual(beRetour);

  //   beRetour.pourcentageDetention = '0%';
  //   beRetour.gouvernanceDetention = TYPE_GOUVERNANCE_REPRESENTANT_LEGAL;
  //   const resultBERepLeg = (DonneesLiensService.prototype as any).beneficiaireEffectifRestToApp(beRest, 3);
  //   expect(resultBERepLeg).toEqual(beRetour);

  //   beRetour.pourcentageDetention = '0%';
  //   beRetour.gouvernanceDetention = TYPE_GOUVERNANCE_AUTRE;
  //   const resultBEAutre = (DonneesLiensService.prototype as any).beneficiaireEffectifRestToApp(beRest, 4);
  //   expect(resultBEAutre).toEqual(beRetour);
  // });

  it('getDonneesLiens', () => {
    service.getDonneesLiens('', '').subscribe(data => {
      expect((service as any).filtrerNominationsReglementaires).toHaveBeenCalled();
      expect((service as any).filtrerBeneficiairesEffectifs).toHaveBeenCalled();
    });
  });
});

class MockTiersCorporateV1CorporateTiersLiesService {
  getCorporateTiersLies(
    codeEtablissement: string,
    identifiantTiers: number,
    codeSens: number,
    codeCategorieLien: string
  ): Observable<RessourceTiersCorporateV1CorporateTiersLies.ICorporateTiersLies> {
    return of(MockRestCorporateTiersLies);
  }
}

class MockTiersV3PersPolitiqExposeeService {
  getPersProlitiqExposee(
    codeEtablissement: string,
    idPersonne: number
  ): Observable<RessourceTiersConformiteV1PersPolitiqExposee.IAutoDeclarationPEEPers> {
    return of(MockRestPersPolitiqExposee);
  }
}

export const MockRetourCompletudePPEDeclaration: INominationsReglementaires[] = [
  {
    fonction: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
    identite: '',
    numeroPersonne: '10730153',
    ppe: true,
    provenanceStatutPpe: PPE_DECLARATION
  }
];

export const MockRetourCompletudePPEContagion: INominationsReglementaires[] = [
  {
    fonction: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
    identite: '',
    numeroPersonne: '10730153',
    ppe: true,
    provenanceStatutPpe: PPE_CONTAGION
  }
];

export const MockRetourCompletudeSansPPE: INominationsReglementaires[] = [
  {
    fonction: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
    identite: '',
    numeroPersonne: '10730153',
    ppe: false,
    provenanceStatutPpe: ''
  }
];

export const MockRestPersPolitiqExposee: RessourceTiersConformiteV1PersPolitiqExposee.IAutoDeclarationPEEPers = {
  codeEtablissement: '17515',
  numeroPersonne: 94211213,
  codeAutoDeclarationPers: 'N',
  codeResident: null,
  codeInseePaysResFisc: null,
  idFonctionFormulaire: null,
  codeRQ1FonctionPPE: null,
  codeRQ2FonctionPPE: null,
  detailsSensibilitePersPPE: {
    date1ereSurveillance: null,
    dateDerniereMajSensi: null,
    codeModeCalculScoreVOR: null,
    refExtAgentForceurScoreVOR: 0,
    datePremierRetourAutoDecl: null,
    dateMajRetourAutoDecl: '0001-01-01',
    idElementStructure: 454972,
    idElementStructure1: 304410,
    codeDegreSensiPers: null,
    codeStatutPPE: 'C'
  }
};

export const MockRestCorporateTiersLies: RessourceTiersCorporateV1CorporateTiersLies.ICorporateTiersLies = {
  identifiantTiers: 55262838,
  listeLien: [
    {
      identifiantTiersEnRelation: 10730153,
      dateCreation: '2012-12-14',
      codeType: '697',
      dateMiseAJour: '2012-12-14',
      referencePieceJustificative: "Carte d'identité",
      dateDebutEffet: '2012-12-14',
      dateFinEffet: '2900-01-01',
      designationCourte: 'RIQUARD  MURIEL',
      codeFamille: 'FO',
      codeCaracteristique: '2',
      codeQualification: null,
      pourcentageCapitalistique: 25,
      numero: 0,
      libelleType: 'DIRIGEANT',
      codeSens: 2,
      codePersonnaliteJuridique: '1',
      referenceLocataire: null,
      tauxDroitVote: 0,
      codeCategorieLien: null,
      eligibleSponsorFinancier: null,
      estSponsorFinancier: null,
      pourcentageCapitalIndirect: 0,
      tauxDroitVoteIndirect: 0
    },
    {
      identifiantTiersEnRelation: 10730153,
      dateCreation: '2012-12-14',
      codeType: '538',
      dateMiseAJour: '2012-12-14',
      referencePieceJustificative: "Carte d'identité",
      dateDebutEffet: '2012-12-14',
      dateFinEffet: '2900-01-01',
      designationCourte: 'RIQUARD  MURIEL',
      codeFamille: 'GR',
      codeCaracteristique: '2',
      codeQualification: null,
      pourcentageCapitalistique: 25,
      numero: 0,
      libelleType: 'BENEFICIAIRE EFFECTIF',
      codeSens: 2,
      codePersonnaliteJuridique: '1',
      referenceLocataire: null,
      tauxDroitVote: 0,
      codeCategorieLien: null,
      eligibleSponsorFinancier: null,
      estSponsorFinancier: null,
      pourcentageCapitalIndirect: 0,
      tauxDroitVoteIndirect: 0
    }
  ],
  codeEtablissement: '13135',
  indicateurBordereauImprimer: false,
  listeRepresentant: null
};
