import { async, TestBed } from '@angular/core/testing';
import { NgxsModule } from '@ngxs/store';
import { LIBELLE_ALERTE_EAI_CHANGEMENT_CIRCONSTANCES } from '../../constantes/ihm.constantes';
import { AppEnum } from '../../enums/app-enums';
import { AlertesTopCCService } from './alertes-topcc.service';

describe('AlertesTopCCService', () => {
  let service: AlertesTopCCService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgxsModule.forRoot([])],
      providers: [AlertesTopCCService]
    }).compileComponents();

    service = TestBed.inject(AlertesTopCCService);
  }));

  it('should create', () => {
    expect(service).toBeDefined();
  });

  it("ajoute un liste d'alertes à la liste", () => {
    service.listeAlertes = [
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_STATUTS,
        entete: 'Statuts',
        message: 'Justificatif manquant',
        isBloquante: true,
        isDRC: true
      }
    ];

    service.ajouterListeAlerte(mockListeAlertes);
    expect(service.listeAlertes).toEqual(mockListeAlertesCompletee);
  });

  it("ajoute un liste d'alertes à la liste", () => {
    service.listeAlertes = [
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
        entete: 'Capacité Professionnelle',
        message: "Justificatif d'identité manquant",
        isBloquante: true,
        isDRC: true
      }
    ];

    service.ajouterAlerte({
      codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_STATUTS,
      entete: 'Statuts',
      message: 'Justificatif manquant',
      isBloquante: true,
      isDRC: true
    });
    expect(service.listeAlertes).toEqual([
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_STATUTS,
        entete: 'Statuts',
        message: 'Justificatif manquant',
        isBloquante: true,
        isDRC: true
      },
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
        entete: 'Capacité Professionnelle',
        message: "Justificatif d'identité manquant",
        isBloquante: true,
        isDRC: true
      }
    ]);
  });

  it('filtre liste alerte par bloc Top CC', () => {
    service.listeAlertes = mockListeAlertesCompletee;

    const retour = service.filtrerListeAlertes(AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_TOP_CC);
    expect(retour).toEqual([
      {
        codeAppartenanceBloc: 0,
        entete: 'Top CC',
        isBloquante: false,
        message: 'Date limite de mise à jour de Connaissance client dépassée'
      }
    ]);
  });

  it('filtre liste alerte vide', () => {
    service.listeAlertes = null;

    const retour = service.filtrerListeAlertes(AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_ACTIVITE_ECO);
    expect(retour).toEqual([]);
  });

  it('filtrer Liste Alertes par Changement Circonstances', () => {
    service.listeAlertes = mockListeAlertesAvecChangementCirconstance;

    const retour = service.filtrerListeAlertesChangementCirconstances();
    expect(retour).toEqual([
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EAI,
        entete: 'EAI',
        message: LIBELLE_ALERTE_EAI_CHANGEMENT_CIRCONSTANCES,
        isBloquante: true
      }
    ]);
  });

  it('filtrer Liste Alertes vide par Changement Circonstances', () => {
    service.listeAlertes = null;

    const retour = service.filtrerListeAlertesChangementCirconstances();
    expect(retour).toEqual([]);
  });

  it('filtrer Liste Alertes par type bloquant', () => {
    service.listeAlertes = mockListeAlertes;

    const retour = service.filtrerListeAlertesBloquantes();
    expect(retour).toEqual([
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
        entete: 'Coordonnées',
        message: 'Justificatif manquant',
        isBloquante: true,
        isDRC: true
      },
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
        entete: 'Capacité Professionnelle',
        message: "Justificatif d'identité manquant",
        isBloquante: true,
        isDRC: true
      }
    ]);
  });

  it('filtrer Liste Alertes vide par type bloquant', () => {
    service.listeAlertes = null;

    const retour = service.filtrerListeAlertesBloquantes();
    expect(retour).toEqual([]);
  });

  it('filtrer Liste Alertes en DRC', () => {
    service.listeAlertes = mockListeAlertes;

    const retour = service.filtrerListeAlertesDRC();
    expect(retour).toEqual([
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
        entete: 'Coordonnées',
        message: 'Justificatif manquant',
        isBloquante: true,
        isDRC: true
      },
      {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
        entete: 'Capacité Professionnelle',
        message: "Justificatif d'identité manquant",
        isBloquante: true,
        isDRC: true
      }
    ]);
  });

  it('filtrer Liste Alertes vide en DRC', () => {
    service.listeAlertes = null;

    const retour = service.filtrerListeAlertesDRC();
    expect(retour).toEqual([]);
  });

  it('verifierEvenementDeclencheur liste alerte vide', () => {
    service.listeAlertes = null;
    const retour = service.verifierEvenementDeclencheur();
    expect(retour).toEqual(false);
  });

  it('verifierEvenementDeclencheur liste alerte avec evnt decl', () => {
    service.listeAlertes = mockListeAlertesAvecEvenementDeclencheur;
    const retour = service.verifierEvenementDeclencheur();
    expect(retour).toEqual(true);
  });
});

const mockListeAlertes = [
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_TOP_CC,
    entete: 'Top CC',
    message: 'Date limite de mise à jour de Connaissance client dépassée',
    isBloquante: false
  },
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
    entete: 'Coordonnées',
    message: 'Justificatif manquant',
    isBloquante: true,
    isDRC: true
  },
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
    entete: 'Capacité Professionnelle',
    message: "Justificatif d'identité manquant",
    isBloquante: true,
    isDRC: true
  }
];

const mockListeAlertesAvecChangementCirconstance = [
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_TOP_CC,
    entete: 'Top CC',
    message: 'Date limite de mise à jour de Connaissance client dépassée',
    isBloquante: false
  },
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
    entete: 'Coordonnées',
    message: 'Justificatif manquant',
    isBloquante: true,
    isDRC: true
  },
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
    entete: 'Capacité Professionnelle',
    message: "Justificatif d'identité manquant",
    isBloquante: true,
    isDRC: true
  },
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EAI,
    entete: 'EAI',
    message: LIBELLE_ALERTE_EAI_CHANGEMENT_CIRCONSTANCES,
    isBloquante: true
  }
];

const mockListeAlertesAvecEvenementDeclencheur = [
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_TOP_CC,
    entete: 'Top CC',
    message: 'Date limite de mise à jour de Connaissance client dépassée',
    isBloquante: false
  },
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
    entete: 'Coordonnées',
    message: 'Justificatif manquant',
    isBloquante: true,
    isDRC: true
  },
  {
    codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
    entete: 'Capacité Professionnelle',
    message: "Justificatif d'identité manquant",
    isBloquante: true,
    isDRC: true
  },
  {
    message: 'Modification du code NAF/ Activité - DRC dégradé',
    isBloquante: true,
    isEvenementDeclencheur: true
  }
];

const mockListeAlertesCompletee = [
  { codeAppartenanceBloc: 0, entete: 'Top CC', isBloquante: false, message: 'Date limite de mise à jour de Connaissance client dépassée' },
  { codeAppartenanceBloc: 1, entete: 'Coordonnées', isBloquante: true, isDRC: true, message: 'Justificatif manquant' },
  { codeAppartenanceBloc: 2, entete: 'Statuts', isBloquante: true, isDRC: true, message: 'Justificatif manquant' },
  {
    codeAppartenanceBloc: 4,
    entete: 'Capacité Professionnelle',
    isBloquante: true,
    isDRC: true,
    message: "Justificatif d'identité manquant"
  }
];
