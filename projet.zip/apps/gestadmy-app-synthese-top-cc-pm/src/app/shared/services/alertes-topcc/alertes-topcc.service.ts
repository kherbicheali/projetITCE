import { Injectable } from '@angular/core';
import { LIBELLE_ALERTE_EAI_CHANGEMENT_CIRCONSTANCES } from '../../constantes/ihm.constantes';
import { AppEnum } from '../../enums/app-enums';
import { IAlerte } from '../../modeles/alerte.modele';

@Injectable({
  providedIn: 'root'
})
export class AlertesTopCCService {
  public listeAlertes: IAlerte[];
  public eaiNonConcerneParTopCC: boolean;
  public beNonConcerneParTopCC: boolean;

  constructor() {}

  public ajouterListeAlerte(alertes: IAlerte[]) {
    this.listeAlertes = this.listeAlertes.concat(alertes);
    this.listeAlertes.sort((a, b) => a.codeAppartenanceBloc - b.codeAppartenanceBloc);
  }

  public ajouterAlerte(alerte: IAlerte) {
    this.listeAlertes.push(alerte);
    this.listeAlertes.sort((a, b) => a.codeAppartenanceBloc - b.codeAppartenanceBloc);
  }

  public verifierEvenementDeclencheur(): boolean {
    if (this.listeAlertes) {
      return this.listeAlertes.some(alerte => alerte.isEvenementDeclencheur);
    } else {
      return false;
    }
  }

  public trierListeEvenementDeclencheur(): IAlerte[] {
    if (this.listeAlertes) {
      const listeTriee = this.listeAlertes.sort((alerte1, alerte2) => {
        if (!alerte1.isEvenementDeclencheur) return 1;
        if (!alerte2.isEvenementDeclencheur) return -1;
        return 0;
      });
      return listeTriee;
    } else {
      return [];
    }
  }

  public filtrerListeAlertes(codeAppartenanceBloc: number): IAlerte[] {
    if (this.listeAlertes) {
      return this.listeAlertes.filter(alerte => alerte.codeAppartenanceBloc === codeAppartenanceBloc);
    } else {
      return [];
    }
  }

  public filtrerListeAlertesChangementCirconstances(): IAlerte[] {
    if (this.listeAlertes) {
      return this.listeAlertes.filter(
        alerte =>
          alerte.codeAppartenanceBloc === AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EAI &&
          alerte.message === LIBELLE_ALERTE_EAI_CHANGEMENT_CIRCONSTANCES
      );
    } else {
      return [];
    }
  }

  public filtrerListeAlertesBloquantes(): IAlerte[] {
    if (this.listeAlertes) {
      return this.listeAlertes.filter(alerte => alerte.isBloquante);
    } else {
      return [];
    }
  }

  public filtrerListeAlertesDRC(): IAlerte[] {
    if (this.listeAlertes) {
      return this.listeAlertes.filter(alerte => alerte.isDRC);
    } else {
      return [];
    }
  }
}
