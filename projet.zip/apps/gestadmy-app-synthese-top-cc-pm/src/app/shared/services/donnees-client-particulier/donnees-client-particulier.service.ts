import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import {
  RessourceSyntheseV2InformationClient,
  RessourceSyntheseV2ProduitServiceClient,
  RessourceTiersV3ParticulierInformation,
  RessourceTiersV3ParticulierRevenu,
  RessourceTiersV3PatrimoineImmobilier,
  SyntheseV2InformationClientService,
  SyntheseV2ProduitServiceClientService,
  TiersV3ParticulierInformationService,
  TiersV3ParticulierRevenuService,
  TiersV3PatrimoineImmobilierService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IDonneesClientParticulier } from '../../modeles/donnees-client-particulier.modele';

@Injectable({
  providedIn: 'root'
})
export class DonneesClientParticulierService {
  constructor(
    @Inject(LOCALE_ID) public locale: string,
    private syntheseV2InfoClientService: SyntheseV2InformationClientService,
    private syntheseV2ProduitServiceClientService: SyntheseV2ProduitServiceClientService,
    private tiersV3ParticulierRevenuService: TiersV3ParticulierRevenuService,
    private tiersV3PatrimoineImmobilierService: TiersV3PatrimoineImmobilierService,
    private tiersV3ParticulierInformationService: TiersV3ParticulierInformationService
  ) {}

  public getDonneesClientParticulier(codeEtablissement: string, identifiantPersonne: string): Observable<IDonneesClientParticulier> {
    return forkJoin([
      this.tiersV3ParticulierInformationService.getParticulierInformation(codeEtablissement, +identifiantPersonne),
      this.syntheseV2InfoClientService.getInformationClient(codeEtablissement, +identifiantPersonne, false, true, true),
      this.syntheseV2ProduitServiceClientService.getProduitServiceClient(codeEtablissement, +identifiantPersonne),
      this.tiersV3ParticulierRevenuService.getParticulierRevenu(codeEtablissement, +identifiantPersonne),
      this.tiersV3PatrimoineImmobilierService.getPatrimoineImmobilier(codeEtablissement, +identifiantPersonne)
    ]).pipe(
      map(([particulierInfo, infoClient, produitServiceClient, particulierRevenu, patrimoineImmo]) => {
        const data = this.donneesClientParticulierRestToApp(
          particulierInfo,
          infoClient,
          produitServiceClient,
          particulierRevenu,
          patrimoineImmo,
          identifiantPersonne
        );
        return data;
      })
    );
  }

  public donneesClientParticulierRestToApp(
    particulierInfo: RessourceTiersV3ParticulierInformation.IParticulierInformation,
    infoClient: RessourceSyntheseV2InformationClient.IInformationClient,
    produitServiceClient: RessourceSyntheseV2ProduitServiceClient.IProduitServiceClient,
    particulierRevenu: RessourceTiersV3ParticulierRevenu.IRevenu[],
    patrimoineImmo: RessourceTiersV3PatrimoineImmobilier.IPatrimoineImmobilier[],
    identifiantPersonne: string
  ): IDonneesClientParticulier {
    const donneesClientPart = {} as IDonneesClientParticulier;
    if (particulierInfo) {
      donneesClientPart.nom = particulierInfo.nomFamillePersonnePhysique;
      donneesClientPart.prenom = particulierInfo.prenom;
      donneesClientPart.nomUsage = particulierInfo.nomMarital ? particulierInfo.nomMarital : '';
    }
    if (infoClient) {
      if (infoClient.coordonnees && infoClient.coordonnees.adresses && infoClient.coordonnees.adresses.length > 0) {
        const adressePrincipale = infoClient.coordonnees.adresses.find(adresse => adresse.codeTypeAdresse === '1');
        donneesClientPart.adresse = '';
        donneesClientPart.adresse += adressePrincipale.ligne2 ? adressePrincipale.ligne2 : '';
        donneesClientPart.adresse += adressePrincipale.ligne3
          ? (donneesClientPart.adresse.length !== 0 ? ', ' : '') + adressePrincipale.ligne3
          : '';
        donneesClientPart.adresse += adressePrincipale.ligne4
          ? (donneesClientPart.adresse.length !== 0 ? ', ' : '') + adressePrincipale.ligne4
          : '';
        donneesClientPart.adresse += adressePrincipale.ligne5
          ? (donneesClientPart.adresse.length !== 0 ? ', ' : '') + adressePrincipale.ligne5
          : '';
        donneesClientPart.adresse += adressePrincipale.ligne6
          ? (donneesClientPart.adresse.length !== 0 ? ', ' : '') + adressePrincipale.ligne6
          : '';
      }
      if (infoClient.titreSousTitre) {
        donneesClientPart.categorieSocioPro =
          infoClient.titreSousTitre.codeCategorieSocioProfessionnel + ' - ' + infoClient.titreSousTitre.libelleCSP;
        donneesClientPart.nationalite = infoClient.titreSousTitre.nationalite;
      }
    }

    if (
      produitServiceClient &&
      produitServiceClient.entiteTitulairePrive &&
      produitServiceClient.entiteTitulairePrive.compteurToutETEpargne
    ) {
      donneesClientPart.epargnePlacement = produitServiceClient.entiteTitulairePrive.compteurToutETEpargne.cumulSolde.toString();
    }

    if (particulierRevenu && particulierRevenu.length > 0) {
      let totalRevenu: number = particulierRevenu
        .filter((re: RessourceTiersV3ParticulierRevenu.IRevenu) => {
          return re.codeTypeRevenu !== 'RO' && re.codeTypeRevenu !== 'RL';
        })
        .reduce((a: number, c: RessourceTiersV3ParticulierRevenu.IRevenu) => {
          return a + c.montantPeriodiqueRevenu * c.nombrePeriode;
        }, 0);
      totalRevenu = totalRevenu / 12;
      donneesClientPart.revenusNetMensuels = this.getLibelleRevenu(totalRevenu);
    }

    if (patrimoineImmo && patrimoineImmo.length > 0) {
      const patrimoineImmobilier = `${patrimoineImmo
        .filter(e => e.identifiantPersonne === +identifiantPersonne || e.identifiantPersonne === 0)
        .reduce((a, el) => {
          return a + el.valeurEstimeeBien;
        }, 0)}`;
      donneesClientPart.patrimoineImmobilier = patrimoineImmobilier;
    }
    return donneesClientPart;
  }

  /* istanbul ignore next */
  private getLibelleRevenu(valeurRevenu: number) {
    if (Number(valeurRevenu) < 1000) {
      return 'Moins de 1 000 € net/mois';
    } else if (Number(valeurRevenu) <= 1500) {
      return 'Entre 1 000 et 1 500 € nets/mois';
    } else if (Number(valeurRevenu) <= 3000) {
      return 'Entre 1 501 et 3 000 € nets/mois';
    } else if (Number(valeurRevenu) <= 5000) {
      return 'Entre 3 001 et 5 000 € nets/mois';
    } else if (Number(valeurRevenu) <= 7000) {
      return 'Entre 5 001 et 7 000 € nets/mois';
    } else if (Number(valeurRevenu) <= 10000) {
      return 'Entre 7 001 et 10 000 € nets/mois';
    } else {
      return 'Plus de 10 000 € nets/mois';
    }
  }
}
