import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import {
  RessourceSynthesecorporateV1InfosAdministratives,
  RessourceTiersV3Media,
  SynthesecorporateV1InfosAdministrativesService,
  TiersV3MediaService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  CODETYPEUSAGEMEDIAMAIL,
  CODETYPEUSAGEMEDIAPART,
  CODETYPEUSAGEMEDIAPRO,
  CODETYPEUSAGEMEDIATELFIXE,
  CODETYPEUSAGEMEDIATELPORTABLE,
  DATAINCONNU,
  MEDIA_ABSENT
} from '../../constantes/ihm.constantes';
import { InformationsAdministrativesModele as modele } from '../../modeles/informations-administratives.modele';

@Injectable({
  providedIn: 'root'
})
export class InformationsAdministrativesService {
  constructor(
    private synthesecorporateV1InfosAdministrativesService: SynthesecorporateV1InfosAdministrativesService,
    private tiersV3MediaService: TiersV3MediaService,
    @Inject(LOCALE_ID) public locale: string
  ) {}

  getDonneesAdministratives(
    codeEtablissement: string,
    identifiantPersonne: string,
    estPersonnePhysique: boolean
  ): Observable<modele.IDonneesAdministratives> {
    return forkJoin([
      this.synthesecorporateV1InfosAdministrativesService.getInfosAdmin(codeEtablissement, +identifiantPersonne),
      this.tiersV3MediaService.getMedia(codeEtablissement, +identifiantPersonne)
    ]).pipe(
      map(([infoAdmin, dataMedia]) => {
        const data = this.infoAdminRestToApp(infoAdmin, dataMedia, estPersonnePhysique);
        return data;
      })
    );
  }

  /**
   * Méthode d'alimentation de l'objet métier IDonneesAdministratives
   * @param infoAdminRest Donnees du service rest infoAdministratives
   * @param datasJuridiques données de la table délocalisée IJuridique
   * @param dataNaf données de la table délocalisée INaf
   * @returns objet métier IDonneesAdministratives
   */
  infoAdminRestToApp(
    infoAdminRest: RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin,
    dataMedia: RessourceTiersV3Media.Media,
    estPersonnePhysique: boolean
  ): modele.IDonneesAdministratives {
    const donneesAdminApp = {} as modele.IDonneesAdministratives;
    donneesAdminApp.raisonSociale = infoAdminRest.raisonSociale ? infoAdminRest.raisonSociale : '';
    donneesAdminApp.nomCommercial = infoAdminRest.nomCommercialProfessionnel ? infoAdminRest.nomCommercialProfessionnel : '';
    donneesAdminApp.numeroSiren = infoAdminRest.numeroSiren ? infoAdminRest.numeroSiren : '';
    donneesAdminApp.telephonePortablePm = MEDIA_ABSENT;
    donneesAdminApp.telephoneFixePm = MEDIA_ABSENT;
    donneesAdminApp.emailPm = MEDIA_ABSENT;
    donneesAdminApp.telephoneFixePart = MEDIA_ABSENT;
    donneesAdminApp.telephonePortablePart = MEDIA_ABSENT;
    donneesAdminApp.emailPart = MEDIA_ABSENT;

    if (infoAdminRest.adresses && infoAdminRest.adresses.adresseSiege) {
      donneesAdminApp.adressePrincipale = {} as modele.IAdresse;
      donneesAdminApp.adressePrincipale.ligne2 = infoAdminRest.adresses.adresseSiege.ligne2Adresse;
      donneesAdminApp.adressePrincipale.ligne3 = infoAdminRest.adresses.adresseSiege.ligne3Adresse;
      donneesAdminApp.adressePrincipale.ligne4 = infoAdminRest.adresses.adresseSiege.ligne4Adresse;
      donneesAdminApp.adressePrincipale.ligne5 = infoAdminRest.adresses.adresseSiege.ligne5Adresse;
      donneesAdminApp.adressePrincipale.ligne6 = infoAdminRest.adresses.adresseSiege.ligne6Adresse;
    }
    if (infoAdminRest.interlocuteurPrincipal) {
      const inter = {} as modele.IInterloc;
      inter.designation = infoAdminRest.interlocuteurPrincipal.designationCourte
        ? infoAdminRest.interlocuteurPrincipal.designationCourte
        : DATAINCONNU;
      inter.medias = [];

      let med = {} as modele.IMediaPM;
      med.estMediaValeur = infoAdminRest.interlocuteurPrincipal.telephoneFixe ? true : false;
      med.type = modele.enumMediaType.TelFixe;
      med.valeur = infoAdminRest.interlocuteurPrincipal.telephoneFixe
        ? this.getFormatTelephone(infoAdminRest.interlocuteurPrincipal.telephoneFixe)
        : MEDIA_ABSENT;
      inter.medias.push(med);

      med = {} as modele.IMediaPM;
      med.estMediaValeur = infoAdminRest.interlocuteurPrincipal.telephonePortable ? true : false;
      med.type = modele.enumMediaType.TelPortable;
      med.valeur = infoAdminRest.interlocuteurPrincipal.telephonePortable
        ? this.getFormatTelephone(infoAdminRest.interlocuteurPrincipal.telephonePortable)
        : MEDIA_ABSENT;
      inter.medias.push(med);

      med = {} as modele.IMediaPM;
      med.estMediaValeur = infoAdminRest.interlocuteurPrincipal.adresseEmail ? true : false;
      med.type = modele.enumMediaType.Email;
      med.valeur = infoAdminRest.interlocuteurPrincipal.adresseEmail ? infoAdminRest.interlocuteurPrincipal.adresseEmail : MEDIA_ABSENT;
      inter.medias.push(med);
      inter.poste = infoAdminRest.interlocuteurPrincipal.typeRole ? infoAdminRest.interlocuteurPrincipal.typeRole : null;
      donneesAdminApp.interlocuteurPrincipal = inter;
    }

    if (dataMedia) {
      if (estPersonnePhysique && !donneesAdminApp.interlocuteurPrincipal) {
        // Gestion EI si pas d'interlocuteur: l'interlocuteur est l'EI lui même
        const inter = {} as modele.IInterloc;
        inter.designation = donneesAdminApp.nomCommercial ? donneesAdminApp.nomCommercial : DATAINCONNU;
        inter.medias = [];
        if (dataMedia.listeMedia && dataMedia.listeMedia.length > 0) {
          let medTel = {} as modele.IMediaPM;
          // regle: on ne prend que les media pro, si plusieurs media du meme type, on prend le preféré sinon le premier
          medTel = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIATELFIXE, true, true);
          medTel.type = modele.enumMediaType.TelFixe;
          inter.medias.push(medTel);
          let medPortable = {} as modele.IMediaPM;
          medPortable = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIATELPORTABLE, true, true);
          medPortable.type = modele.enumMediaType.TelPortable;
          inter.medias.push(medPortable);
          let medEmail = {} as modele.IMediaPM;
          medEmail = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIAMAIL, false, true);
          medEmail.type = modele.enumMediaType.Email;
          inter.medias.push(medEmail);
          donneesAdminApp.interlocuteurPrincipal = inter;
          donneesAdminApp.telephonePortablePm = medPortable && medPortable.valeur !== MEDIA_ABSENT ? medPortable.valeur : MEDIA_ABSENT;
          donneesAdminApp.telephoneFixePm = medTel && medTel.valeur !== MEDIA_ABSENT ? medTel.valeur : MEDIA_ABSENT;
          donneesAdminApp.emailPm = medEmail && medEmail.valeur !== MEDIA_ABSENT ? medEmail.valeur : MEDIA_ABSENT;

          let medTelPart = {} as modele.IMediaPM;
          // regle: on ne prend que les media part, si plusieurs media du meme type, on prend le preféré sinon le premier
          medTelPart = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIATELFIXE, true, false);
          medTelPart.type = modele.enumMediaType.TelFixe;
          donneesAdminApp.telephoneFixePart = medTelPart && medTelPart.valeur !== MEDIA_ABSENT ? medTelPart.valeur : MEDIA_ABSENT;
          let medPortablePart = {} as modele.IMediaPM;
          // regle: on ne prend que les media part, si plusieurs media du meme type, on prend le preféré sinon le premier
          medPortablePart = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIATELPORTABLE, true, false);
          medPortablePart.type = modele.enumMediaType.TelPortable;
          donneesAdminApp.telephonePortablePart =
            medPortablePart && medPortablePart.valeur !== MEDIA_ABSENT ? medPortablePart.valeur : MEDIA_ABSENT;
          let medEmailPart = {} as modele.IMediaPM;
          // regle: on ne prend que les media part, si plusieurs media du meme type, on prend le preféré sinon le premier
          medEmailPart = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIAMAIL, false, false);
          medEmailPart.type = modele.enumMediaType.Email;
          donneesAdminApp.emailPart = medEmailPart && medEmailPart.valeur !== MEDIA_ABSENT ? medEmailPart.valeur : MEDIA_ABSENT;
        }
      } else {
        if (dataMedia.listeMedia && dataMedia.listeMedia.length > 0) {
          let medTel = {} as modele.IMediaPM;
          // regle: on ne prend que les media pro, si plusieurs media du meme type, on prend le preféré sinon le premier
          medTel = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIATELFIXE, true, true);
          medTel.type = modele.enumMediaType.TelFixe;
          let medPortable = {} as modele.IMediaPM;
          medPortable = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIATELPORTABLE, true, true);
          medPortable.type = modele.enumMediaType.TelPortable;
          let medEmail = {} as modele.IMediaPM;
          medEmail = this.getMediaProPrefOuPremier(dataMedia.listeMedia, CODETYPEUSAGEMEDIAMAIL, false, true);
          medEmail.type = modele.enumMediaType.Email;
          donneesAdminApp.telephonePortablePm = medPortable && medPortable.valeur !== MEDIA_ABSENT ? medPortable.valeur : MEDIA_ABSENT;
          donneesAdminApp.telephoneFixePm = medTel && medTel.valeur !== MEDIA_ABSENT ? medTel.valeur : MEDIA_ABSENT;
          donneesAdminApp.emailPm = medEmail && medEmail.valeur !== MEDIA_ABSENT ? medEmail.valeur : MEDIA_ABSENT;
        }
      }
    }
    return donneesAdminApp;
  }

  /* istanbul ignore next */
  private getFormatTelephone(numTel: string): string {
    let formatedTel = numTel;
    if (numTel && !isNaN(Number(numTel))) {
      // cas 10 chiffres
      if (numTel.length < 10) {
        formatedTel = numTel;
      } else {
        if (formatedTel.length === 10) {
          formatedTel = this.formatNumTelephone(numTel);
        } else {
          // cas plus de 10 chiffre: les 10 derniers correspondent au numero de tel
          formatedTel = `+${numTel.substr(0, numTel.length - 10)} ${this.formatNumTelephone(numTel.slice(-10))}`;
        }
      }
    }
    return formatedTel;
  }

  /* istanbul ignore next */
  getMediaProPrefOuPremier(
    liste: RessourceTiersV3Media.ListeMedia[],
    typeMedia: string,
    isTel: boolean,
    mediaPro: boolean
  ): modele.IMediaPM {
    const rep = {} as modele.IMediaPM;
    const medPref = liste.find(med => {
      return (
        med.codeTypeUsageMedia === (mediaPro ? CODETYPEUSAGEMEDIAPRO : CODETYPEUSAGEMEDIAPART) &&
        med.codeTypeMedia === typeMedia &&
        med.indicateurPreferenceMedia
      );
    });
    const medFirst = liste.find(med => {
      return med.codeTypeUsageMedia === (mediaPro ? CODETYPEUSAGEMEDIAPRO : CODETYPEUSAGEMEDIAPART) && med.codeTypeMedia === typeMedia;
    });
    let valMed = '';
    if (medPref) {
      valMed = isTel
        ? !medPref.indicatifTelephone || medPref.indicatifTelephone === '+33'
          ? medPref.referenceAccesMedia
          : `${medPref.indicatifTelephone} ${medPref.referenceAccesMedia}`
        : medPref.referenceAccesMedia;
      rep.valeur = isTel ? this.getFormatTelephone(valMed) : medPref.referenceAccesMedia;
      rep.estMediaValeur = true;
    } else {
      valMed = medFirst
        ? isTel
          ? !medFirst.indicatifTelephone || medFirst.indicatifTelephone === '+33'
            ? medFirst.referenceAccesMedia
            : `${medFirst.indicatifTelephone} ${medFirst.referenceAccesMedia}`
          : medFirst.referenceAccesMedia
        : '';
      rep.valeur = medFirst ? (isTel ? this.getFormatTelephone(valMed) : valMed) : MEDIA_ABSENT;
      rep.estMediaValeur = rep.valeur !== MEDIA_ABSENT;
    }
    return rep;
  }

  /* istanbul ignore next */
  private formatNumTelephone(num: string): string {
    if (num) {
      return num.match(/.{1,2}/g).join(' ');
    } else {
      return num;
    }
  }
}
