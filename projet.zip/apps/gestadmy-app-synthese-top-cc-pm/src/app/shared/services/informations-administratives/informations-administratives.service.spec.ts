import { async, TestBed } from '@angular/core/testing';
import {
  RessourceSynthesecorporateV1InfosAdministratives,
  RessourceTiersV3Media,
  SynthesecorporateV1InfosAdministrativesService,
  TiersV3MediaService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { NgxsModule } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { MEDIA_ABSENT } from '../../constantes/ihm.constantes';
import { InformationsAdministrativesModele } from '../../modeles/informations-administratives.modele';
import { InformationsAdministrativesService } from './informations-administratives.service';

describe('InformationsAdministrativesService', () => {
  let service: InformationsAdministrativesService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgxsModule.forRoot([])],
      providers: [
        InformationsAdministrativesService,
        { provide: SynthesecorporateV1InfosAdministrativesService, useClass: MockSynthesecorporateV1InfosAdministrativesService },
        { provide: TiersV3MediaService, useClass: MockTiersV3MediaService }
      ]
    }).compileComponents();

    service = TestBed.inject(InformationsAdministrativesService);
  }));

  it('should create', () => {
    expect(service).toBeDefined();
  });

  it('infoAdminRestToApp: infoAdminComplet', () => {
    const result = service.infoAdminRestToApp(MockRestInfoAdminComplet, undefined, false);
    expect(result).toEqual(MockAppInfoAdminComplet);
  });

  it('infoAdminRestToApp: infoAdmin avec données manquantes', () => {
    const result = service.infoAdminRestToApp(MockRestInfoAdminDonneesManquantes, undefined, false);
    expect(result).toEqual(MockAppInfoAdminDonnesManquantes);
  });

  it('infoAdminRestToApp: infoAdmin sans adresses', () => {
    const result = service.infoAdminRestToApp(MockRestInfoAdminNoAdresses, undefined, false);
    expect(result).toEqual(MockAppInfoAdminNoAdresses);
  });

  it('infoAdminRestToApp: infoAdmin Sans interlocuteur ppal avec media tiers', () => {
    const result = service.infoAdminRestToApp(MockRestInfoAdminNoContactPpal, MockRestTiersMedia, true);
    expect(result).toEqual(MockAppInfoAdminNoContactPPalAvecMedia);
  });

  it('infoAdminRestToApp: infoAdmin Sans interlocuteur ppal avec media tiers vide', () => {
    const result = service.infoAdminRestToApp(MockRestInfoAdminNoContactPpal, MockRestTiersMediaVide, true);
    expect(result).toEqual(MockAppInfoAdminNoContactPPalSansMedia);
  });

  it('infoAdminRestToApp: infoAdmin Sans interlocuteur ppal et sans media tiers vide', () => {
    const result = service.infoAdminRestToApp(MockRestInfoAdminNoContactPpal, null, true);
    expect(result).toEqual(MockAppInfoAdminNoContactPPalSansMedia);
  });

  it('getDonneesAdministratives: personne physique', () => {
    spyOn(service, 'infoAdminRestToApp');
    service.getDonneesAdministratives('', '', true).subscribe(data => {
      expect(service.infoAdminRestToApp).toHaveBeenCalled();
    });
  });

  it('getDonneesAdministratives: personne morale', () => {
    spyOn(service, 'infoAdminRestToApp');
    service.getDonneesAdministratives('', '', false).subscribe(data => {
      expect(service.infoAdminRestToApp).toHaveBeenCalled();
    });
  });
});

class MockTiersV3MediaService {
  getMedia(codeEtablissement: string, identifiantPersonne: number): Observable<RessourceTiersV3Media.Media> {
    return of(MockRestTiersMedia);
  }
}

// tslint:disable-next-line: max-classes-per-file
class MockSynthesecorporateV1InfosAdministrativesService {
  getInfosAdmin(
    codeEtablissement: string,
    identifiantPersonne: number
  ): Observable<RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin> {
    return of(MockRestInfoAdminComplet);
  }
}

export const MockAppInfoAdminComplet: InformationsAdministrativesModele.IDonneesAdministratives = {
  adressePrincipale: { ligne2: null, ligne3: null, ligne4: '1    RUE DU GAZ', ligne5: 'BP 93330', ligne6: '12033 RODEZ CEDEX 9' },
  interlocuteurPrincipal: {
    designation: 'MR JALADEAU FREDERIC',
    medias: [
      { estMediaValeur: true, type: 1, valeur: '05 65 73 31 92' },
      { estMediaValeur: false, type: 2, valeur: 'Non Renseigné' },
      { estMediaValeur: true, type: 0, valeur: 'fjaladeau@udaf12.fr' }
    ],
    poste: 'CONTACT BANQUE A DISTANCE'
  },
  nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  telephonePortablePart: MEDIA_ABSENT,
  telephoneFixePart: MEDIA_ABSENT,
  telephonePortablePm: MEDIA_ABSENT,
  telephoneFixePm: MEDIA_ABSENT,
  emailPart: MEDIA_ABSENT,
  emailPm: MEDIA_ABSENT
};

export const MockAppInfoAdminDonnesManquantes: InformationsAdministrativesModele.IDonneesAdministratives = {
  adressePrincipale: { ligne2: null, ligne3: null, ligne4: '1    RUE DU GAZ', ligne5: 'BP 93330', ligne6: '12033 RODEZ CEDEX 9' },
  interlocuteurPrincipal: {
    designation: 'MR JALADEAU FREDERIC',
    medias: [
      { estMediaValeur: false, type: 1, valeur: MEDIA_ABSENT },
      { estMediaValeur: true, type: 2, valeur: '06 45 30 67 54' },
      { estMediaValeur: false, type: 0, valeur: MEDIA_ABSENT }
    ],
    poste: null
  },
  nomCommercial: '',
  numeroSiren: '',
  raisonSociale: '',
  telephonePortablePart: MEDIA_ABSENT,
  telephoneFixePart: MEDIA_ABSENT,
  telephonePortablePm: MEDIA_ABSENT,
  telephoneFixePm: MEDIA_ABSENT,
  emailPart: MEDIA_ABSENT,
  emailPm: MEDIA_ABSENT
};

export const MockAppInfoAdminNoAdresses: InformationsAdministrativesModele.IDonneesAdministratives = {
  interlocuteurPrincipal: {
    designation: 'MR JALADEAU FREDERIC',
    medias: [
      { estMediaValeur: true, type: 1, valeur: '05 65 73 31 92' },
      { estMediaValeur: false, type: 2, valeur: 'Non Renseigné' },
      { estMediaValeur: true, type: 0, valeur: 'fjaladeau@udaf12.fr' }
    ],
    poste: 'CONTACT BANQUE A DISTANCE'
  },
  nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  telephonePortablePart: MEDIA_ABSENT,
  telephoneFixePart: MEDIA_ABSENT,
  telephonePortablePm: MEDIA_ABSENT,
  telephoneFixePm: MEDIA_ABSENT,
  emailPart: MEDIA_ABSENT,
  emailPm: MEDIA_ABSENT
};

export const MockAppInfoAdminNoContactPPalAvecMedia: InformationsAdministrativesModele.IDonneesAdministratives = {
  adressePrincipale: { ligne2: null, ligne3: null, ligne4: '1    RUE DU GAZ', ligne5: 'BP 93330', ligne6: '12033 RODEZ CEDEX 9' },
  interlocuteurPrincipal: {
    designation: 'ICYACJO EVAYEYAV EBTYTO',
    medias: [
      { estMediaValeur: true, type: 1, valeur: '01 11 11 11 11' },
      { estMediaValeur: true, type: 2, valeur: '+12 0622222222' },
      { estMediaValeur: true, type: 0, valeur: 'fxbenyczoz@bytfa.fr' }
    ]
  },
  nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  telephonePortablePm: '+12 0622222222',
  telephoneFixePm: '01 11 11 11 11',
  emailPm: 'fxbenyczoz@bytfa.fr',
  emailPart: 'fxbenyczozby@tfa.fr',
  telephoneFixePart: 'Non Renseigné',
  telephonePortablePart: 'Non Renseigné'
};

export const MockAppInfoAdminNoContactPPalSansMedia: InformationsAdministrativesModele.IDonneesAdministratives = {
  adressePrincipale: { ligne2: null, ligne3: null, ligne4: '1    RUE DU GAZ', ligne5: 'BP 93330', ligne6: '12033 RODEZ CEDEX 9' },
  nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  telephonePortablePart: MEDIA_ABSENT,
  telephoneFixePart: MEDIA_ABSENT,
  telephonePortablePm: MEDIA_ABSENT,
  telephoneFixePm: MEDIA_ABSENT,
  emailPart: MEDIA_ABSENT,
  emailPm: MEDIA_ABSENT
};

export const MockRestInfoAdminComplet: RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin = {
  codeEtablissement: '13135',
  numeroPersonne: 9038489,
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  suiviPar: 'BARDOU JOEL',
  codeTypePersonne: '0',
  codeMarche: {
    codeMarche: 'MN',
    libelleLongCodeMarche: 'ESI : MEES - Sanitaire/Médico-social/Action sociale (1,5 M€ <= budget < 10 M€)',
    libelleCourtCodeMarche: 'MEES Santé',
    libelleFamilleCodeMarche: 'ECONOMIE SOCIALE'
  },
  adresses: {
    adresseSiege: {
      ligne2Adresse: null,
      ligne3Adresse: null,
      ligne4Adresse: '1    RUE DU GAZ',
      ligne5Adresse: 'BP 93330',
      ligne6Adresse: '12033 RODEZ CEDEX 9',
      typeAdresse: '1',
      numPro: 1,
      numLieuAct: 1
    },
    adresseCorrespondance: null
  },
  interlocuteurPrincipal: {
    designationCourte: 'MR JALADEAU FREDERIC',
    adresseEmail: 'fjaladeau@udaf12.fr',
    telephoneFixe: '0565733192',
    telephonePortable: null,
    typeRole: 'CONTACT BANQUE A DISTANCE'
  },
  segmentRelationnelle: {
    codeSegment: 'BM',
    libelleLongSegment: 'A Développer',
    libelleCourtSegment: 'A_DEVP',
    libelleFamilleSegment: null
  },
  codeJuridique: '9220',
  etatPersonne: '0',
  libelleCodeNAF: null,
  codeNAF: '8899B',
  libelleElementStructure: 'ECONOMIE SOCIALE COMPTES AVEYRON',
  identifiantExterneClient: '3110191105',
  datePremiereEntreeRelation: '1981-01-01',
  nomCommercialProfessionnel: 'ICYACJO EVAYEYAV EBTYTO',
  idtRelationEconomique: 18546974,
  libelleIntituleRelation: 'GROUPE ICYACJO EVAYEYAV EBTYTO'
};

export const MockRestInfoAdminDonneesManquantes: RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin = {
  codeEtablissement: '13135',
  numeroPersonne: 9038489,
  raisonSociale: null,
  numeroSiren: null,
  suiviPar: 'BARDOU JOEL',
  codeTypePersonne: '0',
  codeMarche: {
    codeMarche: 'MN',
    libelleLongCodeMarche: 'ESI : MEES - Sanitaire/Médico-social/Action sociale (1,5 M€ <= budget < 10 M€)',
    libelleCourtCodeMarche: 'MEES Santé',
    libelleFamilleCodeMarche: 'ECONOMIE SOCIALE'
  },
  adresses: {
    adresseSiege: {
      ligne2Adresse: null,
      ligne3Adresse: null,
      ligne4Adresse: '1    RUE DU GAZ',
      ligne5Adresse: 'BP 93330',
      ligne6Adresse: '12033 RODEZ CEDEX 9',
      typeAdresse: '1',
      numPro: 1,
      numLieuAct: 1
    },
    adresseCorrespondance: null
  },
  interlocuteurPrincipal: {
    designationCourte: 'MR JALADEAU FREDERIC',
    adresseEmail: null,
    telephoneFixe: null,
    telephonePortable: '0645306754',
    typeRole: null
  },
  segmentRelationnelle: {
    codeSegment: 'BM',
    libelleLongSegment: 'A Développer',
    libelleCourtSegment: 'A_DEVP',
    libelleFamilleSegment: null
  },
  codeJuridique: '9220',
  etatPersonne: '0',
  libelleCodeNAF: null,
  codeNAF: '8899B',
  libelleElementStructure: 'ECONOMIE SOCIALE COMPTES AVEYRON',
  identifiantExterneClient: '3110191105',
  datePremiereEntreeRelation: '1981-01-01',
  nomCommercialProfessionnel: null,
  idtRelationEconomique: 18546974,
  libelleIntituleRelation: 'GROUPE ICYACJO EVAYEYAV EBTYTO'
};

export const MockRestInfoAdminNoAdresses: RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin = {
  codeEtablissement: '13135',
  numeroPersonne: 9038489,
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  suiviPar: 'BARDOU JOEL',
  codeTypePersonne: '0',
  codeMarche: {
    codeMarche: 'MN',
    libelleLongCodeMarche: 'ESI : MEES - Sanitaire/Médico-social/Action sociale (1,5 M€ <= budget < 10 M€)',
    libelleCourtCodeMarche: 'MEES Santé',
    libelleFamilleCodeMarche: 'ECONOMIE SOCIALE'
  },
  adresses: null,
  interlocuteurPrincipal: {
    designationCourte: 'MR JALADEAU FREDERIC',
    adresseEmail: 'fjaladeau@udaf12.fr',
    telephoneFixe: '0565733192',
    telephonePortable: null,
    typeRole: 'CONTACT BANQUE A DISTANCE'
  },
  segmentRelationnelle: {
    codeSegment: 'BM',
    libelleLongSegment: 'A Développer',
    libelleCourtSegment: 'A_DEVP',
    libelleFamilleSegment: null
  },
  codeJuridique: '9220',
  etatPersonne: '0',
  libelleCodeNAF: null,
  codeNAF: '8899B',
  libelleElementStructure: 'ECONOMIE SOCIALE COMPTES AVEYRON',
  identifiantExterneClient: '3110191105',
  datePremiereEntreeRelation: '1981-01-01',
  nomCommercialProfessionnel: 'ICYACJO EVAYEYAV EBTYTO',
  idtRelationEconomique: 18546974,
  libelleIntituleRelation: 'GROUPE ICYACJO EVAYEYAV EBTYTO'
};

export const MockRestTiersMediaVide: RessourceTiersV3Media.Media = {
  identificationPersonne: null,
  listeMedia: null
};

export const MockRestTiersMedia: RessourceTiersV3Media.Media = {
  identificationPersonne: {
    codeEtablissement: '13135',
    identifiantPersonne: 6706482
  },
  listeMedia: [
    {
      codeTypeMedia: '01',
      libelleTypeMedia: 'Téléphone fixe',
      codeTypeUsageMedia: 'T',
      libelleTypeUsageMedia: 'Professionnel',
      indicateurPreferenceMedia: false,
      referenceAccesMedia: '0111111111',
      indicateurOptin: true,
      commentaire: null,
      indicatifTelephone: '+33',
      indicateurSecu: false,
      indicateurProOptout: true,
      indicateurSmsFax: false
    },
    {
      codeTypeMedia: '02',
      libelleTypeMedia: 'Téléphone mobile',
      codeTypeUsageMedia: 'T',
      libelleTypeUsageMedia: 'Professionnel',
      indicateurPreferenceMedia: false,
      referenceAccesMedia: '0611111111',
      indicateurOptin: true,
      commentaire: null,
      indicatifTelephone: '+33',
      indicateurSecu: false,
      indicateurProOptout: true,
      indicateurSmsFax: false
    },
    {
      codeTypeMedia: '02',
      libelleTypeMedia: 'Téléphone mobile',
      codeTypeUsageMedia: 'T',
      libelleTypeUsageMedia: 'Professionnel',
      indicateurPreferenceMedia: true,
      referenceAccesMedia: '0622222222',
      indicateurOptin: true,
      commentaire: null,
      indicatifTelephone: '+12',
      indicateurSecu: true,
      indicateurProOptout: true,
      indicateurSmsFax: false
    },
    {
      codeTypeMedia: '03',
      libelleTypeMedia: 'E-mail',
      codeTypeUsageMedia: 'P',
      libelleTypeUsageMedia: 'Personnel',
      indicateurPreferenceMedia: true,
      referenceAccesMedia: 'fxbenyczozby@tfa.fr',
      indicateurOptin: false,
      commentaire: null,
      indicatifTelephone: null,
      indicateurSecu: false,
      indicateurProOptout: false,
      indicateurSmsFax: false
    },
    {
      codeTypeMedia: '03',
      libelleTypeMedia: 'E-mail',
      codeTypeUsageMedia: 'T',
      libelleTypeUsageMedia: 'Professionnel',
      indicateurPreferenceMedia: false,
      referenceAccesMedia: 'fxbenyczoz@bytfa.fr',
      indicateurOptin: false,
      commentaire: null,
      indicatifTelephone: null,
      indicateurSecu: false,
      indicateurProOptout: true,
      indicateurSmsFax: false
    }
  ]
};

export const MockRestInfoAdminNoContactPpal: RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin = {
  codeEtablissement: '13135',
  numeroPersonne: 9038489,
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  suiviPar: 'BARDOU JOEL',
  codeTypePersonne: '0',
  codeMarche: {
    codeMarche: 'MN',
    libelleLongCodeMarche: 'ESI : MEES - Sanitaire/Médico-social/Action sociale (1,5 M€ <= budget < 10 M€)',
    libelleCourtCodeMarche: 'MEES Santé',
    libelleFamilleCodeMarche: 'ECONOMIE SOCIALE'
  },
  adresses: {
    adresseSiege: {
      ligne2Adresse: null,
      ligne3Adresse: null,
      ligne4Adresse: '1    RUE DU GAZ',
      ligne5Adresse: 'BP 93330',
      ligne6Adresse: '12033 RODEZ CEDEX 9',
      typeAdresse: '1',
      numPro: 1,
      numLieuAct: 1
    },
    adresseCorrespondance: null
  },
  interlocuteurPrincipal: null,
  segmentRelationnelle: {
    codeSegment: 'BM',
    libelleLongSegment: 'A Développer',
    libelleCourtSegment: 'A_DEVP',
    libelleFamilleSegment: null
  },
  codeJuridique: '9220',
  etatPersonne: '0',
  libelleCodeNAF: null,
  codeNAF: '8899B',
  libelleElementStructure: 'ECONOMIE SOCIALE COMPTES AVEYRON',
  identifiantExterneClient: '3110191105',
  datePremiereEntreeRelation: '1981-01-01',
  nomCommercialProfessionnel: 'ICYACJO EVAYEYAV EBTYTO',
  idtRelationEconomique: 18546974,
  libelleIntituleRelation: 'GROUPE ICYACJO EVAYEYAV EBTYTO'
};

export const MockRestInfoAdminContactPpalNoEmail: RessourceSynthesecorporateV1InfosAdministratives.InfosAdmin = {
  codeEtablissement: '13135',
  numeroPersonne: 9038489,
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  suiviPar: 'BARDOU JOEL',
  codeTypePersonne: '0',
  codeMarche: {
    codeMarche: 'MN',
    libelleLongCodeMarche: 'ESI : MEES - Sanitaire/Médico-social/Action sociale (1,5 M€ <= budget < 10 M€)',
    libelleCourtCodeMarche: 'MEES Santé',
    libelleFamilleCodeMarche: 'ECONOMIE SOCIALE'
  },
  adresses: {
    adresseSiege: {
      ligne2Adresse: null,
      ligne3Adresse: null,
      ligne4Adresse: '1    RUE DU GAZ',
      ligne5Adresse: 'BP 93330',
      ligne6Adresse: '12033 RODEZ CEDEX 9',
      typeAdresse: '1',
      numPro: 1,
      numLieuAct: 1
    },
    adresseCorrespondance: null
  },
  interlocuteurPrincipal: {
    designationCourte: 'MR JALADEAU FREDERIC',
    adresseEmail: '',
    telephoneFixe: '0565733192',
    telephonePortable: null,
    typeRole: 'CONTACT BANQUE A DISTANCE'
  },
  segmentRelationnelle: {
    codeSegment: 'BM',
    libelleLongSegment: 'A Développer',
    libelleCourtSegment: 'A_DEVP',
    libelleFamilleSegment: null
  },
  codeJuridique: '9220',
  etatPersonne: '0',
  libelleCodeNAF: null,
  codeNAF: '8899B',
  libelleElementStructure: 'ECONOMIE SOCIALE COMPTES AVEYRON',
  identifiantExterneClient: '3110191105',
  datePremiereEntreeRelation: '1981-01-01',
  nomCommercialProfessionnel: 'ICYACJO EVAYEYAV EBTYTO',
  idtRelationEconomique: 18546974,
  libelleIntituleRelation: 'GROUPE ICYACJO EVAYEYAV EBTYTO'
};
