import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import {
  RessourceTiersConformiteV1NatureRelation,
  TiersConformiteV1NatureRelationService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ACTUALISATION_FREQUENTE, ACTUALISATION_REGULIERE, ACTUALISATION_SOUTENUE, DATAINCONNU } from '../../constantes/ihm.constantes';
import { INatureRelation } from '../../modeles/nature-relation.modele';

@Injectable({
  providedIn: 'root'
})
export class NatureRelationService {
  constructor(
    private tiersConformiteV1NatureRelationService: TiersConformiteV1NatureRelationService,
    @Inject(LOCALE_ID) public locale: string
  ) {}

  getNatureRelation(codeEtablissement: string, identifiantPersonne: string): Observable<INatureRelation> {
    return this.tiersConformiteV1NatureRelationService.getNatureRelation(codeEtablissement, +identifiantPersonne).pipe(
      map(natureRelation => {
        return this.natureRelationRestToApp(natureRelation);
      })
    );
  }

  natureRelationRestToApp(natureRelation: RessourceTiersConformiteV1NatureRelation.INatureRelation): INatureRelation {
    const natureRelationApp: INatureRelation = <INatureRelation>{};
    natureRelationApp.dateEntreeRelation = natureRelation.datePremiereEntreeEnRelation
      ? natureRelation.datePremiereEntreeEnRelation
      : DATAINCONNU;
    natureRelationApp.etablissementReferent = natureRelation.libelleEtablissementDeNotation
      ? natureRelation.libelleEtablissementDeNotation
      : DATAINCONNU;

    if (natureRelation.codeDegreSensibilitePersonne) {
      switch (natureRelation.codeDegreSensibilitePersonne) {
        case 'T': {
          natureRelationApp.actualisation = ACTUALISATION_SOUTENUE;
          break;
        }
        case 'S': {
          natureRelationApp.actualisation = ACTUALISATION_FREQUENTE;
          break;
        }
        case 'N': {
          natureRelationApp.actualisation = ACTUALISATION_REGULIERE;
          break;
        }
        case 'A': {
          natureRelationApp.actualisation = null;
          break;
        }
      }
    }
    const mois = ' mois';
    natureRelationApp.delaiActualisation = natureRelation.delaiPeriodeActualisation
      ? natureRelation.delaiPeriodeActualisation + mois
      : null;
    return natureRelationApp;
  }
}
