import { async, TestBed } from '@angular/core/testing';
import {
  RessourceTiersConformiteV1NatureRelation,
  TiersConformiteV1NatureRelationService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { NgxsModule } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { NatureRelationService } from './nature-relation.service';

describe('NatureRelationService', () => {
  let service: NatureRelationService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgxsModule.forRoot([])],
      providers: [
        NatureRelationService,
        { provide: TiersConformiteV1NatureRelationService, useClass: MockTiersConformiteV1NatureRelationService }
      ]
    }).compileComponents();

    service = TestBed.inject(NatureRelationService);
  }));

  it('should create', () => {
    expect(service).toBeDefined();
  });

  it('récupère la nature de la relation', () => {
    spyOn(service, 'natureRelationRestToApp');
    service.getNatureRelation('', '').subscribe(data => {
      expect(service.natureRelationRestToApp).toHaveBeenCalled();
    });
  });

  it('natureRelationRestToApp: NatureRelation complet avec actualisation frequente', () => {
    const result = service.natureRelationRestToApp(MockRestNatureRelationComplet);
    expect(result).toEqual(MockAppNatureRelationComplet);
  });

  it('natureRelationRestToApp: NatureRelation complet avec actualisation soutenue', () => {
    const result = service.natureRelationRestToApp(MockRestNatureRelationCompletActualisationSoutenue);
    expect(result).toEqual(MockAppNatureRelationCompletSoutenue);
  });

  it('natureRelationRestToApp: NatureRelation complet avec actualisation reguliere', () => {
    const result = service.natureRelationRestToApp(MockRestNatureRelationCompletActualisationReguliere);
    expect(result).toEqual(MockAppNatureRelationCompletReguliere);
  });

  it('natureRelationRestToApp: NatureRelation complet avec actualisation nulle', () => {
    const result = service.natureRelationRestToApp(MockRestNatureRelationCompletActualisationNulle);
    expect(result).toEqual(MockAppNatureRelationCompletNulle);
  });

  it('natureRelationRestToApp: NatureRelation incomplet', () => {
    const result = service.natureRelationRestToApp(MockRestNatureRelationIncomplet);
    expect(result).toEqual(MockAppNatureRelationIncomplet);
  });
});

class MockTiersConformiteV1NatureRelationService {
  getNatureRelation(
    codeEtablissement: string,
    identifiantPersonne: number
  ): Observable<RessourceTiersConformiteV1NatureRelation.INatureRelation> {
    return of(MockRestNatureRelationComplet);
  }
}

export const MockRestNatureRelationComplet: RessourceTiersConformiteV1NatureRelation.INatureRelation = {
  datePremiereEntreeEnRelation: '2018-12-06',
  codeDegreSensibilitePersonne: 'S',
  delaiPeriodeActualisation: 30,
  codeEtablissementNoteur: '17515',
  libelleEtablissementDeNotation: 'ILE DE FRANCE'
};

export const MockRestNatureRelationCompletActualisationSoutenue: RessourceTiersConformiteV1NatureRelation.INatureRelation = {
  datePremiereEntreeEnRelation: '2018-12-06',
  codeDegreSensibilitePersonne: 'T',
  delaiPeriodeActualisation: 30,
  codeEtablissementNoteur: '17515',
  libelleEtablissementDeNotation: 'ILE DE FRANCE'
};

export const MockRestNatureRelationCompletActualisationReguliere: RessourceTiersConformiteV1NatureRelation.INatureRelation = {
  datePremiereEntreeEnRelation: '2018-12-06',
  codeDegreSensibilitePersonne: 'N',
  delaiPeriodeActualisation: 30,
  codeEtablissementNoteur: '17515',
  libelleEtablissementDeNotation: 'ILE DE FRANCE'
};

export const MockRestNatureRelationCompletActualisationNulle: RessourceTiersConformiteV1NatureRelation.INatureRelation = {
  datePremiereEntreeEnRelation: '2018-12-06',
  codeDegreSensibilitePersonne: 'A',
  delaiPeriodeActualisation: 30,
  codeEtablissementNoteur: '17515',
  libelleEtablissementDeNotation: 'ILE DE FRANCE'
};

export const MockRestNatureRelationIncomplet: RessourceTiersConformiteV1NatureRelation.INatureRelation = {
  datePremiereEntreeEnRelation: null,
  codeDegreSensibilitePersonne: null,
  delaiPeriodeActualisation: null,
  codeEtablissementNoteur: '17515',
  libelleEtablissementDeNotation: null
};

export const MockAppNatureRelationComplet = {
  actualisation: 'Fréquente',
  dateEntreeRelation: '2018-12-06',
  delaiActualisation: '30 mois',
  etablissementReferent: 'ILE DE FRANCE'
};

export const MockAppNatureRelationCompletSoutenue = {
  actualisation: 'Soutenue',
  dateEntreeRelation: '2018-12-06',
  delaiActualisation: '30 mois',
  etablissementReferent: 'ILE DE FRANCE'
};

export const MockAppNatureRelationCompletReguliere = {
  actualisation: 'Régulière',
  dateEntreeRelation: '2018-12-06',
  delaiActualisation: '30 mois',
  etablissementReferent: 'ILE DE FRANCE'
};

export const MockAppNatureRelationCompletNulle = {
  actualisation: null,
  dateEntreeRelation: '2018-12-06',
  delaiActualisation: '30 mois',
  etablissementReferent: 'ILE DE FRANCE'
};

export const MockAppNatureRelationIncomplet = {
  dateEntreeRelation: 'Non Renseigné(e)',
  delaiActualisation: null,
  etablissementReferent: 'Non Renseigné(e)'
};
