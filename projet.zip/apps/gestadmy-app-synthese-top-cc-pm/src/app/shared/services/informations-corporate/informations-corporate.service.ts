import { CurrencyPipe, DatePipe } from '@angular/common';
import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import {
  RessourceTiersV2CorporateActiviteProfessionnelle,
  RessourceTiersV2CorporateInformation,
  TiersV2CorporateActiviteProfessionnelleService,
  TiersV2CorporateInformationService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { DATAINCONNU } from '../../constantes/ihm.constantes';
import { DonneesCorporateModele as modele } from '../../modeles/donnees-corporate.modele';
import { DataUtilsService } from '../utils/data-utils.service';

@Injectable({
  providedIn: 'root'
})
export class InformationsCorporateService {
  constructor(
    private tiersV2CorporateInformationService: TiersV2CorporateInformationService,
    private tiersV2CorporateActiviteProfessionnelleService: TiersV2CorporateActiviteProfessionnelleService,
    @Inject(LOCALE_ID) public locale: string,
    private datePipe: DatePipe,
    private currencyPipe: CurrencyPipe,
    private dataUtilsService: DataUtilsService
  ) {}

  getInformationsCorporate(
    codeEtablissement: string,
    identifiantPersonne: string,
    estPersonnePhysique: boolean
  ): Observable<modele.IDonneesCorporate> {
    if (!estPersonnePhysique) {
      return forkJoin([this.tiersV2CorporateInformationService.getCorporateInformation(codeEtablissement, +identifiantPersonne)]).pipe(
        map(([donneesCorporateRest]) => {
          return this.corporateInformationRestToApp(donneesCorporateRest);
        })
      );
    } else {
      return forkJoin([
        this.tiersV2CorporateActiviteProfessionnelleService.getCorporateActiviteProfessionnelle(codeEtablissement, +identifiantPersonne)
      ]).pipe(
        map(([donneesCorporateRest]) => {
          return this.corporateActiviteProfessionnelleRestToApp(donneesCorporateRest);
        })
      );
    }
  }

  /**
   * Méthode d'alimentation de l'objet métier IActiviteEconomique à partir de la ressource corporateInformation
   * @param corporateInformationRest Donnees du service rest corporateInformation
   * @returns objet métier IActiviteEconomique
   */
  corporateInformationRestToApp(
    corporateInformationRest: RessourceTiersV2CorporateInformation.ICorporateInformation
  ): modele.IDonneesCorporate {
    const donneesCorporateApp: modele.IDonneesCorporate = {
      activiteEconomique: {
        anneeDernierBilan: DATAINCONNU,
        chiffreAffaire: DATAINCONNU,
        dateArrete: DATAINCONNU,
        effectif: DATAINCONNU
      },
      existenceJuridique: {
        categorieJuridique: DATAINCONNU,
        dateCloture: DATAINCONNU,
        dateCreation: DATAINCONNU,
        montantCapitalSocial: DATAINCONNU,
        nomCommercial: DATAINCONNU,
        numeroSiren: DATAINCONNU,
        raisonSocial: DATAINCONNU,
        secteurActivite: DATAINCONNU
      },
      nombrePNDAdresseSiege: 0
    } as modele.IDonneesCorporate;

    if (corporateInformationRest) {
      donneesCorporateApp.existenceJuridique.raisonSocial = corporateInformationRest.raisonSociale
        ? corporateInformationRest.raisonSociale
        : DATAINCONNU;
      donneesCorporateApp.existenceJuridique.nomCommercial = corporateInformationRest.nomCommercial
        ? corporateInformationRest.nomCommercial
        : DATAINCONNU;
      donneesCorporateApp.existenceJuridique.numeroSiren = corporateInformationRest.numeroSiren
        ? corporateInformationRest.numeroSiren
        : DATAINCONNU;
      donneesCorporateApp.existenceJuridique.secteurActivite =
        corporateInformationRest.codeFamilleNAFINSEE && corporateInformationRest.troisDerniersCaracteresNAF
          ? corporateInformationRest.codeFamilleNAFINSEE + corporateInformationRest.troisDerniersCaracteresNAF
          : DATAINCONNU;
      donneesCorporateApp.existenceJuridique.categorieJuridique =
        corporateInformationRest.codeFamilleCategorieJuridique && corporateInformationRest.codeCategoJuridi2DerCaracteres
          ? corporateInformationRest.codeFamilleCategorieJuridique + corporateInformationRest.codeCategoJuridi2DerCaracteres
          : DATAINCONNU;
      donneesCorporateApp.existenceJuridique.dateCreation = corporateInformationRest.dateCreationJuridique
        ? this.datePipe.transform(corporateInformationRest.dateCreationJuridique, 'dd/MM/yyyy')
        : DATAINCONNU;
      donneesCorporateApp.existenceJuridique.dateCloture = corporateInformationRest.dateClotureJuridique
        ? this.datePipe.transform(corporateInformationRest.dateClotureJuridique, 'dd/MM/yyyy')
        : DATAINCONNU;

      if (corporateInformationRest.situationFinanciere) {
        donneesCorporateApp.activiteEconomique.anneeDernierBilan = corporateInformationRest.situationFinanciere.anneeChiffreAffaires
          ? corporateInformationRest.situationFinanciere.anneeChiffreAffaires.toString()
          : DATAINCONNU;
        donneesCorporateApp.activiteEconomique.chiffreAffaire = corporateInformationRest.situationFinanciere.montantChiffreAffaires
          ? this.currencyPipe.transform(
              corporateInformationRest.situationFinanciere.montantChiffreAffaires * 100,
              'K€',
              'code',
              '1.0-0',
              this.locale
            )
          : DATAINCONNU;
        donneesCorporateApp.activiteEconomique.dateArrete = corporateInformationRest.situationFinanciere.dateArreteComptable
          ? (corporateInformationRest.situationFinanciere.dateArreteComptable.toString().length > 3
              ? corporateInformationRest.situationFinanciere.dateArreteComptable.toString().substring(0, 2)
              : this.dataUtilsService.leftPadWithZero(
                  corporateInformationRest.situationFinanciere.dateArreteComptable.toString().substring(0, 1),
                  2
                )) +
            '/' +
            (corporateInformationRest.situationFinanciere.dateArreteComptable.toString().length > 3
              ? corporateInformationRest.situationFinanciere.dateArreteComptable.toString().substring(2, 4)
              : this.dataUtilsService.leftPadWithZero(
                  corporateInformationRest.situationFinanciere.dateArreteComptable.toString().substring(1, 3),
                  2
                ))
          : DATAINCONNU;
        donneesCorporateApp.activiteEconomique.effectif = corporateInformationRest.situationFinanciere.effectif
          ? corporateInformationRest.situationFinanciere.effectif.toString()
          : DATAINCONNU;
        donneesCorporateApp.existenceJuridique.montantCapitalSocial = corporateInformationRest.situationFinanciere.montantCapitalSocial
          ? this.currencyPipe.transform(
              corporateInformationRest.situationFinanciere.montantCapitalSocial,
              'EUR',
              'symbol',
              '1.0-2',
              this.locale
            )
          : DATAINCONNU;
      }
      if (corporateInformationRest.adresse) {
        donneesCorporateApp.nombrePNDAdresseSiege =
          corporateInformationRest.adresse.codeTypeRetourPTT === '1' ? corporateInformationRest.adresse.nombreRetourPTT : 0;
      }
    }
    return donneesCorporateApp;
  }

  /**
   * Méthode d'alimentation de l'objet métier IActiviteEconomique à partir de la ressource corporateActiviteProfessionnelle
   * @param corporateInformationRest Donnees du service rest corporateInformation
   * @returns objet métier IActiviteEconomique
   */
  corporateActiviteProfessionnelleRestToApp(
    corporateActiviteProfessionnelleRest: RessourceTiersV2CorporateActiviteProfessionnelle.ICorporateActiviteProfessionnelle
  ): modele.IDonneesCorporate {
    const donneesCorporateApp: modele.IDonneesCorporate = {
      activiteEconomique: {
        anneeDernierBilan: DATAINCONNU,
        chiffreAffaire: DATAINCONNU,
        dateArrete: DATAINCONNU,
        effectif: DATAINCONNU
      },
      existenceJuridique: {
        categorieJuridique: DATAINCONNU,
        dateCloture: DATAINCONNU,
        dateCreation: DATAINCONNU,
        montantCapitalSocial: DATAINCONNU,
        nomCommercial: DATAINCONNU,
        numeroSiren: DATAINCONNU,
        raisonSocial: DATAINCONNU,
        secteurActivite: DATAINCONNU
      },
      nombrePNDAdresseSiege: 0
    } as modele.IDonneesCorporate;

    if (
      corporateActiviteProfessionnelleRest.activitesProfessionnelles &&
      corporateActiviteProfessionnelleRest.activitesProfessionnelles[0]
    ) {
      donneesCorporateApp.existenceJuridique.numeroSiren = corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].numeroSiren
        ? corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].numeroSiren
        : DATAINCONNU;

      if (corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].situationFinanciere) {
        const situationFinanciere = corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].situationFinanciere;
        donneesCorporateApp.activiteEconomique.anneeDernierBilan = situationFinanciere.anneeChiffreAffaires
          ? situationFinanciere.anneeChiffreAffaires.toString()
          : DATAINCONNU;
        donneesCorporateApp.activiteEconomique.chiffreAffaire = situationFinanciere.montantChiffreAffaires
          ? this.currencyPipe.transform(situationFinanciere.montantChiffreAffaires, 'K€', 'code', '1.0-0', this.locale)
          : DATAINCONNU;
        donneesCorporateApp.existenceJuridique.montantCapitalSocial = situationFinanciere.montantCapitalSocialEnCentimes
          ? this.currencyPipe.transform(situationFinanciere.montantCapitalSocialEnCentimes / 100, 'EUR', 'symbol', '1.0-2', this.locale)
          : DATAINCONNU;
      }

      if (corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].secteurActivite) {
        const secteurActivite = corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].secteurActivite;
        donneesCorporateApp.existenceJuridique.categorieJuridique =
          secteurActivite.codeFamilleCategorieJuridique && secteurActivite.codeCategoJuridi2DerCaracteres
            ? secteurActivite.codeFamilleCategorieJuridique + secteurActivite.codeCategoJuridi2DerCaracteres
            : DATAINCONNU;
        donneesCorporateApp.existenceJuridique.secteurActivite =
          secteurActivite.codeDeLaFamilleNAF && secteurActivite.codeNAF3DerniersCaracteres
            ? secteurActivite.codeDeLaFamilleNAF + secteurActivite.codeNAF3DerniersCaracteres
            : DATAINCONNU;
      }

      if (corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].donneAdministrative) {
        const donneAdministrative = corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].donneAdministrative;
        donneesCorporateApp.activiteEconomique.dateArrete = donneAdministrative.dateArreteComptable
          ? donneAdministrative.dateArreteComptable.toString().substring(0, 2) +
            '/' +
            donneAdministrative.dateArreteComptable.toString().substring(2, 4)
          : DATAINCONNU;
        donneesCorporateApp.activiteEconomique.effectif = donneAdministrative.nombreDeSalaries
          ? donneAdministrative.nombreDeSalaries.toString()
          : DATAINCONNU;
        donneesCorporateApp.existenceJuridique.nomCommercial = donneAdministrative.nomCommercial
          ? donneAdministrative.nomCommercial
          : DATAINCONNU;
        donneesCorporateApp.existenceJuridique.raisonSocial = donneesCorporateApp.existenceJuridique.nomCommercial;
      }

      if (corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].informationJuridique) {
        const informationJuridique = corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].informationJuridique;
        donneesCorporateApp.existenceJuridique.dateCreation = informationJuridique.dateDeCreation
          ? this.datePipe.transform(informationJuridique.dateDeCreation, 'dd/MM/yyyy')
          : DATAINCONNU;
        donneesCorporateApp.existenceJuridique.dateCloture = informationJuridique.dateDeCloture
          ? this.datePipe.transform(informationJuridique.dateDeCloture, 'dd/MM/yyyy')
          : DATAINCONNU;
      }
      if (
        corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].listeAdresse &&
        corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].listeAdresse[0]
      ) {
        donneesCorporateApp.nombrePNDAdresseSiege =
          corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].listeAdresse[0].codeTypeRetourPTT === '1'
            ? corporateActiviteProfessionnelleRest.activitesProfessionnelles[0].listeAdresse[0].nombreRetourPTT
            : 0;
      }
    }
    return donneesCorporateApp;
  }
}
