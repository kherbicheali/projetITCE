import { Injectable } from '@angular/core';
import { NotificationService } from '@myway/ui';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { ErrorMessage, StorageLevel } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { PROCESSUS_LISA_CLASSEUR_CLIENT } from '../../constantes/lisa.constantes';
import { DataUtilsService } from './data-utils.service';

@Injectable({
  providedIn: 'root'
})
export class LisaUtilsService {
  constructor(
    private dataUtils: DataUtilsService,
    private contextAgentService: ContextAgentService,
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService
  ) {}

  /**
   * Méthode pour débrancher vers classeur client
   */
  public debrancherVersClasseurClient(identifiantPersonne: string): void {
    const keyValuesToAdd: Map<string, any> = new Map<string, any>([
      ['NODAPE', this.dataUtils.leftPadWithZero(identifiantPersonne, 9)],
      ['IDAFF', this.dataUtils.leftPadWithZero(identifiantPersonne, 9)],
      ['IDPN', this.dataUtils.leftPadWithZero(identifiantPersonne, 9)]
    ]);
    this.contextAgentService
      .addListToContext({
        keyValues: keyValuesToAdd,
        storageLevel: StorageLevel.Process
      })
      .subscribe(
        () => {
          this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_CLASSEUR_CLIENT }).subscribe(
            (result: LisaCallbackResult) => {},
            (erreur: ErrorMessage) => {
              this.notification.openInfo("Erreur de lancement de l'application Classeur client");
            }
          );
        },
        (erreur: ErrorMessage) => {
          this.notification.openInfo("Erreur d'enregistrement dans le contexte");
        }
      );
  }
}
