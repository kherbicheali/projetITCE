import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataUtilsService {
  /**
   * Méthode pour ajouter des 0 à gauche dans une chaine de caractères
   * @param chaine chaine initiale
   * @param size longeur souhaitée de la chaine
   */
  public leftPadWithZero(chaine: string, size: number): string {
    if (chaine && chaine.length < size) {
      let reponse = '';
      const test = Array(size + 1).join('0');
      reponse = String(test + chaine).slice(-size);
      return reponse;
    } else {
      return chaine;
    }
  }
}
