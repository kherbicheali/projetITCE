import { Injectable } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { TITRE_SANS_INFOS_CLIENT } from '../../constantes/ihm.constantes';
import { InformationsAdministrativesModele as modelDataAdmin } from '../../modeles/informations-administratives.modele';
import { ContexteState } from '../../states/contexte/contexte.state';
import { DonneesAdministrativesState } from '../../states/donnees-administratives/donnees-administratives.state';

@Injectable({
  providedIn: 'root'
})
export class HeaderUtilsService {
  @Select(DonneesAdministrativesState.getContent) donneesAdministrative$: Observable<modelDataAdmin.IDonneesAdministratives>;
  private raisonSociale: string;
  private nomCommercial: string;
  private numeroSiren: string;
  private estPersonnePhysique: boolean;

  constructor(private store: Store) {
    this.donneesAdministrative$.subscribe((data: modelDataAdmin.IDonneesAdministratives) => {
      if (data) {
        this.raisonSociale = data.raisonSociale;
        this.nomCommercial = data.nomCommercial;
        this.numeroSiren = data.numeroSiren;
        this.estPersonnePhysique = this.store.selectSnapshot(ContexteState.getContent).estPersonnePhysique;
      }
    });
  }

  getTitle(): string {
    return TITRE_SANS_INFOS_CLIENT;
  }

  getSousTitre(): string {
    let soustitre: string = ' - SIREN N° ';
    if (!this.estPersonnePhysique && this.raisonSociale && this.numeroSiren) {
      soustitre = this.raisonSociale + ' - SIREN N° ' + this.numeroSiren;
    } else if (this.estPersonnePhysique && this.nomCommercial && this.numeroSiren) {
      soustitre = this.nomCommercial + ' - SIREN N° ' + this.numeroSiren;
    }
    return soustitre;
  }
}
