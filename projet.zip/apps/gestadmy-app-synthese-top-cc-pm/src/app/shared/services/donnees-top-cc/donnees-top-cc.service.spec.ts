import { DatePipe } from '@angular/common';
import { async, TestBed } from '@angular/core/testing';
import {
  ClasseurclientV1DossierReglementaireClientService,
  RessourceClasseurclientV1DossierReglementaireClient,
  RessourceTiersConformiteV1CouleurTopCC,
  RessourceTiersConformiteV1RevueTopCC,
  RessourceTiersCorporateServicV1DocRevisionAnnuelle,
  RessourceTiersV2CorporateEtablissement,
  TiersConformiteV1CouleurTopCCService,
  TiersConformiteV1RevueTopCCService,
  TiersCorporateServicV1DocRevisionAnnuelleService,
  TiersV2CorporateEtablissementService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { NgxsModule } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { DATAINCONNU } from '../../constantes/ihm.constantes';
import { AlertesTopCCService } from '../alertes-topcc/alertes-topcc.service';
import { DataUtilsService } from '../utils/data-utils.service';
import { DonneesTopCCService } from './donnees-top-cc.service';

describe('DonneesTopCCService', () => {
  let service: DonneesTopCCService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgxsModule.forRoot([])],
      providers: [
        DonneesTopCCService,
        { provide: TiersConformiteV1CouleurTopCCService, useClass: MockTiersConformiteV1CouleurTopCCService },
        { provide: TiersConformiteV1RevueTopCCService, useClass: MockTiersConformiteV1RevueTopCCService },
        { provide: ClasseurclientV1DossierReglementaireClientService, useClass: MockClasseurclientV1DossierReglementaireClientService },
        { provide: TiersV2CorporateEtablissementService, useClass: MockTiersV2CorporateEtablissementService },
        { provide: TiersCorporateServicV1DocRevisionAnnuelleService, useClass: MockTiersCorporateServicV1DocRevisionAnnuelleService },
        DatePipe,
        AlertesTopCCService,
        DataUtilsService
      ]
    }).compileComponents();

    service = TestBed.inject(DonneesTopCCService);
  }));

  it('should create', () => {
    expect(service).toBeDefined();
  });

  it('récupère les donnees du Top CC', () => {
    spyOn(service, 'donneesTopCCRestToApp');
    service.getDonneesTopCC('', '', false).subscribe(data => {
      expect(service.donneesTopCCRestToApp).toHaveBeenCalled();
    });
  });

  it('donneesTopCCRestToApp: CouleurTopCC complet', () => {
    service['alertesTopCCService'].listeAlertes = [];
    const result = service.donneesTopCCRestToApp(MockRestCouleurTopCCComplet, infoDRCCompletMock, corporateEtabRestMock, false);
    expect(result).toEqual(MockAppDonneesTopCCComplet);
    expect(service['alertesTopCCService'].listeAlertes).toEqual([]);
  });

  it('donneesTopCCRestToApp: CouleurTopCC DRC KO', () => {
    service['alertesTopCCService'].listeAlertes = [];
    const result = service.donneesTopCCRestToApp(MockRestCouleurTopCcDrcKo, infoDRCIncompletMock, corporateEtabRestMock, false);
    expect(result).toEqual(MockAppDonneesTopCCDrcKo);
    expect(service['alertesTopCCService'].listeAlertes).toEqual(MockAppListeAlertesDrcKo);
  });
});

class MockTiersConformiteV1CouleurTopCCService {
  getCouleurTopCC(
    codeEtablissement: string,
    identifiantPersonne: number
  ): Observable<RessourceTiersConformiteV1CouleurTopCC.ICouleurTopCC> {
    return of(MockRestCouleurTopCCComplet);
  }
}

class MockTiersCorporateServicV1DocRevisionAnnuelleService {
  postGenererArchiverEditionsRevision(
    input: RessourceTiersCorporateServicV1DocRevisionAnnuelle.IInGenererEditions
  ): Observable<RessourceTiersCorporateServicV1DocRevisionAnnuelle.IOutGenererArchiverEditions> {
    return of(<RessourceTiersCorporateServicV1DocRevisionAnnuelle.IOutGenererArchiverEditions>{});
  }
}

class MockTiersV2CorporateEtablissementService {
  getCorporateEtablissement(
    codeEtablissement: string,
    identifiantPersonne: number
  ): Observable<RessourceTiersV2CorporateEtablissement.ICorporateEtablissement> {
    return of(corporateEtabRestMock);
  }
}

const corporateEtabRestMock: RessourceTiersV2CorporateEtablissement.ICorporateEtablissement = {
  gestionSuite: {
    indicateurListeSuivre: 'F',
    contexteRepositionnementListe: null
  },
  listeMessageFonctionnel: null,
  listeEtablissement: [
    {
      designationCourteLieuActivite: 'XXXXX',
      numeroTelecopieurLieuActivite: '0556081422',
      effectifDuLieuActivite: 0,
      enseigneCommercialeLieuActivit: 'FENTO JCY',
      designationLongueLieuActivite: 'XXXXX',
      numeroSIRENProfessionnel: '398828814',
      numeroComplementSIRETEtabli: '00069',
      codeFamilleAPEINSEE: '74',
      deuxDerniersCaracteresAPE: '1J',
      codeResident: '1',
      codeFamilleNAFINSEE: '70',
      troisDerniersCaracteresNAF: '10Z',
      codeClientTiers: null,
      activiteEconomiqueReelleLieu: null,
      libelleEtablissement: null,
      codeEtablissement: '42559',
      identifiantTiers: 904025074,
      dateDebutExploitationLieuActivite: '1994-07-04',
      dateFinExploitationLieuActivite: null,
      numeroLieuActivite: 1,
      numeroProfessionnel: 1,
      numeroTelexLieuActivite: null,
      listeAdresse: [
        {
          identifiant: 800007029432,
          codeType: '1',
          libelleType: null,
          ligne2AFNOR: null,
          ligne3AFNOR: null,
          ligne4AFNOR: '35 AVENUE AUGUSTE FERRET',
          ligne5AFNOR: null,
          ligne6AFNOR: '33110 LE BOUSCAT',
          codePostalPTT: '33110',
          codeInseePays: '99000',
          codeISOPays: 'FR',
          libelleISOPays: 'FRANCE',
          codeInseeLocalite: '33069',
          libelleInseeLocalite: 'LE BOUSCAT',
          codeTypeRetourPTT: null,
          nombreRetourPTT: 0,
          dateDernierRetourPTT: null,
          indicateurConfirmeAdresse: null
        }
      ]
    }
  ]
};

class MockTiersConformiteV1RevueTopCCService {
  postRevueTopCC(
    revueTopCC: RessourceTiersConformiteV1RevueTopCC.IRevueTopCC
  ): Observable<RessourceTiersConformiteV1RevueTopCC.IRevueTopCC> {
    return of(MockRestRevueTopCCComplet);
  }
}

class MockClasseurclientV1DossierReglementaireClientService {
  getCompletudeDossierReglementaireClient(
    typeEntiteSupport: string,
    identifiantPorteur: string,
    indicateurPersonneMorale?: string,
    codeChronoDRC?: string
  ): Observable<RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse> {
    return of(infoDRCIncompletMock);
  }
}

export const infoDRCIncompletMock: RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse = {
  etatCompletude: 'I',
  nombrePiecesConcernees: 5,
  piecesEnAlerte: [],
  piecesManquantes: [
    'ADRESSE PERSONNE MORALE',
    'EXISTENCE JURIDIQUE PERS MORALE',
    'STATUTS DATES ET SIGNES',
    'NOMINATIONS ET POUVOIRS',
    'ACTIVITE ECONOMIQUE PERS MORALE'
  ]
};

export const infoDRCCompletMock: RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse = {
  etatCompletude: 'C',
  nombrePiecesConcernees: undefined,
  piecesEnAlerte: [],
  piecesManquantes: []
};

export const MockAppDonneesTopCCComplet = {
  couleurTopCC: 'V',
  derniereActualisation: '30/10/2020',
  dateDebutPeriodeActualisation: '01/08/2021',
  dateFinPeriodeActualisation: '31/12/2030',
  dateBlocage: '28/04/2022'
};
export const MockAppDonneesTopCCDrcKo = {
  couleurTopCC: 'V',
  derniereActualisation: DATAINCONNU,
  dateDebutPeriodeActualisation: DATAINCONNU,
  dateFinPeriodeActualisation: DATAINCONNU,
  dateBlocage: DATAINCONNU
};

export const MockAppListeAlertesDrcKo = [
  {
    codeAppartenanceBloc: 0,
    entete: 'Top CC',
    isBloquante: false,
    message: 'Date limite de mise à jour de Connaissance client dépassée'
  },
  {
    codeAppartenanceBloc: 1,
    entete: 'Coordonnées',
    isBloquante: true,
    message: 'Justificatif manquant',
    isDRC: true
  },
  {
    codeAppartenanceBloc: 2,
    entete: 'Statuts',
    isBloquante: true,
    message: 'Justificatif manquant',
    isDRC: true
  },
  {
    codeAppartenanceBloc: 3,
    entete: 'Activité économique',
    isBloquante: true,
    message: 'Justificatif manquant',
    isDRC: true
  },
  {
    codeAppartenanceBloc: 4,
    entete: 'Existence juridique',
    isBloquante: true,
    message: 'Justificatif manquant',
    isDRC: true
  },
  {
    codeAppartenanceBloc: 4,
    entete: 'Existence juridique',
    isBloquante: true,
    message: 'Société en création > 6 mois'
  },
  {
    codeAppartenanceBloc: 5,
    entete: 'Nominations réglementaires',
    isBloquante: true,
    message: 'Justificatif manquant',
    isDRC: true
  },
  {
    codeAppartenanceBloc: 6,
    entete: 'EAI',
    isBloquante: true,
    message: 'EAI en anomalie'
  },
  {
    codeAppartenanceBloc: 7,
    entete: 'Bénéficiaires effectifs',
    isBloquante: true,
    message: 'Justificatif manquant'
  }
];

export const MockRestCouleurTopCCComplet: RessourceTiersConformiteV1CouleurTopCC.ICouleurTopCC = {
  codeCouleurTopCC: 'V',
  dateDerniereActualisation: '2020-10-30',
  completudeDRCExistenceJuridique: 'OK',
  completudeDRCStatut: 'OK',
  completudeDRCActiviteEconomique: 'OK',
  completudeDRCAdresseCoordonnee: 'OK',
  completudeDRCNominationPouvoir: 'OK',
  codeSituationPPE: 'OK',
  codeSituationPersonneEAI: 'OK',
  codeSituationBE: 'OK',
  identifiantAgentAppliMAJ: '0077482',
  dateDebutPeriodeActualisation: '2021-08-01',
  dateFinPeriodeActualisation: '2030-12-31',
  dateBlocage: '2022-04-28',
  codeSituationSIREN: 'NC',
  listeComplements: []
};

export const MockRestCouleurTopCcDrcKo: RessourceTiersConformiteV1CouleurTopCC.ICouleurTopCC = {
  codeCouleurTopCC: 'V',
  dateDerniereActualisation: null,
  completudeDRCExistenceJuridique: 'KO',
  completudeDRCStatut: 'KO',
  completudeDRCActiviteEconomique: 'KO',
  completudeDRCAdresseCoordonnee: 'KO',
  completudeDRCNominationPouvoir: 'KO',
  codeSituationPPE: 'KO',
  codeSituationPersonneEAI: 'KO',
  codeSituationBE: 'KO',
  identifiantAgentAppliMAJ: '0077482',
  dateDebutPeriodeActualisation: null,
  dateFinPeriodeActualisation: null,
  dateBlocage: null,
  codeSituationSIREN: 'KO',
  listeComplements: []
};

export const MockRestRevueTopCCComplet: RessourceTiersConformiteV1RevueTopCC.IRevueTopCC = {
  codeEtablissement: '17515',
  identifiantPersonne: 66898177,
  numeroChronoProfessionnel: 1,
  codeActionTraitementTopCC: '01',
  codeOrigineEvenement: 'T',
  dateDerniereActualisation: '2020-10-28',
  codeDegreSensibilitePersonne: null,
  codeSituationCompletudeDossier: null,
  codeSituationPersonneEAI: null,
  codeSituationPPE: null,
  codeSituationBE: null,
  codeSituationAdresseNPAI: null,
  identifiantAgentAppliCreation: '0077482',
  codeCouleurTopCC: 'V'
};
