import { DatePipe } from '@angular/common';
import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import {
  ClasseurclientV1DossierReglementaireClientService,
  RessourceClasseurclientV1DossierReglementaireClient,
  RessourceTiersConformiteV1CouleurTopCC,
  RessourceTiersConformiteV1RevueTopCC,
  RessourceTiersCorporateServicV1DocRevisionAnnuelle,
  RessourceTiersV2CorporateEtablissement,
  TiersConformiteV1CouleurTopCCService,
  TiersConformiteV1RevueTopCCService,
  TiersCorporateServicV1DocRevisionAnnuelleService,
  TiersV2CorporateEtablissementService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import * as moment from 'moment';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  ALERTE_DRC_KO,
  ALERTE_DRC_NC,
  DATAINCONNU,
  LIBELLE_PIECE_MANQUANTE_ACTIVITE_ECO_EI,
  LIBELLE_PIECE_MANQUANTE_ACTIVITE_ECO_PM,
  LIBELLE_PIECE_MANQUANTE_ADRESSE_EI,
  LIBELLE_PIECE_MANQUANTE_ADRESSE_PM,
  LIBELLE_PIECE_MANQUANTE_EXISTENCE_JURIDIQUE_EI,
  LIBELLE_PIECE_MANQUANTE_EXISTENCE_JURIDIQUE_PM,
  LIBELLE_PIECE_MANQUANTE_NOMINATION_PM,
  LIBELLE_PIECE_MANQUANTE_REPRES_LEG_PP,
  LIBELLE_PIECE_MANQUANTE_STATUT_EI,
  LIBELLE_PIECE_MANQUANTE_STATUT_PM
} from '../../constantes/ihm.constantes';
import { AppEnum } from '../../enums/app-enums';
import { IAlerte } from '../../modeles/alerte.modele';
import { IDonneesTopCC } from '../../modeles/donnees-top-cc.modele';
import { AlertesTopCCService } from '../alertes-topcc/alertes-topcc.service';
import { DataUtilsService } from '../utils/data-utils.service';

@Injectable({
  providedIn: 'root'
})
export class DonneesTopCCService {
  constructor(
    private tiersConformiteV1CouleurTopCCService: TiersConformiteV1CouleurTopCCService,
    @Inject(LOCALE_ID) public locale: string,
    private datePipe: DatePipe,
    private alertesTopCCService: AlertesTopCCService,
    private tiersConformiteV1RevueTopCCService: TiersConformiteV1RevueTopCCService,
    private classeurclientV1DossierReglementaireClientService: ClasseurclientV1DossierReglementaireClientService,
    private dataUtils: DataUtilsService,
    private tiersV2CorporateEtablissementService: TiersV2CorporateEtablissementService,
    private tiersCorporateServicV1DocRevisionAnnuelleService: TiersCorporateServicV1DocRevisionAnnuelleService
  ) {}

  getDonneesTopCC(codeEtablissement: string, identifiantPersonne: string, isPersonnePhysique: boolean): Observable<IDonneesTopCC> {
    this.alertesTopCCService.listeAlertes = [];
    return forkJoin([
      this.tiersConformiteV1CouleurTopCCService.getCouleurTopCC(codeEtablissement, +identifiantPersonne),
      this.classeurclientV1DossierReglementaireClientService.getCompletudeDossierReglementaireClient(
        '2',
        this.dataUtils.leftPadWithZero(identifiantPersonne, 9)
      ),
      this.tiersV2CorporateEtablissementService.getCorporateEtablissement(codeEtablissement, +identifiantPersonne)
    ]).pipe(
      map(([couleurTopCC, drc, corporateEtablissement]) => {
        return this.donneesTopCCRestToApp(couleurTopCC, drc, corporateEtablissement, isPersonnePhysique);
      })
    );
  }

  donneesTopCCRestToApp(
    couleurTopCCRest: RessourceTiersConformiteV1CouleurTopCC.ICouleurTopCC,
    drc: RessourceClasseurclientV1DossierReglementaireClient.CompletudeResponse,
    corporateEtablissement: RessourceTiersV2CorporateEtablissement.ICorporateEtablissement,
    estPersonnePhysique: boolean
  ): IDonneesTopCC {
    const donneesTopCCApp: IDonneesTopCC = <IDonneesTopCC>{};
    donneesTopCCApp.couleurTopCC = couleurTopCCRest.codeCouleurTopCC;
    donneesTopCCApp.derniereActualisation =
      couleurTopCCRest.dateDerniereActualisation && couleurTopCCRest.dateDerniereActualisation !== '0001-01-01'
        ? this.datePipe.transform(couleurTopCCRest.dateDerniereActualisation, 'dd/MM/yyyy')
        : DATAINCONNU;
    donneesTopCCApp.dateDebutPeriodeActualisation =
      couleurTopCCRest.dateDebutPeriodeActualisation && couleurTopCCRest.dateDebutPeriodeActualisation !== '0001-01-01'
        ? this.datePipe.transform(couleurTopCCRest.dateDebutPeriodeActualisation, 'dd/MM/yyyy')
        : DATAINCONNU;
    donneesTopCCApp.dateFinPeriodeActualisation =
      couleurTopCCRest.dateFinPeriodeActualisation && couleurTopCCRest.dateFinPeriodeActualisation !== '0001-01-01'
        ? this.datePipe.transform(couleurTopCCRest.dateFinPeriodeActualisation, 'dd/MM/yyyy')
        : DATAINCONNU;
    donneesTopCCApp.dateBlocage =
      couleurTopCCRest.dateBlocage && couleurTopCCRest.dateBlocage !== '0001-01-01'
        ? this.datePipe.transform(couleurTopCCRest.dateBlocage, 'dd/MM/yyyy')
        : DATAINCONNU;

    if (
      donneesTopCCApp.dateFinPeriodeActualisation === DATAINCONNU ||
      (donneesTopCCApp.dateFinPeriodeActualisation !== DATAINCONNU &&
        moment()
          .startOf('day')
          .diff(moment(donneesTopCCApp.dateFinPeriodeActualisation, 'DD/MM/YYYY'), 'days') > 0)
    ) {
      const alerteDateLimiteMAJCC: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_TOP_CC,
        entete: 'Top CC',
        message: 'Date limite de mise à jour de Connaissance client dépassée',
        isBloquante: false
      };
      this.alertesTopCCService.ajouterAlerte(alerteDateLimiteMAJCC);
    }

    if (couleurTopCCRest.listeComplements && couleurTopCCRest.listeComplements.length > 0) {
      for (let i = 0; i < couleurTopCCRest.listeComplements.length; i++) {
        const alerteEvenementDeclencheur: IAlerte = {
          message: couleurTopCCRest.listeComplements[i].alerteEvenementDeclencheur,
          isBloquante: couleurTopCCRest.listeComplements[i].codeActionDegradation === 'DR' ? true : false,
          isEvenementDeclencheur: true
        };
        this.alertesTopCCService.ajouterAlerte(alerteEvenementDeclencheur);
      }
    }

    if (drc && drc.piecesManquantes && drc.piecesManquantes.length > 0) {
      let alerteStatut = null;
      let alerteJustificatifIdentite = null;
      let alerteNomination = null;
      let alerteRepreLegPP = null;
      let alerteExistenceJur = null;
      let alerteActiviteEco = null;
      let alerteCoordonnees = null;
      if (estPersonnePhysique) {
        alerteJustificatifIdentite = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_STATUT_EI);
        alerteExistenceJur = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_EXISTENCE_JURIDIQUE_EI);
        alerteActiviteEco = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_ACTIVITE_ECO_EI);
        alerteCoordonnees = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_ADRESSE_EI);
      } else {
        alerteStatut = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_STATUT_PM);
        alerteExistenceJur = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_EXISTENCE_JURIDIQUE_PM);
        alerteActiviteEco = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_ACTIVITE_ECO_PM);
        alerteCoordonnees = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_ADRESSE_PM);
        alerteNomination = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_NOMINATION_PM);
        alerteRepreLegPP = drc.piecesManquantes.find(alerte => alerte === LIBELLE_PIECE_MANQUANTE_REPRES_LEG_PP);
      }
      if (alerteCoordonnees) {
        const alerteDRCCoordonnees: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
          entete: 'Coordonnées',
          message: 'Justificatif manquant',
          isBloquante: true,
          isDRC: true
        };
        this.alertesTopCCService.ajouterAlerte(alerteDRCCoordonnees);
      }
      if (alerteJustificatifIdentite) {
        const alerteDRCJustificatifIdentite: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
          entete: estPersonnePhysique ? 'Capacité Professionnelle' : 'Existence juridique',
          message: "Justificatif d'identité manquant",
          isBloquante: true,
          isDRC: true
        };
        this.alertesTopCCService.ajouterAlerte(alerteDRCJustificatifIdentite);
      }
      if (alerteStatut) {
        const alerteDRCStatut: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_STATUTS,
          entete: 'Statuts',
          message: 'Justificatif manquant',
          isBloquante: true,
          isDRC: true
        };
        this.alertesTopCCService.ajouterAlerte(alerteDRCStatut);
      }
      if (alerteActiviteEco) {
        const alerteDRCActEco: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_ACTIVITE_ECO,
          entete: 'Activité économique',
          message: 'Justificatif manquant',
          isBloquante: true,
          isDRC: true
        };
        this.alertesTopCCService.ajouterAlerte(alerteDRCActEco);
      }
      if (alerteExistenceJur) {
        const alerteDRCExistenceJuridique: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
          entete: estPersonnePhysique ? 'Capacité Professionnelle' : 'Existence juridique',
          message: estPersonnePhysique ? 'Justificatif capacité professionnelle manquant' : 'Justificatif manquant',
          isBloquante: true,
          isDRC: true
        };
        this.alertesTopCCService.ajouterAlerte(alerteDRCExistenceJuridique);
      }
      if (alerteNomination) {
        const alerteJustificatifDRCNominationsPouvoir: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_NOMINATIONS_REGLEMENTAIRES,
          entete: 'Nominations réglementaires',
          message: 'Justificatif manquant',
          isBloquante: true,
          isDRC: true
        };
        this.alertesTopCCService.ajouterAlerte(alerteJustificatifDRCNominationsPouvoir);
      }
      if (alerteRepreLegPP) {
        const alertePieceIdentiteDRCNominationsPouvoir: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_NOMINATIONS_REGLEMENTAIRES,
          entete: 'Nominations réglementaires',
          message: 'Pièce d’identité manquante',
          isBloquante: true,
          isDRC: true
        };
        this.alertesTopCCService.ajouterAlerte(alertePieceIdentiteDRCNominationsPouvoir);
      }
    }

    if (couleurTopCCRest.codeSituationPersonneEAI === ALERTE_DRC_KO && !estPersonnePhysique) {
      const alerteDRCEAI: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EAI,
        entete: 'EAI',
        message: 'EAI en anomalie',
        isBloquante: true
      };
      this.alertesTopCCService.ajouterAlerte(alerteDRCEAI);
    }

    if (couleurTopCCRest.codeSituationSIREN === ALERTE_DRC_KO) {
      const alerteSocieteCreation: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
        entete: estPersonnePhysique ? 'Capacité Professionnelle' : 'Existence juridique',
        message: 'Société en création > 6 mois',
        isBloquante: true
      };
      this.alertesTopCCService.ajouterAlerte(alerteSocieteCreation);
    }

    if (couleurTopCCRest.codeSituationPersonneEAI === ALERTE_DRC_NC && !estPersonnePhysique) {
      this.alertesTopCCService.eaiNonConcerneParTopCC = true;
    }

    if (couleurTopCCRest.codeSituationBE === ALERTE_DRC_KO && !estPersonnePhysique) {
      const alerteDRCBE: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_BE,
        entete: 'Bénéficiaires effectifs',
        message: 'Justificatif manquant',
        isBloquante: true
      };
      this.alertesTopCCService.ajouterAlerte(alerteDRCBE);
    }

    if (couleurTopCCRest.codeSituationBE === ALERTE_DRC_NC && !estPersonnePhysique) {
      this.alertesTopCCService.beNonConcerneParTopCC = true;
    }

    if (
      corporateEtablissement.listeEtablissement &&
      corporateEtablissement.listeEtablissement[0] &&
      corporateEtablissement.listeEtablissement[0].listeAdresse &&
      corporateEtablissement.listeEtablissement[0].listeAdresse[1] &&
      corporateEtablissement.listeEtablissement[0].listeAdresse[1].nombreRetourPTT > 0
    ) {
      const alertePndAdresseCorrespondanceSiege: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
        entete: 'Coordonnées',
        message: 'Adresse de correspondance en PND',
        isBloquante: false
      };
      this.alertesTopCCService.ajouterAlerte(alertePndAdresseCorrespondanceSiege);
    }
    if (corporateEtablissement.listeEtablissement && corporateEtablissement.listeEtablissement.length > 1) {
      const listeEtablissementSecondaire = corporateEtablissement.listeEtablissement.slice(1);
      let nombreAdressePnd = 0;
      listeEtablissementSecondaire.forEach(etablissementSecondaire => {
        etablissementSecondaire.listeAdresse.forEach(adresse => {
          nombreAdressePnd += adresse.nombreRetourPTT;
        });
      });
      if (nombreAdressePnd > 0) {
        const alertePndAdresseEtablissement: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
          entete: 'Coordonnées',
          message: 'Adresse établissement secondaire en PND (' + nombreAdressePnd + ')',
          isBloquante: false
        };
        this.alertesTopCCService.ajouterAlerte(alertePndAdresseEtablissement);
      }
    }
    return donneesTopCCApp;
  }

  /* istanbul ignore next */
  public validerTopCC(
    codeEtablissement: string,
    identifiantPersonne: string,
    identifiantAgent: string
  ): Observable<RessourceTiersConformiteV1RevueTopCC.IRevueTopCC> {
    const revueTopCCPost: RessourceTiersConformiteV1RevueTopCC.IRevueTopCC = {
      codeEtablissement: codeEtablissement,
      identifiantPersonne: +identifiantPersonne,
      identifiantAgentAppliCreation: identifiantAgent,
      codeActionTraitementTopCC: '01',
      numeroChronoProfessionnel: 1,
      codeOrigineEvenement: 'T',
      dateDerniereActualisation: moment().format('YYYY-MM-DD'),
      codeMotifOrigineDegradation: 'N',
      codeSituationSirenEnFormation: 'NC'
    };

    return this.tiersConformiteV1RevueTopCCService.postRevueTopCC(revueTopCCPost).pipe(
      map((retour: RessourceTiersConformiteV1RevueTopCC.IRevueTopCC) => {
        if (retour.indicateurMAJrevisionAnnuelle === 'O') {
          this.tiersCorporateServicV1DocRevisionAnnuelleService
            .postGenererArchiverEditionsRevision(this.creerParamEntreePostGenerateEdtionsRevision(codeEtablissement, identifiantPersonne))
            .subscribe((retour: RessourceTiersCorporateServicV1DocRevisionAnnuelle.IOutGenererArchiverEditions) => {});
        }
        return retour;
      })
    );
  }

  private creerParamEntreePostGenerateEdtionsRevision(
    codeEtablissement: string,
    identifiantPersonne: string
  ): RessourceTiersCorporateServicV1DocRevisionAnnuelle.IInGenererEditions {
    const paramGenerateEditionsRevision: RessourceTiersCorporateServicV1DocRevisionAnnuelle.IInGenererEditions = <
      RessourceTiersCorporateServicV1DocRevisionAnnuelle.IInGenererEditions
    >{
      listeParametres: [
        {
          typeRattachement: 'Personne',
          idRattachement: this.dataUtils.leftPadWithZero(identifiantPersonne, 9),
          idEtab: codeEtablissement,
          editionSthFonctionnement: false,
          editionDSCStandard: true
        }
      ]
    };
    return paramGenerateEditionsRevision;
  }
}
