import { Injectable } from '@angular/core';
import {
  RessourceOutilimpressionV1LibelleEtablissement,
  RessourceTiersV2Identification
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { IAuthentificationInfo, IParametresComptables } from '@ptmyway-stc-v2/core-common';
import { IContexte } from '../../modeles/contexte.model';

@Injectable({
  providedIn: 'root'
})
export class ContexteService {
  constructor() {}

  getContextFromInfos(
    identification: RessourceTiersV2Identification.IIdentification,
    choixTopCCPM: string,
    authentificationInfo: IAuthentificationInfo,
    parametresComptables: IParametresComptables,
    libelleEtablissement: RessourceOutilimpressionV1LibelleEtablissement.ILibelleEtablissement
  ): IContexte {
    const ctx = {} as IContexte;
    if (identification && identification.donneeIdentification) {
      ctx.codeEtablissement = identification.donneeIdentification.codeEtablissement;
      ctx.identifiantPersonne = '' + identification.donneeIdentification.identifiantPersonne;
      ctx.estPersonnePhysique = identification.donneeIdentification.codePersonnaliteJuridique === '1' ? true : false;
    }
    if (authentificationInfo) {
      ctx.authentificationInfo = authentificationInfo;
      if (authentificationInfo.agent) {
        ctx.identifiantAgent = authentificationInfo.agent.codeAgent;
      }
    }
    ctx.choixTopCCPM = choixTopCCPM === 'O' ? true : false;
    ctx.parametresComptables = parametresComptables;
    ctx.libelleEditiqueEtablissement = libelleEtablissement;

    console.log('Contexte => ', ctx);
    return ctx;
  }
}
