import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import {
  RessourceTiersCorporateServicV1InformationEAI,
  TiersCorporateServicV1InformationEAIService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { DATAINCONNU, LIBELLE_ALERTE_EAI_CHANGEMENT_CIRCONSTANCES } from '../../constantes/ihm.constantes';
import { AppEnum } from '../../enums/app-enums';
import { IAlerte } from '../../modeles/alerte.modele';
import { IEchangeAutomatiqueInformations } from '../../modeles/echange-automatique-informations.modele';
import { AlertesTopCCService } from '../alertes-topcc/alertes-topcc.service';

@Injectable({
  providedIn: 'root'
})
export class EaiAutoCertificationService {
  constructor(
    private tiersCorporateServicV1InformationEAIService: TiersCorporateServicV1InformationEAIService,
    private alertesTopCCService: AlertesTopCCService,
    @Inject(LOCALE_ID) public locale: string
  ) {}

  consulterInformationsEai(codeEtablissement: string, identifiantPersonne: string): Observable<IEchangeAutomatiqueInformations> {
    return this.tiersCorporateServicV1InformationEAIService.getInformationEAI(codeEtablissement, +identifiantPersonne).pipe(
      map((infoEai: RessourceTiersCorporateServicV1InformationEAI.IInformationEAI) => {
        return this.infoEaiRestToApp(infoEai);
      })
    );
  }

  private infoEaiRestToApp(infoEai: RessourceTiersCorporateServicV1InformationEAI.IInformationEAI): IEchangeAutomatiqueInformations {
    const eaiApp: IEchangeAutomatiqueInformations = <IEchangeAutomatiqueInformations>{};
    if (infoEai) {
      if (infoEai.statutACEAI) {
        eaiApp.statutEAI = infoEai.statutACEAI.libelleStatutEAI ? infoEai.statutACEAI.libelleStatutEAI : DATAINCONNU;
        eaiApp.etatEAI = this.getLibelleEtatClient(infoEai.statutACEAI.codeStatutClient);
      }
      if (
        infoEai.dernierEAISaisi &&
        infoEai.dernierEAISaisi.listeResidenceFiscale &&
        infoEai.dernierEAISaisi.listeResidenceFiscale.length > 0
      ) {
        eaiApp.paysResidenceFiscale = infoEai.dernierEAISaisi.listeResidenceFiscale[0].paysResidenceFiscale
          ? infoEai.dernierEAISaisi.listeResidenceFiscale[0].paysResidenceFiscale
          : DATAINCONNU;
      } else {
        eaiApp.paysResidenceFiscale = DATAINCONNU;
      }

      if (
        infoEai.detailAutoCertificationEAI &&
        infoEai.detailAutoCertificationEAI.codeStatutAC === AppEnum.EtatClient.NON_CLASSIFIE &&
        infoEai.detailAutoCertificationEAI.codeInformationObtenueACEAI === '00'
      ) {
        const alerteChangementCirconstanceEAI: IAlerte = {
          codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EAI,
          entete: 'EAI',
          message: LIBELLE_ALERTE_EAI_CHANGEMENT_CIRCONSTANCES,
          isBloquante: true
        };
        this.alertesTopCCService.ajouterAlerte(alerteChangementCirconstanceEAI);
      }
    }
    return eaiApp;
  }

  /* istanbul ignore next */
  private getLibelleEtatClient(codeStatut: string): string {
    let etatClient: string = '';
    switch (codeStatut) {
      case '00':
        etatClient = 'Non classifié';
        break;
      case '01':
        etatClient = 'Classifié EAI';
        break;
      case '02':
        etatClient = 'Classifié EAI par défaut';
        break;
      case '03':
        etatClient = 'Classifié EAI de façon automatique';
        break;
      case '04':
        etatClient = 'Classifié EAI Non documenté';
        break;
      case '05':
        etatClient = 'Classifié EAI Récalcitrant';
        break;
      case '06':
        etatClient = 'Classifié EAI Récalcitrant Non documenté';
        break;
      default:
        etatClient = DATAINCONNU;
    }
    return etatClient;
  }
}
