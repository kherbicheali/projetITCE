export interface IEchangeAutomatiqueInformations {
  paysResidenceFiscale: string;
  statutEAI: string;
  etatEAI: string;
}
