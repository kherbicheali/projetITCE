export interface IDonneesTopCC {
  couleurTopCC: string;
  derniereActualisation: string;
  dateDebutPeriodeActualisation: string;
  dateFinPeriodeActualisation: string;
  dateBlocage: string;
}
