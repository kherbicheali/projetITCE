export interface IDonneesClientParticulier {
  nom: string;
  prenom: string;
  nomUsage: string;
  adresse: string;
  nationalite: string;
  categorieSocioPro: string;
  revenusNetMensuels: string;
  epargnePlacement: string;
  patrimoineImmobilier: string;
}
