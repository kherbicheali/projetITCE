// tslint:disable-next-line: max-line-length
import { RessourceOutilimpressionV1LibelleEtablissement } from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { IAuthentificationInfo, IParametresComptables } from '@ptmyway-stc-v2/core-common';

export interface IContexte {
  identifiantPersonne: string;
  codeEtablissement: string;
  estPersonnePhysique?: boolean;
  choixTopCCPM: boolean;
  identifiantAgent?: string;
  parametresComptables?: IParametresComptables;
  libelleEditiqueEtablissement?: RessourceOutilimpressionV1LibelleEtablissement.ILibelleEtablissement;
  authentificationInfo: IAuthentificationInfo;
}
