export interface IAlerte {
  message: string;
  entete?: string;
  codeAppartenanceBloc?: number;
  isBloquante: boolean;
  isDRC?: boolean;
  isEvenementDeclencheur?: boolean;
  isCreationDRCImpossible?: boolean;
}
