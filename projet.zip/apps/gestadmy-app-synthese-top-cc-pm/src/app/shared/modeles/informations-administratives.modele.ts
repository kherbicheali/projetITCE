export namespace InformationsAdministrativesModele {
  export interface IDonneesAdministratives {
    raisonSociale: string;
    nomCommercial: string;
    numeroSiren: string;
    adressePrincipale?: IAdresse;
    telephonePortablePm?: string;
    telephoneFixePm?: string;
    emailPm?: string;
    interlocuteurPrincipal?: IInterloc;
    telephoneFixePart?: string;
    telephonePortablePart?: string;
    emailPart?: string;
  }

  export interface IInterloc {
    designation: string;
    medias: IMediaPM[];
    poste?: string;
  }

  export class IMediaPM {
    valeur: string;
    type: enumMediaType;
    estMediaValeur: boolean;
  }

  export interface IAdresse {
    ligne2: string;
    ligne3: string;
    ligne4: string;
    ligne5: string;
    ligne6: string;
  }

  export enum enumMediaType {
    Email,
    TelFixe,
    TelPortable
  }
}
