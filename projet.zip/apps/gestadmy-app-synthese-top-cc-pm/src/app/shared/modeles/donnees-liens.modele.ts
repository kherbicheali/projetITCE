export interface IBeneficiaireEffectif {
  identite: string;
  numeroPersonne: string;
  pourcentageDetention: string;
  gouvernanceDetention: string;
  ppe: boolean;
  provenanceStatutPpe: string;
  role: string;
}

export interface INominationsReglementaires {
  fonction: string;
  identite: string;
  numeroPersonne: string;
  ppe: boolean;
  provenanceStatutPpe: string;
}

export interface IDonneesLiens {
  listeBeneficiairesEffectifs: IBeneficiaireEffectif[];
  listeNominationsReglementaires: INominationsReglementaires[];
}
