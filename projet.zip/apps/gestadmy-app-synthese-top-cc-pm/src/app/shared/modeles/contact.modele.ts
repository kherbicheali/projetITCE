export interface IContact {
  designation: string;
  role: string;
  telFixe?: string;
  telMobile?: string;
  email?: string;
}
