export interface INatureRelation {
  dateEntreeRelation: string;
  etablissementReferent: string;
  actualisation: string;
  delaiActualisation: string;
}
