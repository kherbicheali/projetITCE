export namespace DonneesCorporateModele {
  export interface IActiviteEconomique {
    chiffreAffaire?: string;
    anneeDernierBilan?: string;
    dateArrete?: string;
    effectif?: string;
  }

  export interface IExistenceJuridique {
    raisonSocial?: string;
    nomCommercial?: string;
    numeroSiren: string;
    secteurActivite: string;
    categorieJuridique: string;
    montantCapitalSocial?: string;
    dateCreation: string;
    dateCloture: string;
  }

  export interface IDonneesCorporate {
    activiteEconomique: IActiviteEconomique;
    existenceJuridique: IExistenceJuridique;
    nombrePNDAdresseSiege: number;
  }
}
