import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { IDonneesClientParticulier } from '../../modeles/donnees-client-particulier.modele';
import { DonneesClientParticulierService } from '../../services/donnees-client-particulier/donnees-client-particulier.service';
import { LoadDonneesClientParticulier } from './donnees-client-particulier.actions';

export interface IDonneesClientParticulierState {
  data: IDonneesClientParticulier;
  loading: boolean;
  isError: boolean;
  error: HttpErrorResponse;
}

@State<IDonneesClientParticulierState>({
  name: 'donneesClientParticulier',
  defaults: {
    data: null,
    loading: true,
    isError: false,
    error: null
  }
})
@Injectable()
export class DonneesClientParticulierState {
  constructor(private readonly donneesClientParticulierService: DonneesClientParticulierService) {}

  @Selector()
  static getContent(state: IDonneesClientParticulierState): IDonneesClientParticulier {
    return state.data;
  }

  @Selector()
  static getError(state: IDonneesClientParticulierState): HttpErrorResponse {
    return state.error;
  }

  @Selector()
  static isLoading(state: IDonneesClientParticulierState): boolean {
    return state.loading;
  }

  /* istanbul ignore next */
  @Action(LoadDonneesClientParticulier)
  loadContent(ctx: StateContext<IDonneesClientParticulierState>, action: LoadDonneesClientParticulier) {
    ctx.patchState({
      data: null,
      loading: true,
      isError: false,
      error: null
    });
    return this.donneesClientParticulierService.getDonneesClientParticulier(action.codeEtablissement, action.identifiantPersonne).pipe(
      tap(data => {
        ctx.patchState({
          data: data,
          loading: false,
          isError: false,
          error: null
        });
      }),
      catchError((err: HttpErrorResponse) => {
        ctx.patchState({
          loading: false,
          isError: true,
          error: err
        });
        return of(err);
      })
    );
  }
}
