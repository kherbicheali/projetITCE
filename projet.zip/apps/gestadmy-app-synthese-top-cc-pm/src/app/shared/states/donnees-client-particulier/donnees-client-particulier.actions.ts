export class LoadDonneesClientParticulier {
  constructor(public codeEtablissement: string, public identifiantPersonne: string) {}
  static readonly type = '[LoadDonneesClientParticulier] Load content';
}
