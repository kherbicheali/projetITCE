import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DialogService } from '@myway/ui';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { IDonneesTopCC } from '../../modeles/donnees-top-cc.modele';
import { DonneesTopCCService } from '../../services/donnees-top-cc/donnees-top-cc.service';
import { LoadDonneesTopCC, ValiderDonneesTopCC } from './donnees-top-cc.actions';

export interface IDonneesTopCCState {
  data: IDonneesTopCC;
  loading: boolean;
  isError: boolean;
  error: HttpErrorResponse;
}

@State<IDonneesTopCCState>({
  name: 'donneesTopCC',
  defaults: {
    data: null,
    loading: true,
    isError: false,
    error: null
  }
})
@Injectable()
export class DonneesTopCCState {
  constructor(private readonly donneesTopCCService: DonneesTopCCService, private modaleService: DialogService) {}

  @Selector()
  static getContent(state: IDonneesTopCCState): IDonneesTopCC {
    return state.data;
  }
  @Selector()
  static getError(state: IDonneesTopCCState): HttpErrorResponse {
    return state.error;
  }

  @Selector()
  static isLoading(state: IDonneesTopCCState): boolean {
    return state.loading;
  }

  /* istanbul ignore next */
  @Action(LoadDonneesTopCC)
  loadContent(ctx: StateContext<IDonneesTopCCState>, action: LoadDonneesTopCC) {
    ctx.patchState({
      data: null,
      loading: true,
      isError: false,
      error: null
    });
    return this.donneesTopCCService.getDonneesTopCC(action.codeEtablissement, action.identifiantPersonne, action.isPersonnePhysique).pipe(
      tap(data => {
        ctx.patchState({
          data: data,
          loading: false,
          isError: false,
          error: null
        });
      }),
      catchError((err: HttpErrorResponse) => {
        ctx.patchState({
          loading: false,
          isError: true,
          error: err
        });
        return of(err);
      })
    );
  }

  /* istanbul ignore next */
  @Action(ValiderDonneesTopCC)
  validerTopCC(ctx: StateContext<IDonneesTopCCState>, action: ValiderDonneesTopCC) {
    return this.donneesTopCCService.validerTopCC(action.codeEtablissement, action.identifiantPersonne, action.identifiantAgent).pipe(
      catchError((err: HttpErrorResponse) => {
        this.modaleService.info({
          titleHeader: 'Erreur lors de la validation du Top CC',
          messageError: err.error?.libelle ? err.error.libelle : err.message ? err.message : ''
        });
        throw err;
      })
    );
  }
}
