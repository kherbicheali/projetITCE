export class LoadDonneesTopCC {
  constructor(public codeEtablissement: string, public identifiantPersonne: string, public isPersonnePhysique: boolean) {}
  static readonly type = '[DonneesTopCC] Load content';
}

export class ValiderDonneesTopCC {
  constructor(public codeEtablissement: string, public identifiantPersonne: string, public identifiantAgent: string) {}
  static readonly type = '[DonneesTopCC] Validation Top CC';
}
