import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { NgxsModule, Store } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { InformationsAdministrativesModele } from '../../modeles/informations-administratives.modele';
import { InformationsAdministrativesService } from '../../services/informations-administratives/informations-administratives.service';
import { DonneesAdministrativesState } from './donnees-administratives.state';

const mockDonneesAdmin = {
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  adressePrincipale: { ligne2: null, ligne3: null, ligne4: '1    RUE DU GAZ', ligne5: 'BP 93330', ligne6: '12033 RODEZ CEDEX 9' },
  interlocuteurPrincipal: {
    designation: 'MR JALADEAU FREDERIC',
    medias: [
      { estMediaValeur: true, type: 1, valeur: '05 65 73 31 92' },
      { estMediaValeur: false, type: 2, valeur: 'Non Renseigné' },
      { estMediaValeur: true, type: 0, valeur: 'fjaladeau@udaf12.fr' }
    ],
    poste: 'CONTACT BANQUE A DISTANCE'
  }
};

const mockDonneesAdminState = {
  data: mockDonneesAdmin,
  loading: false,
  isError: false,
  error: null
};

class MockDonneesAdministrativesService {
  getDonneesAdministratives(
    codeEtablissement: string,
    identifiantPersonne: string,
    estPersonnePhysique: boolean
  ): Observable<InformationsAdministrativesModele.IDonneesAdministratives> {
    return of(mockDonneesAdmin);
  }
}

describe('DonneesAdministrativesState', () => {
  let store: Store;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [NgxsModule.forRoot([])],
      providers: [{ provide: InformationsAdministrativesService, useClass: MockDonneesAdministrativesService }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    store = TestBed.inject(Store);
  }));

  it('Sélectionne les donnees administratives', () => {
    const retour: any = DonneesAdministrativesState.getContent(mockDonneesAdminState);
    expect(retour).toEqual(mockDonneesAdmin);
  });

  it('Sélectionne les erreurs', () => {
    const retour: any = DonneesAdministrativesState.getError(mockDonneesAdminState);
    expect(retour).toEqual(null);
  });

  it("Sélectionne l'état de chargement", () => {
    const retour: any = DonneesAdministrativesState.isLoading(mockDonneesAdminState);
    expect(retour).toBeFalsy();
  });
});
