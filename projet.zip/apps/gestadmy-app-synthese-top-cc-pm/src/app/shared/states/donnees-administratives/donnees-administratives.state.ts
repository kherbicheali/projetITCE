import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { InformationsAdministrativesModele as modelDataAdmin } from '../../modeles/informations-administratives.modele';
import { InformationsAdministrativesService } from '../../services/informations-administratives/informations-administratives.service';
import { LoadDonneesAdministratives } from './donnees-administratives.actions';

export interface IDonneesAdministrativesState {
  data: modelDataAdmin.IDonneesAdministratives;
  loading: boolean;
  isError: boolean;
  error: HttpErrorResponse;
}

@State<IDonneesAdministrativesState>({
  name: 'administratif',
  defaults: {
    data: null,
    loading: true,
    isError: false,
    error: null
  }
})
@Injectable()
export class DonneesAdministrativesState {
  constructor(private readonly donneesAdministrativesBusinessService: InformationsAdministrativesService) {}

  @Selector()
  static getContent(state: IDonneesAdministrativesState): modelDataAdmin.IDonneesAdministratives {
    return state.data;
  }

  @Selector()
  static getError(state: IDonneesAdministrativesState): HttpErrorResponse {
    return state.error;
  }

  @Selector()
  static isLoading(state: IDonneesAdministrativesState): boolean {
    return state.loading;
  }

  /* istanbul ignore next */
  @Action(LoadDonneesAdministratives)
  loadContent(ctx: StateContext<IDonneesAdministrativesState>, action: LoadDonneesAdministratives) {
    ctx.patchState({
      data: null,
      loading: true,
      isError: false,
      error: null
    });
    return this.donneesAdministrativesBusinessService
      .getDonneesAdministratives(
        action.codeEtablissement,
        action.identifiantPersonne,
        action.estPersonnePhysique ? action.estPersonnePhysique : false
      )
      .pipe(
        tap(data => {
          ctx.patchState({
            data: data,
            loading: false,
            isError: false,
            error: null
          });
        }),
        catchError((err: HttpErrorResponse) => {
          ctx.patchState({
            loading: false,
            isError: true,
            error: err
          });
          return of(err);
        })
      );
  }
}
