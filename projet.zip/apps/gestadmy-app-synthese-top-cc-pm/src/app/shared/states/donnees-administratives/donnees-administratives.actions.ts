export class LoadDonneesAdministratives {
  constructor(public codeEtablissement: string, public identifiantPersonne: string, public estPersonnePhysique?: boolean) {}
  static readonly type = '[Administratif] Load content';
}
