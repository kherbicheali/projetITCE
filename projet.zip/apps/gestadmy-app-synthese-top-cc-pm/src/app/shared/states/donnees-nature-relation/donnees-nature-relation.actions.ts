export class LoadDonneesNatureRelation {
  constructor(public codeEtablissement: string, public identifiantPersonne: string) {}
  static readonly type = '[DonneesNatureRelation] Load content';
}
