import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { INatureRelation } from '../../modeles/nature-relation.modele';
import { NatureRelationService } from '../../services/nature-relation/nature-relation.service';
import { LoadDonneesNatureRelation } from './donnees-nature-relation.actions';

export interface IDonneesNatureRelationState {
  data: INatureRelation;
  loading: boolean;
  isError: boolean;
  error: HttpErrorResponse;
}

@State<IDonneesNatureRelationState>({
  name: 'donneesNatureRelation',
  defaults: {
    data: null,
    loading: true,
    isError: false,
    error: null
  }
})
@Injectable()
export class DonneesNatureRelationState {
  constructor(private readonly natureRelationService: NatureRelationService) {}

  @Selector()
  static getContent(state: IDonneesNatureRelationState): INatureRelation {
    return state.data;
  }
  @Selector()
  static getError(state: IDonneesNatureRelationState): HttpErrorResponse {
    return state.error;
  }

  @Selector()
  static isLoading(state: IDonneesNatureRelationState): boolean {
    return state.loading;
  }

  /* istanbul ignore next */
  @Action(LoadDonneesNatureRelation)
  loadContent(ctx: StateContext<IDonneesNatureRelationState>, action: LoadDonneesNatureRelation) {
    ctx.patchState({
      data: null,
      loading: true,
      isError: false,
      error: null
    });
    return this.natureRelationService.getNatureRelation(action.codeEtablissement, action.identifiantPersonne).pipe(
      tap(data => {
        ctx.patchState({
          data: data,
          loading: false,
          isError: false,
          error: null
        });
      }),
      catchError((err: HttpErrorResponse) => {
        ctx.patchState({
          loading: false,
          isError: true,
          error: err
        });
        return of(err);
      })
    );
  }
}
