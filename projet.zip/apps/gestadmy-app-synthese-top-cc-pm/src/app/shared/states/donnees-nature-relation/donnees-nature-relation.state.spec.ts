import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { NgxsModule, Store } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { ACTUALISATION_FREQUENTE } from '../../constantes/ihm.constantes';
import { INatureRelation } from '../../modeles/nature-relation.modele';
import { NatureRelationService } from '../../services/nature-relation/nature-relation.service';
import { DonneesNatureRelationState } from './donnees-nature-relation.state';

const mockDonneesNatureRelation: INatureRelation = {
  dateEntreeRelation: '2018-12-06',
  etablissementReferent: 'ILE DE FRANCE',
  actualisation: ACTUALISATION_FREQUENTE,
  delaiActualisation: '30 mois'
};

const mockDonneesNatureRelationState = {
  data: mockDonneesNatureRelation,
  loading: false,
  isError: false,
  error: null
};

class MockNatureRelationService {
  getNatureRelation(codeEtablissement: string, identifiantPersonne: string): Observable<INatureRelation> {
    return of(mockDonneesNatureRelation);
  }
}

describe('DonneesNatureRelationState', () => {
  let store: Store;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [NgxsModule.forRoot([])],
      providers: [{ provide: NatureRelationService, useClass: MockNatureRelationService }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    store = TestBed.inject(Store);
  }));

  it('Sélectionne les donnees liens', () => {
    const retour: any = DonneesNatureRelationState.getContent(mockDonneesNatureRelationState);
    expect(retour).toEqual(mockDonneesNatureRelation);
  });

  it('Sélectionne les erreurs', () => {
    const retour: any = DonneesNatureRelationState.getError(mockDonneesNatureRelationState);
    expect(retour).toEqual(null);
  });

  it("Sélectionne l'état de chargement", () => {
    const retour: any = DonneesNatureRelationState.isLoading(mockDonneesNatureRelationState);
    expect(retour).toBeFalsy();
  });
});
