import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { DonneesCorporateModele } from '../../modeles/donnees-corporate.modele';
import { InformationsCorporateService } from '../../services/informations-corporate/informations-corporate.service';
import { LoadDonneesCorporate } from './donnees-corporate.actions';

export interface IDonneesCorporateState {
  data: DonneesCorporateModele.IDonneesCorporate;
  loading: boolean;
  isError: boolean;
  error: HttpErrorResponse;
}

@State<IDonneesCorporateState>({
  name: 'donneesCorporate',
  defaults: {
    data: null,
    loading: true,
    isError: false,
    error: null
  }
})
@Injectable()
export class DonneesCorporateState {
  constructor(private readonly informationsCorporateService: InformationsCorporateService) {}

  @Selector()
  static getContent(state: IDonneesCorporateState): DonneesCorporateModele.IDonneesCorporate {
    return state.data;
  }

  @Selector()
  static getActiviteEconomique(state: IDonneesCorporateState): DonneesCorporateModele.IActiviteEconomique {
    return state.data.activiteEconomique;
  }

  @Selector()
  static getExistenceJuridique(state: IDonneesCorporateState): DonneesCorporateModele.IExistenceJuridique {
    return state.data.existenceJuridique;
  }

  @Selector()
  static getError(state: IDonneesCorporateState): HttpErrorResponse {
    return state.error;
  }

  @Selector()
  static isLoading(state: IDonneesCorporateState): boolean {
    return state.loading;
  }

  /* istanbul ignore next */
  @Action(LoadDonneesCorporate)
  loadContent(ctx: StateContext<IDonneesCorporateState>, action: LoadDonneesCorporate) {
    ctx.patchState({
      data: null,
      loading: true,
      isError: false,
      error: null
    });
    return this.informationsCorporateService
      .getInformationsCorporate(
        action.codeEtablissement,
        action.identifiantPersonne,
        action.estPersonnePhysique ? action.estPersonnePhysique : false
      )
      .pipe(
        tap(data => {
          ctx.patchState({
            data: data,
            loading: false,
            isError: false,
            error: null
          });
        }),
        catchError((err: HttpErrorResponse) => {
          ctx.patchState({
            loading: false,
            isError: true,
            error: err
          });
          return of(err);
        })
      );
  }
}
