export class LoadDonneesCorporate {
  constructor(public codeEtablissement: string, public identifiantPersonne: string, public estPersonnePhysique?: boolean) {}
  static readonly type = '[DonneesCorporate] Load content';
}
