import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { NgxsModule, Store } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { DonneesCorporateModele } from '../../modeles/donnees-corporate.modele';
import { InformationsCorporateService } from '../../services/informations-corporate/informations-corporate.service';
import { DonneesCorporateState } from './donnees-corporate.state';

const mockDonneesCorporate: DonneesCorporateModele.IDonneesCorporate = {
  activiteEconomique: {
    anneeDernierBilan: '2018',
    chiffreAffaire: 'K€4,152',
    dateArrete: '31/12',
    effectif: '80'
  },
  existenceJuridique: {
    categorieJuridique: '9220',
    dateCloture: '01/01/2020',
    dateCreation: '01/01/1900',
    montantCapitalSocial: '€306,000',
    nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
    numeroSiren: '302769161',
    raisonSocial: 'ICYACJO EVAYEYAV EBTYTO',
    secteurActivite: '8899B'
  },
  nombrePNDAdresseSiege: 0
};

const mockDonneesCorporateState = {
  data: mockDonneesCorporate,
  loading: false,
  isError: false,
  error: null
};

class MockInformationsCorporateService {
  getInformationsCorporate(
    codeEtablissement: string,
    identifiantPersonne: number,
    estPersonnePhysique: boolean
  ): Observable<DonneesCorporateModele.IDonneesCorporate> {
    return of(mockDonneesCorporate);
  }
}

describe('DonneesCorporateState', () => {
  let store: Store;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [NgxsModule.forRoot([])],
      providers: [{ provide: InformationsCorporateService, useClass: MockInformationsCorporateService }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    store = TestBed.inject(Store);
  }));

  it('Sélectionne les donnees administratives', () => {
    const retour: any = DonneesCorporateState.getContent(mockDonneesCorporateState);
    expect(retour).toEqual(mockDonneesCorporate);
  });

  it("Sélectionne l'activite économique", () => {
    const retour: any = DonneesCorporateState.getActiviteEconomique(mockDonneesCorporateState);
    expect(retour).toEqual(mockDonneesCorporate.activiteEconomique);
  });

  it("Sélectionne l'existence juridique", () => {
    const retour: any = DonneesCorporateState.getExistenceJuridique(mockDonneesCorporateState);
    expect(retour).toEqual(mockDonneesCorporate.existenceJuridique);
  });

  it('Sélectionne les erreurs', () => {
    const retour: any = DonneesCorporateState.getError(mockDonneesCorporateState);
    expect(retour).toEqual(null);
  });

  it("Sélectionne l'état de chargement", () => {
    const retour: any = DonneesCorporateState.isLoading(mockDonneesCorporateState);
    expect(retour).toBeFalsy();
  });
});
