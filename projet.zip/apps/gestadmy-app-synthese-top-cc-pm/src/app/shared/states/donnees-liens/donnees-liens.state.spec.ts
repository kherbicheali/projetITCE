import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { NgxsModule, Store } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { IDonneesLiens } from '../../modeles/donnees-liens.modele';
import { DonneesLiensService } from '../../services/donnees-liens/donnees-liens.service';
import { DonneesLiensState } from './donnees-liens.state';

const mockDonneesLiens: IDonneesLiens = {
  listeNominationsReglementaires: [
    {
      numeroPersonne: '94211210',
      identite: 'FENNO VEBIO',
      fonction: 'Gérant',
      ppe: false,
      provenanceStatutPpe: ''
    },
    {
      numeroPersonne: '94211213',
      identite: 'MIWTO BELYB',
      fonction: 'Dirigeant',
      ppe: false,
      provenanceStatutPpe: ''
    }
  ],
  listeBeneficiairesEffectifs: [
    {
      numeroPersonne: '94211210',
      pourcentageDetention: '50%',
      gouvernanceDetention: 'Capital direct et indirect',
      ppe: false,
      provenanceStatutPpe: '',
      identite: 'FENNO VEBIO',
      role: 'Bénéficiaire effectif'
    },
    {
      numeroPersonne: '94211213',
      pourcentageDetention: '50%',
      gouvernanceDetention: 'Capital direct et indirect',
      ppe: false,
      provenanceStatutPpe: '',
      identite: 'MIWTO BELYB',
      role: 'Bénéficiaire effectif'
    }
  ]
};

const mockDonneesLiensState = {
  data: mockDonneesLiens,
  loading: false,
  isError: false,
  error: null
};

class MockDonneesLiensService {
  getDonneesLiens(codeEtablissement: string, identifiantPersonne: string): Observable<IDonneesLiens> {
    return of(mockDonneesLiens);
  }
}

describe('DonneesLiensState', () => {
  let store: Store;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [NgxsModule.forRoot([])],
      providers: [{ provide: DonneesLiensService, useClass: MockDonneesLiensService }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    store = TestBed.inject(Store);
  }));

  it('Sélectionne les donnees liens', () => {
    const retour: any = DonneesLiensState.getContent(mockDonneesLiensState);
    expect(retour).toEqual(mockDonneesLiens);
  });

  it('Sélectionne les donnees beneficiaires effectifs', () => {
    const retour: any = DonneesLiensState.getBeneficiairesEffectifs(mockDonneesLiensState);
    expect(retour).toEqual(mockDonneesLiens.listeBeneficiairesEffectifs);
  });

  it('Sélectionne les donnees nominations reglementaires', () => {
    const retour: any = DonneesLiensState.getNominationsReglementaires(mockDonneesLiensState);
    expect(retour).toEqual(mockDonneesLiens.listeNominationsReglementaires);
  });

  it('Sélectionne les erreurs', () => {
    const retour: any = DonneesLiensState.getError(mockDonneesLiensState);
    expect(retour).toEqual(null);
  });

  it("Sélectionne l'état de chargement", () => {
    const retour: any = DonneesLiensState.isLoading(mockDonneesLiensState);
    expect(retour).toBeFalsy();
  });
});
