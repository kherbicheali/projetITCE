import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { IBeneficiaireEffectif, IDonneesLiens, INominationsReglementaires } from '../../modeles/donnees-liens.modele';
import { DonneesLiensService } from '../../services/donnees-liens/donnees-liens.service';
import { LoadDonneesLiens } from './donnees-liens.actions';

export interface IDonneesLiensState {
  data: IDonneesLiens;
  loading: boolean;
  isError: boolean;
  error: HttpErrorResponse;
}

@State<IDonneesLiensState>({
  name: 'donneesLiens',
  defaults: {
    data: null,
    loading: true,
    isError: false,
    error: null
  }
})
@Injectable()
export class DonneesLiensState {
  constructor(private readonly donneesLiensService: DonneesLiensService) {}

  @Selector()
  static getContent(state: IDonneesLiensState): IDonneesLiens {
    return state.data;
  }

  @Selector()
  static getBeneficiairesEffectifs(state: IDonneesLiensState): IBeneficiaireEffectif[] {
    return state.data.listeBeneficiairesEffectifs;
  }

  @Selector()
  static getNominationsReglementaires(state: IDonneesLiensState): INominationsReglementaires[] {
    return state.data.listeNominationsReglementaires;
  }

  @Selector()
  static getError(state: IDonneesLiensState): HttpErrorResponse {
    return state.error;
  }

  @Selector()
  static isLoading(state: IDonneesLiensState): boolean {
    return state.loading;
  }

  /* istanbul ignore next */
  @Action(LoadDonneesLiens)
  loadContent(ctx: StateContext<IDonneesLiensState>, action: LoadDonneesLiens) {
    ctx.patchState({
      data: null,
      loading: true,
      isError: false,
      error: null
    });
    return this.donneesLiensService.getDonneesLiens(action.codeEtablissement, action.identifiantPersonne).pipe(
      tap(data => {
        ctx.patchState({
          data: data,
          loading: false,
          isError: false,
          error: null
        });
      }),
      catchError((err: HttpErrorResponse) => {
        ctx.patchState({
          loading: false,
          isError: true,
          error: err
        });
        return of(err);
      })
    );
  }
}
