export class LoadDonneesLiens {
  constructor(public codeEtablissement: string, public identifiantPersonne: string) {}
  static readonly type = '[LoadDonneesLiens] Load content';
}
