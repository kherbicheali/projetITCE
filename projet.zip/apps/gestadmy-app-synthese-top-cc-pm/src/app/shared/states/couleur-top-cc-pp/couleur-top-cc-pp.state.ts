import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TiersV3ConnaissanceClientService } from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { LoadCouleurTopCCPP } from './couleur-top-cc-pp.actions';

export interface ICouleurTopCCPPState {
  data: string;
  loading: boolean;
  isError: boolean;
  error: HttpErrorResponse;
}

@State<ICouleurTopCCPPState>({
  name: 'couleurTopCCPP',
  defaults: {
    data: null,
    loading: true,
    isError: false,
    error: null
  }
})
@Injectable()
export class CouleurTopCCPPState {
  constructor(private readonly tiersV3ConnaissanceClientService: TiersV3ConnaissanceClientService) {}

  @Selector()
  static getContent(state: ICouleurTopCCPPState): string {
    return state.data;
  }
  @Selector()
  static getError(state: ICouleurTopCCPPState): HttpErrorResponse {
    return state.error;
  }

  @Selector()
  static isLoading(state: ICouleurTopCCPPState): boolean {
    return state.loading;
  }

  /* istanbul ignore next */
  @Action(LoadCouleurTopCCPP)
  loadContent(ctx: StateContext<ICouleurTopCCPPState>, action: LoadCouleurTopCCPP) {
    ctx.patchState({
      data: null,
      loading: true,
      isError: false,
      error: null
    });
    return this.tiersV3ConnaissanceClientService.getConnaissanceClient(action.codeEtablissement, +action.identifiantPersonne).pipe(
      tap(data => {
        ctx.patchState({
          data: data.codeCouleurTopCC,
          loading: false,
          isError: false,
          error: null
        });
      }),
      catchError((err: HttpErrorResponse) => {
        ctx.patchState({
          loading: false,
          isError: true,
          error: err
        });
        return of(err);
      })
    );
  }
}
