export class LoadCouleurTopCCPP {
  constructor(public codeEtablissement: string, public identifiantPersonne: string) {}
  static readonly type = '[CouleurTopCCPP] Load content';
}
