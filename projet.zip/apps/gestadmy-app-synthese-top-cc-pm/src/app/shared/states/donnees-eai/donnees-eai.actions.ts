export class LoadDonneesEai {
  constructor(public codeEtablissement: string, public identifiantPersonne: string) {}
  static readonly type = '[LoadDonneesEai] Load content';
}
