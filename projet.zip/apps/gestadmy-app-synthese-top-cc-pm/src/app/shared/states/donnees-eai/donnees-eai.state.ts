import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { IEchangeAutomatiqueInformations } from '../../modeles/echange-automatique-informations.modele';
import { EaiAutoCertificationService } from '../../services/eai-auto-certification/eai-auto-certification.service';
import { LoadDonneesEai } from './donnees-eai.actions';

export interface IDonneesEaiState {
  data: IEchangeAutomatiqueInformations;
  loading: boolean;
  isError: boolean;
  error: HttpErrorResponse;
}

@State<IDonneesEaiState>({
  name: 'donneesEai',
  defaults: {
    data: null,
    loading: true,
    isError: false,
    error: null
  }
})
@Injectable()
export class DonneesEaiState {
  constructor(private readonly eaiAutoCertificationService: EaiAutoCertificationService) {}

  @Selector()
  static getContent(state: IDonneesEaiState): IEchangeAutomatiqueInformations {
    return state.data;
  }

  @Selector()
  static getError(state: IDonneesEaiState): HttpErrorResponse {
    return state.error;
  }

  @Selector()
  static isLoading(state: IDonneesEaiState): boolean {
    return state.loading;
  }

  /* istanbul ignore next */
  @Action(LoadDonneesEai)
  loadContent(ctx: StateContext<IDonneesEaiState>, action: LoadDonneesEai) {
    ctx.patchState({
      data: null,
      loading: true,
      isError: false,
      error: null
    });
    return this.eaiAutoCertificationService.consulterInformationsEai(action.codeEtablissement, action.identifiantPersonne).pipe(
      tap(data => {
        ctx.patchState({
          data: data,
          loading: false,
          isError: false,
          error: null
        });
      }),
      catchError((err: HttpErrorResponse) => {
        ctx.patchState({
          loading: false,
          isError: true,
          error: err
        });
        return of(err);
      })
    );
  }
}
