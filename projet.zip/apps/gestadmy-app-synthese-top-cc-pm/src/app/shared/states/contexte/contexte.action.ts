export class LoadContexte {
  constructor() {}
  static readonly type = '[Contexte] Load content';
}
