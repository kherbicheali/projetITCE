import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  OutilimpressionV1LibelleEtablissementService,
  TiersV2IdentificationService
} from '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest';
import { DialogService, NotificationService } from '@myway/ui';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { ErrorMessage } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { forkJoin } from 'rxjs';
import { catchError, concatMap, map } from 'rxjs/operators';
import { CONTEXTE_CHOIX_TOPCC_PM, CONTEXTE_IDENTIFIANT_PERSONNE, PROCESSUS_LISA_SORTIE } from '../../constantes/lisa.constantes';
import { IContexte } from '../../modeles/contexte.model';
import { ContexteService } from '../../services/contexte/contexte.service';
import { LoadContexte } from './contexte.action';

export interface IContexteState {
  data: IContexte;
  isLoaded: boolean;
}

@State<IContexteState>({
  name: 'contexte',
  defaults: {
    data: null,
    isLoaded: false
  }
})
@Injectable()
export class ContexteState {
  constructor(
    private contextAgentService: ContextAgentService,
    private contexteService: ContexteService,
    private identificationService: TiersV2IdentificationService,
    private modaleService: DialogService,
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    private outilimpressionV1LibelleEtablissement: OutilimpressionV1LibelleEtablissementService
  ) {}

  @Selector()
  static isLoaded(state: IContexteState): boolean {
    return state.isLoaded;
  }

  @Selector()
  static getContent(state: IContexteState): IContexte {
    return state.data;
  }

  @Action(LoadContexte)
  loadContent(ctx: StateContext<IContexteState>) {
    console.log('*** Action => LoadContexte ****');
    return forkJoin([
      this.contextAgentService.getAuthentificationInfo(),
      this.contextAgentService.getParametresComptables(),
      this.contextAgentService.getFromContext({ key: CONTEXTE_IDENTIFIANT_PERSONNE }),
      // Pour les EI, Pour aller directement sur TOP CC PM au retour d'un débranchement,
      // on récupère la valeur du contexte du choix sur l'écran intermédiaire de branche
      this.contextAgentService.getFromContext({ key: CONTEXTE_CHOIX_TOPCC_PM })
    ]).pipe(
      concatMap(([authentificationInfo, parametresComptables, identifiantPersonne, choixTopCCPM]) => {
        return forkJoin([
          this.identificationService.getIdentification(authentificationInfo.posteFonctionnel.codeEtablissement, +identifiantPersonne),
          this.outilimpressionV1LibelleEtablissement.getLibelleEtablissement(authentificationInfo.posteFonctionnel.codeEtablissement)
        ]).pipe(
          map(([identification, libelleEtablissement]) => {
            ctx.patchState({
              data: this.contexteService.getContextFromInfos(
                identification,
                choixTopCCPM as string,
                authentificationInfo,
                parametresComptables,
                libelleEtablissement
              ),
              isLoaded: true
            });
          }),
          catchError((err: HttpErrorResponse) => {
            console.log(err);
            ctx.patchState({
              isLoaded: true
            });
            throw err;
          })
        );
      }),
      catchError((err: HttpErrorResponse) => {
        this.modaleService
          .info({
            titleHeader: 'Erreur lors du chargement du contexte de la page',
            messageError: err.error?.libelle ? err.error.libelle : err.message ? err.message : ''
          })
          .subscribe(() => {
            this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_SORTIE }).subscribe(
              (result: LisaCallbackResult) => {},
              (erreur: ErrorMessage) => {
                this.notification.openInfo('Erreur de sortie du processus');
              }
            );
          });
        throw err;
      })
    );
  }
}
