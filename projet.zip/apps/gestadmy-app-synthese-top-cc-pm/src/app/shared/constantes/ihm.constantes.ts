export const MEDIA_ABSENT = 'Non Renseigné';
export const NO_CONTACT_PRINCIPAL = 'Aucun contact principal';
export const TITRE_SANS_INFOS_CLIENT = 'Synthèse Top CC';

export const ERREUR_REST_COORDONNEES = 'Erreur sur le chargement des données des coordonnées';
export const ERREUR_REST_ACTIVITE_ECONOMIQUE = "Erreur sur le chargement des données de l'activité économique";
export const ERREUR_REST_EXISTENCE_JURIDIQUE = "Erreur sur le chargement des données de l'existence juridique";
export const ERREUR_REST_BENEFICIAIRES_EFFECTIFS = 'Erreur sur le chargement des données des bénéficiaires effectifs';
export const ERREUR_REST_NOMINATIONS_REGLEMENTAIRES = 'Erreur sur le chargement des données des nominations réglementaires';
export const ERREUR_REST_PPE = 'Erreur sur le chargement des données des PPE';
export const ERREUR_REST_NATURE_RELATION = 'Erreur sur le chargement des données de la nature de la relation';
export const ERREUR_REST_EAI = "Erreur sur le chargement des données de l'EAI";
export const ERREUR_REST_COULEUR_TOPCC_PM = 'Erreur sur le chargement des données du Top CC Personne Morale';
export const ERREUR_REST_COULEUR_TOPCC_PP = 'Erreur sur le chargement des données du Top CC Personne Physique';

export const CODETYPEUSAGEMEDIAMAIL = '03';
export const CODETYPEUSAGEMEDIATELPORTABLE = '02';
export const CODETYPEUSAGEMEDIATELFIXE = '01';
export const CODETYPEUSAGEMEDIAPRO = 'T';
export const CODETYPEUSAGEMEDIAPART = 'P';

export const CLASSE_TELEPHONE = 'telephones disabled';
export const CLASSE_EMAIL = 'emails disabled';

export const DATAINCONNU = 'Non Renseigné(e)';
export const DATAINCONNU_MASCULIN = 'Non Renseigné';

export const ACTUALISATION_SOUTENUE = 'Soutenue';
export const ACTUALISATION_FREQUENTE = 'Fréquente';
export const ACTUALISATION_REGULIERE = 'Régulière';

export const TYPE_LIEN_BENEFICIAIRE_EFFECTIF = '538';
export const TYPE_LIEN_REPRESENTANT_LEGAL = '201';

export const TYPE_GOUVERNANCE_DROIT_VOTE = 'Droits de vote directs et indirects';
export const TYPE_GOUVERNANCE_CAPITAL = 'Capital direct et indirect';
export const TYPE_GOUVERNANCE_REPRESENTANT_LEGAL = 'Représentant légal';
export const TYPE_GOUVERNANCE_AUTRE = 'Autre forme de contrôle';

export const LIBELLE_COULEUR_TOPCC_VERT = 'Vert';
export const LIBELLE_COULEUR_TOPCC_ORANGE = 'Orange';
export const LIBELLE_COULEUR_TOPCC_ROUGE = 'Rouge';
export const LIBELLE_COULEUR_TOPCC_BLANC = 'Blanc';

export const ALERTE_DRC_KO = 'KO';
export const ALERTE_DRC_NC = 'NC';

export const PPE_DECLARATION = 'Déclaration';
export const PPE_CONTAGION = 'Contagion';

export const LIBELLE_PIECE_MANQUANTE_ADRESSE_EI = 'JUSTIF DOMICILE ENTR INDIV';
export const LIBELLE_PIECE_MANQUANTE_STATUT_EI = 'JUSTIFICATIF D IDENTITE';
export const LIBELLE_PIECE_MANQUANTE_EXISTENCE_JURIDIQUE_EI = 'CAPACITE PROFESSIONNELLE EI';
export const LIBELLE_PIECE_MANQUANTE_ACTIVITE_ECO_EI = 'ACTIVITE ECONOMIQUE EI';

export const LIBELLE_PIECE_MANQUANTE_ADRESSE_PM = 'ADRESSE PERSONNE MORALE';
export const LIBELLE_PIECE_MANQUANTE_STATUT_PM = 'STATUTS DATES ET SIGNES';
export const LIBELLE_PIECE_MANQUANTE_EXISTENCE_JURIDIQUE_PM = 'EXISTENCE JURIDIQUE PERS MORALE';
export const LIBELLE_PIECE_MANQUANTE_ACTIVITE_ECO_PM = 'ACTIVITE ECONOMIQUE PERS MORALE';
export const LIBELLE_PIECE_MANQUANTE_NOMINATION_PM = 'NOMINATIONS ET POUVOIRS';
export const LIBELLE_PIECE_MANQUANTE_REPRES_LEG_PP = 'IDENT. REPRESENTANTS LEGAUX PP';

export const LIBELLE_ALERTE_EAI_CHANGEMENT_CIRCONSTANCES = 'Changement de circonstances';
export const LIBELLE_BOUTON_VALIDER = 'Valider la revue';
