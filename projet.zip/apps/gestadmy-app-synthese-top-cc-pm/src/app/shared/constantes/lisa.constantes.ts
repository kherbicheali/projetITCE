export const CONTEXTE_IDENTIFIANT_PERSONNE = 'identifiantPersonne';
export const CONTEXTE_CHOIX_TOPCC_PM = 'choixTopCCPM';

export const NEXT_SORTIE = 'exit';
export const NEXT_DIGITALSHARE = 'digital-share';
export const NEXT_CLASSEUR_CLIENT = 'classeur-client';

export const PROCESSUS_LISA_SORTIE = -1;
export const PROCESSUS_LISA_CLASSEUR_CLIENT = 2;
export const PROCESSUS_LISA_LIEN = 1;
export const PROCESSUS_LISA_EAI = 3;
export const PROCESSUS_LISA_DIGITAL_SHARE = 4;
export const PROCESSUS_LISA_CONNAISSANCE_CLIENT = 5;
export const PROCESSUS_TOPCC_PP = 6;
