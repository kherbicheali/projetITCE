export namespace AppEnum {
  export enum CodeTypeLienNominationReglementaires {
    COGERANT = <any>'231',
    DIRECTEUR_GENERAL = <any>'212',
    DIRIGEANT = <any>'697',
    GERANT = <any>'230',
    PERS_MORAL_REPRESENTANT_PM = <any>'270',
    PRESIDENT = <any>'204',
    PRESIDENT_FONCTION = <any>'602',
    PRESIDENT_DIRECTEUR_GENERAL = <any>'202',
    REPRESENTANT_LEGAL = <any>'201',
    TRESORIER = <any>'234',
    TRESORIER_FONCTION = <any>'600',
    MEMBRE_DIRECTOIRE = <any>'203',
    PRESIDENT_DIRECTOIRE = <any>'207',
    MAIRE = <any>'210',
    SECRETAIRE = <any>'236',
    SECRETAIRE_ADJOINT = <any>'237',
    SYNDIC = <any>'808'
  }

  export enum LibelleTypeLienNominationReglementaires {
    COGERANT = <any>'Co-gérant',
    DIRECTEUR_GENERAL = <any>'Directeur général',
    DIRIGEANT = <any>'Dirigeant',
    GERANT = <any>'Gérant',
    PERS_MORAL_REPRESENTANT_PM = <any>"Personne morale représentant d'une personne morale",
    PRESIDENT = <any>'Président',
    PRESIDENT_FONCTION = <any>'Président (fonction)',
    PRESIDENT_DIRECTEUR_GENERAL = <any>'Président directeur général',
    REPRESENTANT_LEGAL = <any>'Représentant légal',
    TRESORIER = <any>'Trésorier',
    TRESORIER_FONCTION = <any>'Trésorier (fonction)',
    MEMBRE_DIRECTOIRE = <any>'Membre du directoire',
    PRESIDENT_DIRECTOIRE = <any>'Président du directoire',
    MAIRE = <any>'Maire',
    SECRETAIRE = <any>'Secrétaire',
    SECRETAIRE_ADJOINT = <any>'Secrétaire adjoint',
    SYNDIC = <any>'Syndic'
  }

  export enum CodeAppartenanceBloc {
    CODE_APPARTENANCE_BLOC_TOP_CC = 0,
    CODE_APPARTENANCE_BLOC_COORDONNEES = 1,
    CODE_APPARTENANCE_BLOC_STATUTS = 2,
    CODE_APPARTENANCE_BLOC_ACTIVITE_ECO = 3,
    CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE = 4,
    CODE_APPARTENANCE_BLOC_NOMINATIONS_REGLEMENTAIRES = 5,
    CODE_APPARTENANCE_BLOC_EAI = 6,
    CODE_APPARTENANCE_BLOC_BE = 7
  }

  export enum EtatClient {
    NON_CLASSIFIE = '00',
    CLASSIFIE_EAI = '01',
    CLASSIFIE_EAI_PAR_DEFAUT = '02',
    CLASSIFIE_EAI_AUTOMATIQUEMENT = '03',
    CLASSIFIE_EAI_NON_DOCUMENTE = '04',
    CLASSIFIE_EAI_RECALCITRANT = '05',
    CLASSIFIE_EAI_RECALCITRANT_NON_DOCUMENTE = '06'
  }
}
