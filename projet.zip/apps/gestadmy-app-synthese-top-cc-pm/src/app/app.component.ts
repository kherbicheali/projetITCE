import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { CoreAgentService } from '@ptmyway-stc-v2/core-agent';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { LoadContexte } from './shared/states/contexte/contexte.action';

@Component({
  selector: 'gestadmy-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit, OnDestroy {
  private unsubscribe$ = new Subject<void>();

  constructor(private readonly store: Store, private readonly coreAgentService: CoreAgentService) {}

  ngOnInit(): void {
    this.coreAgentService
      .init({ codeApplication: 'SYNTHESE_TOPCC' })
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe(() => {
        console.log('>>>>> coreAgentService initialisé <<<<<');
      });
    this.store.dispatch(new LoadContexte());
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
