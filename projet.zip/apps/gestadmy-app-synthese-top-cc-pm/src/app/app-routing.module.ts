import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrancheEIComponent } from './pages/branche-ei/branche-ei.component';
import { MainPageComponent } from './pages/main/main-page.component';

const routes: Routes = [
  { path: 'main-page', component: MainPageComponent },
  { path: '', component: BrancheEIComponent, pathMatch: 'full' },
  { path: '**', component: BrancheEIComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
