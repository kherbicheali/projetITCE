import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngxs/store';
import { CoreAgentService } from '@ptmyway-stc-v2/core-agent';
import { of } from 'rxjs';
import { AppComponent } from './app.component';
import { AppModule } from './app.module';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [AppModule, RouterTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {
          provide: CoreAgentService,
          useValue: { init: () => of({}) }
        },
        {
          provide: Store,
          useValue: { dispatch: () => of({}) }
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it("initialise l'application", () => {
    const spyConsole = jest.spyOn(console, 'log').mockReturnValue(null);
    component.ngOnInit();
    fixture.detectChanges();
    expect(spyConsole).toHaveBeenCalled();
  });

  afterAll(done => {
    component.ngOnDestroy();
  });
});
