import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { ContexteState } from '../../shared/states/contexte/contexte.state';

@Component({
  selector: 'gestadmy-bloc-informations-juridiques',
  templateUrl: './bloc-informations-juridiques.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BlocInformationsJuridiquesComponent implements OnInit {
  public estPersonnePhysique: boolean;

  constructor(private store: Store) {}

  ngOnInit() {
    this.estPersonnePhysique = this.store.selectSnapshot(ContexteState.getContent).estPersonnePhysique;
  }
}
