import { NgModule } from '@angular/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MyWayExpansionPanelModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { ActiviteEconomiqueModule } from '../activite-economique/activite-economique.module';
import { BeneficiairesEffectifsModule } from '../beneficiaires-effectifs/beneficiaires-effectifs.module';
import { EaiAutoCertificationModule } from '../eai-auto-certification/eai-auto-certification.module';
import { ExistenceJuridiqueModule } from '../existence-juridique/existence-juridique.module';
import { NominationsReglementairesModule } from '../nominations-reglementaires/nominations-reglementaires.module';
import { PpeModule } from '../ppe/ppe.module';
import { StatutInformationsJuridiquesModule } from '../statut-informations-juridiques/statut-informations-juridiques.module';
import { BlocInformationsJuridiquesComponent } from './bloc-informations-juridiques.component';

@NgModule({
  declarations: [BlocInformationsJuridiquesComponent],
  imports: [
    SharedModule,
    StatutInformationsJuridiquesModule,
    MatExpansionModule,
    ActiviteEconomiqueModule,
    ExistenceJuridiqueModule,
    EaiAutoCertificationModule,
    BeneficiairesEffectifsModule,
    NominationsReglementairesModule,
    PpeModule,
    MyWayExpansionPanelModule
  ],
  exports: [BlocInformationsJuridiquesComponent]
})
export class BlocInformationsJuridiquesModule {}
