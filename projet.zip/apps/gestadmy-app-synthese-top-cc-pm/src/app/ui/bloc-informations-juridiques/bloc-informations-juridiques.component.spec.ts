import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Store } from '@ngxs/store';
import { IContexte } from '../../shared/modeles/contexte.model';
import { BlocInformationsJuridiquesComponent } from './bloc-informations-juridiques.component';

const MockContexte = <IContexte>{
  codeEtablissement: '17515',
  estPersonnePhysique: false,
  identifiantPersonne: '9031175'
};

describe('BlocInformationsJuridiquesComponent', () => {
  let component: BlocInformationsJuridiquesComponent;
  let fixture: ComponentFixture<BlocInformationsJuridiquesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BlocInformationsJuridiquesComponent],
      providers: [
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {}, selectSnapshot: () => MockContexte }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlocInformationsJuridiquesComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('init component', () => {
    component.ngOnInit();
  });
});
