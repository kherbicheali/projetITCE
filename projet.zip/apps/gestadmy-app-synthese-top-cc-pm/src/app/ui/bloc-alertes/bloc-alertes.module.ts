import { NgModule } from '@angular/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MyWayExpansionPanelModule, MyWayStickerModule, MyWayTooltipModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { BlocAlertesComponent } from './bloc-alertes.component';

@NgModule({
  declarations: [BlocAlertesComponent],
  imports: [SharedModule, MatExpansionModule, MyWayExpansionPanelModule, MyWayStickerModule, MyWayTooltipModule],
  exports: [BlocAlertesComponent]
})
export class BlocAlertesModule {}
