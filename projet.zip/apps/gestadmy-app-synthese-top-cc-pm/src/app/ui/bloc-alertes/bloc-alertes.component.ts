import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Select } from '@ngxs/store';
import { Observable } from 'rxjs';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { DonneesCorporateState } from '../../shared/states/donnees-corporate/donnees-corporate.state';
import { DonneesNatureRelationState } from '../../shared/states/donnees-nature-relation/donnees-nature-relation.state';
import { DonneesTopCCState } from '../../shared/states/donnees-top-cc/donnees-top-cc.state';

@Component({
  selector: 'gestadmy-bloc-alertes',
  templateUrl: './bloc-alertes.component.html',
  styleUrls: ['./bloc-alertes.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class BlocAlertesComponent implements OnInit {
  public listeAlerteExpanded: boolean;
  @Select(DonneesCorporateState.isLoading) isLoadingCorporate$: Observable<boolean>;
  @Select(DonneesNatureRelationState.isLoading) isLoadingNature$: Observable<boolean>;
  @Select(DonneesTopCCState.isLoading) isLoadingTopCCPM$: Observable<boolean>;
  private isCouleurTopCCLoading: boolean;
  private isDonneesCorporateLoading: boolean;
  private isDonneesNatureLoading: boolean;

  constructor(public alertesTopCCService: AlertesTopCCService) {}

  ngOnInit(): void {
    this.listeAlerteExpanded = false;
    this.isLoadingTopCCPM$.subscribe((isLoading: boolean) => {
      this.isCouleurTopCCLoading = isLoading;
    });

    this.isLoadingCorporate$.subscribe((isLoading: boolean) => {
      this.isDonneesCorporateLoading = isLoading;
    });

    this.isLoadingNature$.subscribe((isLoading: boolean) => {
      this.isDonneesNatureLoading = isLoading;
    });
  }

  actionExtension(): void {
    this.listeAlerteExpanded = !this.listeAlerteExpanded;
  }

  getLibelleAfficherPlus(): number {
    return this.alertesTopCCService.listeAlertes.length - 4 > 0 ? this.alertesTopCCService.listeAlertes.length - 4 : 0;
  }

  isAlertesLoading(): boolean {
    return this.isCouleurTopCCLoading && this.isDonneesCorporateLoading && this.isDonneesNatureLoading;
  }
}
