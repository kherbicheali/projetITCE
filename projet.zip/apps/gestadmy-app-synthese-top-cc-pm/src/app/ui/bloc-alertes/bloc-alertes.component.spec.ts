import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { AppEnum } from '../../shared/enums/app-enums';
import { IAlerte } from '../../shared/modeles/alerte.modele';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { BlocAlertesComponent } from './bloc-alertes.component';

describe('BlocAlertesComponent', () => {
  let component: BlocAlertesComponent;
  let fixture: ComponentFixture<BlocAlertesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BlocAlertesComponent],
      providers: [AlertesTopCCService],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlocAlertesComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'isLoadingCorporate$', { writable: true });
    Object.defineProperty(component, 'isLoadingNature$', { writable: true });
    Object.defineProperty(component, 'isLoadingTopCCPM$', { writable: true });
    component.isLoadingCorporate$ = of(true);
    component.isLoadingNature$ = of(true);
    component.isLoadingTopCCPM$ = of(true);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component', () => {
    component.ngOnInit();
  });

  it('getLibelleAfficherPlus', () => {
    component.alertesTopCCService.listeAlertes = mockListeAlertes;
    const res = component.getLibelleAfficherPlus();
    expect(res).toEqual(1);
  });

  it('getLibelleAfficherPlus sans alertes', () => {
    component.alertesTopCCService.listeAlertes = [];
    const res = component.getLibelleAfficherPlus();
    expect(res).toEqual(0);
  });

  it('actionExtension', () => {
    component.listeAlerteExpanded = true;
    component.actionExtension();
    expect(component.listeAlerteExpanded).toBeFalsy();
  });

  it('isAlertesLoading à vrai', () => {
    component['isCouleurTopCCLoading'] = true;
    component['isDonneesCorporateLoading'] = true;
    component['isDonneesNatureLoading'] = true;
    const retour = component.isAlertesLoading();
    expect(retour).toBeTruthy();
  });

  it('isAlertesLoading à faux', () => {
    component['isCouleurTopCCLoading'] = false;
    component['isDonneesCorporateLoading'] = false;
    component['isDonneesNatureLoading'] = false;
    const retour = component.isAlertesLoading();
    expect(retour).toBeFalsy();
  });

  const mockListeAlertes: IAlerte[] = [
    {
      codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
      entete: 'Coordonnées',
      message: 'Justificatif manquant',
      isBloquante: true
    },
    {
      codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_STATUTS,
      entete: 'Statuts',
      message: 'Justificatif manquant',
      isBloquante: true
    },
    {
      codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_ACTIVITE_ECO,
      entete: 'Activité économique',
      message: 'Justificatif manquant',
      isBloquante: true
    },
    {
      codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
      entete: 'Existence juridique',
      message: 'Justificatif manquant',
      isBloquante: true
    },
    {
      codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_NOMINATIONS_REGLEMENTAIRES,
      entete: 'Nominations réglementaires',
      message: 'Justificatif manquant',
      isBloquante: true
    }
  ] as IAlerte[];
});
