import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { NotificationService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ErrorMessage } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ERREUR_REST_NOMINATIONS_REGLEMENTAIRES } from '../../shared/constantes/ihm.constantes';
import { PROCESSUS_LISA_LIEN } from '../../shared/constantes/lisa.constantes';
import { INominationsReglementaires } from '../../shared/modeles/donnees-liens.modele';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { DonneesLiensState } from '../../shared/states/donnees-liens/donnees-liens.state';

@Component({
  selector: 'gestadmy-nominations-reglementaires',
  templateUrl: './nominations-reglementaires.component.html',
  styleUrls: ['./nominations-reglementaires.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class NominationsReglementairesComponent implements OnInit, OnDestroy {
  public listeNominationsReglementaires: Array<INominationsReglementaires>;
  public identifiantPersonne: string;
  @Select(DonneesLiensState.getNominationsReglementaires) donneesNominationsReglementaires$: Observable<INominationsReglementaires[]>;
  @Select(DonneesLiensState.getError) error$: Observable<HttpErrorResponse>;
  @Select(DonneesLiensState.isLoading) isLoading$: Observable<boolean>;
  private unsubscribe$ = new Subject<void>();
  public texteErreurRestNominations: string = ERREUR_REST_NOMINATIONS_REGLEMENTAIRES;

  constructor(
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    public lisaUtilsService: LisaUtilsService,
    private store: Store,
    public alertesTopCCService: AlertesTopCCService
  ) {}

  ngOnInit(): void {
    this.identifiantPersonne = this.store.selectSnapshot(ContexteState.getContent).identifiantPersonne;

    this.donneesNominationsReglementaires$.pipe(takeUntil(this.unsubscribe$)).subscribe((listeNominations: any) => {
      this.listeNominationsReglementaires = listeNominations;
    });
  }

  public debranchementLiens() {
    this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_LIEN }).subscribe(
      (result: LisaCallbackResult) => {},
      (erreur: ErrorMessage) => {
        this.notification.openInfo("Erreur de lancement de l'application de gestion des liens");
      }
    );
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
