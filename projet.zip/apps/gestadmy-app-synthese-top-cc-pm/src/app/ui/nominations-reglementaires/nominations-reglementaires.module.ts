import { NgModule } from '@angular/core';
import { MyWayCardModule, MyWayTableModule, MyWayTooltipModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { NominationsReglementairesComponent } from './nominations-reglementaires.component';

@NgModule({
  declarations: [NominationsReglementairesComponent],
  imports: [SharedModule, MyWayCardModule, MyWayTooltipModule, MyWayTableModule],
  exports: [NominationsReglementairesComponent]
})
export class NominationsReglementairesModule {}
