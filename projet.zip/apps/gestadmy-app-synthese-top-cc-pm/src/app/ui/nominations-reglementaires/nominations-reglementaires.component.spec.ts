import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NotificationService } from '@myway/ui';
import { Store } from '@ngxs/store';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { of } from 'rxjs';
import { IContexte } from '../../shared/modeles/contexte.model';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { NominationsReglementairesComponent } from './nominations-reglementaires.component';

const MockContexte = <IContexte>{
  codeEtablissement: '17515',
  estPersonnePhysique: false,
  identifiantPersonne: '9031175'
};

describe('NominationsReglementairesComponent', () => {
  let component: NominationsReglementairesComponent;
  let fixture: ComponentFixture<NominationsReglementairesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NominationsReglementairesComponent],
      providers: [
        {
          provide: LisaAgentService,
          useValue: { next: () => {} }
        },
        {
          provide: NotificationService,
          useValue: { openInfo: () => {} }
        },
        {
          provide: LisaUtilsService,
          useValue: { debrancherVersClasseurClient: () => {} }
        },
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {}, selectSnapshot: () => MockContexte }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NominationsReglementairesComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'donneesNominationsReglementaires$', { writable: true });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component', () => {
    component.donneesNominationsReglementaires$ = of(undefined);
    component.ngOnInit();
  });
});
