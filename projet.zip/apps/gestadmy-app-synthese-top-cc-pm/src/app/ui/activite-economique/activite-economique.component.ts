import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { NotificationService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { ErrorMessage, StorageLevel } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import * as moment from 'moment';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DATAINCONNU, ERREUR_REST_ACTIVITE_ECONOMIQUE } from '../../shared/constantes/ihm.constantes';
import { PROCESSUS_LISA_CONNAISSANCE_CLIENT } from '../../shared/constantes/lisa.constantes';
import { AppEnum } from '../../shared/enums/app-enums';
import { IAlerte } from '../../shared/modeles/alerte.modele';
import { IContexte } from '../../shared/modeles/contexte.model';
import { DonneesCorporateModele } from '../../shared/modeles/donnees-corporate.modele';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { DonneesCorporateState } from '../../shared/states/donnees-corporate/donnees-corporate.state';

@Component({
  selector: 'gestadmy-activite-economique',
  templateUrl: './activite-economique.component.html',
  changeDetection: ChangeDetectionStrategy.Default
})
export class ActiviteEconomiqueComponent implements OnInit, OnDestroy {
  public activiteEconomique: DonneesCorporateModele.IActiviteEconomique;
  public texteErreurRestActiviteEco: string;
  public identifiantPersonne: string;
  @Select(DonneesCorporateState.getActiviteEconomique) donneesActiviteEconomique$: Observable<DonneesCorporateModele.IActiviteEconomique>;
  @Select(DonneesCorporateState.getError) error$: Observable<HttpErrorResponse>;
  @Select(DonneesCorporateState.isLoading) isLoading$: Observable<boolean>;
  @Select(ContexteState.getContent) dataContexte$: Observable<IContexte>;
  private unsubscribe$ = new Subject<void>();

  constructor(
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    private contextAgentService: ContextAgentService,
    public lisaUtilsService: LisaUtilsService,
    private store: Store,
    public alertesTopCCService: AlertesTopCCService
  ) {}

  ngOnInit() {
    this.identifiantPersonne = this.store.selectSnapshot(ContexteState.getContent).identifiantPersonne;
    this.texteErreurRestActiviteEco = ERREUR_REST_ACTIVITE_ECONOMIQUE;

    this.donneesActiviteEconomique$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((activiteEco: DonneesCorporateModele.IActiviteEconomique) => {
        if (activiteEco) {
          this.activiteEconomique = activiteEco;
          this.ajoutAlerteBilan();
        }
      });
  }

  public ajoutAlerteBilan(): void {
    if (
      moment()
        .startOf('day')
        .diff(moment(this.activiteEconomique.dateArrete + '/' + this.activiteEconomique.anneeDernierBilan, 'DD/MM/YYYY'), 'months') > 18
    ) {
      const alerteBilanPerimeActiviteEco: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_ACTIVITE_ECO,
        entete: 'Activité économique',
        message: 'Bilan > 18 mois',
        isBloquante: false
      };
      this.alertesTopCCService.ajouterAlerte(alerteBilanPerimeActiviteEco);
    }
    if (this.activiteEconomique.chiffreAffaire === DATAINCONNU) {
      const alerteBudgetActiviteEco: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_ACTIVITE_ECO,
        entete: 'Activité économique',
        message: 'Bilan absent',
        isBloquante: false
      };
      this.alertesTopCCService.ajouterAlerte(alerteBudgetActiviteEco);
    }
  }

  public debranchementConnClientFinn() {
    const keyValuesToAdd: Map<string, any> = new Map<string, any>([['codePage', 'financier']]);
    this.contextAgentService
      .addListToContext({
        keyValues: keyValuesToAdd,
        storageLevel: StorageLevel.Process
      })
      .subscribe(
        () => {
          this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_CONNAISSANCE_CLIENT }).subscribe(
            (result: LisaCallbackResult) => {},
            (erreur: ErrorMessage) => {
              this.notification.openInfo("Erreur de lancement de l'application Connaissance Client");
            }
          );
        },
        (erreur: ErrorMessage) => {
          this.notification.openInfo("Erreur d'enregistrement dans le contexte");
        }
      );
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
