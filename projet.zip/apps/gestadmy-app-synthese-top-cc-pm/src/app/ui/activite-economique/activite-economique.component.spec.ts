import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NotificationService } from '@myway/ui';
import { Store } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { of } from 'rxjs';
import { IContexte } from '../../shared/modeles/contexte.model';
import { DonneesCorporateModele } from '../../shared/modeles/donnees-corporate.modele';
import { AbstractMockObservableService } from '../../shared/services/utils/abstract-mock-observable.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ActiviteEconomiqueComponent } from './activite-economique.component';

class ContextAgentMockService extends AbstractMockObservableService {
  addListToContext(param: { keyValues: Map<string, any>; storageLevel: number }) {
    return this;
  }
}

const MockContexte = <IContexte>{
  codeEtablissement: '17515',
  estPersonnePhysique: false,
  identifiantPersonne: '9031175'
};

describe('ActiviteEconomiqueComponent', () => {
  let component: ActiviteEconomiqueComponent;
  let fixture: ComponentFixture<ActiviteEconomiqueComponent>;
  const contextAgentServiceStub = new ContextAgentMockService();
  let mockDate;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ActiviteEconomiqueComponent],
      providers: [
        {
          provide: LisaAgentService,
          useValue: { next: () => {} }
        },
        {
          provide: NotificationService,
          useValue: { openInfo: () => {} }
        },
        {
          provide: ContextAgentService,
          useValue: contextAgentServiceStub
        },
        {
          provide: LisaUtilsService,
          useValue: { debrancherVersClasseurClient: () => {} }
        },
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {}, selectSnapshot: () => MockContexte }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiviteEconomiqueComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'donneesActiviteEconomique$', { writable: true });
    mockDate = require('mockdate');
    mockDate.set('06/05/2020');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component pas de donnees activité économique', () => {
    component.donneesActiviteEconomique$ = of(undefined);
    component.ngOnInit();
  });

  it('init component avec donnees activité économique', () => {
    component.donneesActiviteEconomique$ = of(mockDonneesActiviteEco);
    component.ngOnInit();
    expect(component.activiteEconomique).toEqual(mockDonneesActiviteEco);
  });

  it('destroy component', () => {
    component.ngOnDestroy();
  });

  const mockDonneesActiviteEco: DonneesCorporateModele.IActiviteEconomique = {
    anneeDernierBilan: '2018',
    chiffreAffaire: '4152',
    dateArrete: '31/12',
    effectif: '80'
  } as DonneesCorporateModele.IActiviteEconomique;
});
