import { NgModule } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MyWayCardModule, MyWayLabelModule, MyWayTooltipModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { ActiviteEconomiqueComponent } from './activite-economique.component';

@NgModule({
  declarations: [ActiviteEconomiqueComponent],
  imports: [SharedModule, MyWayCardModule, MyWayTooltipModule, MatFormFieldModule, MatInputModule, MyWayLabelModule],
  exports: [ActiviteEconomiqueComponent]
})
export class ActiviteEconomiqueModule {}
