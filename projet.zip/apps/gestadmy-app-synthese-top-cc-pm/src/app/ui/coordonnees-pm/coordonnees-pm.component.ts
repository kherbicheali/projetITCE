import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { NotificationService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { ErrorMessage, StorageLevel } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {
  CLASSE_EMAIL,
  CLASSE_TELEPHONE,
  ERREUR_REST_COORDONNEES,
  MEDIA_ABSENT,
  NO_CONTACT_PRINCIPAL
} from '../../shared/constantes/ihm.constantes';
import { PROCESSUS_LISA_CONNAISSANCE_CLIENT, PROCESSUS_LISA_LIEN } from '../../shared/constantes/lisa.constantes';
import { AppEnum } from '../../shared/enums/app-enums';
import { IAlerte } from '../../shared/modeles/alerte.modele';
import { DonneesCorporateModele } from '../../shared/modeles/donnees-corporate.modele';
import { InformationsAdministrativesModele } from '../../shared/modeles/informations-administratives.modele';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { DonneesAdministrativesState } from '../../shared/states/donnees-administratives/donnees-administratives.state';
import { DonneesCorporateState } from '../../shared/states/donnees-corporate/donnees-corporate.state';

@Component({
  selector: 'gestadmy-coordonnees-pm',
  templateUrl: './coordonnees-pm.component.html',
  styleUrls: ['./coordonnees-pm.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class CoordonneesPmComponent implements OnInit, OnDestroy {
  public textNoContactPrincipal: string;
  public texteErreurRestCoordonnees: string;
  @Select(DonneesAdministrativesState.getContent) donneesAdministrative$: Observable<
    InformationsAdministrativesModele.IDonneesAdministratives
  >;
  @Select(DonneesAdministrativesState.getError) error$: Observable<HttpErrorResponse>;
  @Select(DonneesAdministrativesState.isLoading) isLoading$: Observable<boolean>;
  @Select(DonneesCorporateState.getContent) donneesCorporate$: Observable<DonneesCorporateModele.IDonneesCorporate>;
  coordonnees: InformationsAdministrativesModele.IDonneesAdministratives;
  private unsubscribe$ = new Subject<void>();
  public identifiantPersonne: string;
  private estPersonnePhysique: boolean;

  constructor(
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    private contextAgentService: ContextAgentService,
    public lisaUtilsService: LisaUtilsService,
    private store: Store,
    public alertesTopCCService: AlertesTopCCService
  ) {}

  ngOnInit() {
    this.textNoContactPrincipal = NO_CONTACT_PRINCIPAL;
    this.texteErreurRestCoordonnees = ERREUR_REST_COORDONNEES;
    this.identifiantPersonne = this.store.selectSnapshot(ContexteState.getContent).identifiantPersonne;
    this.estPersonnePhysique = this.store.selectSnapshot(ContexteState.getContent).estPersonnePhysique;

    this.donneesAdministrative$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((result: InformationsAdministrativesModele.IDonneesAdministratives) => {
        if (result) {
          this.coordonnees = result;
        }
      });

    this.donneesCorporate$.pipe(takeUntil(this.unsubscribe$)).subscribe((result: DonneesCorporateModele.IDonneesCorporate) => {
      if (result) {
        this.ajoutAlertePnd(result);
      }
    });
  }

  getClassMedia(media: InformationsAdministrativesModele.IMediaPM): string {
    let reponse = CLASSE_TELEPHONE;
    if (media && media.type === InformationsAdministrativesModele.enumMediaType.Email) {
      reponse = CLASSE_EMAIL;

      if (media.valeur === MEDIA_ABSENT) {
        reponse += ' disabled';
      }
    }
    return reponse;
  }

  private ajoutAlertePnd(donneesCorporate: DonneesCorporateModele.IDonneesCorporate) {
    if (donneesCorporate.nombrePNDAdresseSiege > 0) {
      const alertePndAdresseSiege: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_COORDONNEES,
        entete: 'Coordonnées',
        message: 'Adresse légale du siège en NPAI',
        isBloquante: true
      };
      this.alertesTopCCService.ajouterAlerte(alertePndAdresseSiege);
    }
  }

  clickMedia(media: InformationsAdministrativesModele.IMediaPM) {
    if (media && media.type === InformationsAdministrativesModele.enumMediaType.Email) {
      const mailText = 'mailto:' + media.valeur;
      window.location.href = mailText;
    }
  }

  public debranchementConnClientIdent() {
    const keyValuesToAdd: Map<string, any> = new Map<string, any>([
      ['codePage', this.estPersonnePhysique ? 'activitePro' : 'identification']
    ]);
    this.contextAgentService
      .addListToContext({
        keyValues: keyValuesToAdd,
        storageLevel: StorageLevel.Process
      })
      .subscribe(
        () => {
          this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_CONNAISSANCE_CLIENT }).subscribe(
            (result: LisaCallbackResult) => {},
            (erreur: ErrorMessage) => {
              this.notification.openInfo("Erreur de lancement de l'application Connaissance Client");
            }
          );
        },
        (erreur: ErrorMessage) => {
          this.notification.openInfo("Erreur d'enregistrement dans le contexte");
        }
      );
  }

  public debranchementLiens() {
    this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_LIEN }).subscribe(
      (result: LisaCallbackResult) => {},
      (erreur: ErrorMessage) => {
        this.notification.openInfo("Erreur de lancement de l'application de gestion des liens");
      }
    );
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
