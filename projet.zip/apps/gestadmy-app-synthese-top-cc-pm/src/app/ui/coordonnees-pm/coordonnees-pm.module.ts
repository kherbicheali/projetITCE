import { NgModule } from '@angular/core';
import { MyWayCardModule, MyWayImageButtonModule, MyWaySeparatorModule, MyWayTooltipModule } from '@myway/ui';
import { MediaDisplayModule } from '@myway/ui-synthese';
import { SharedModule } from '../../shared/shared.module';
import { CoordonneesPmComponent } from './coordonnees-pm.component';

@NgModule({
  declarations: [CoordonneesPmComponent],
  imports: [SharedModule, MyWayCardModule, MyWaySeparatorModule, MyWayTooltipModule, MyWayImageButtonModule, MediaDisplayModule],
  exports: [CoordonneesPmComponent]
})
export class CoordonneesPmModule {}
