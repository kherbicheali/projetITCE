import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NotificationService } from '@myway/ui';
import { Store } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { of } from 'rxjs';
import { CLASSE_EMAIL, CLASSE_TELEPHONE } from '../../shared/constantes/ihm.constantes';
import { IContexte } from '../../shared/modeles/contexte.model';
import { DonneesCorporateModele } from '../../shared/modeles/donnees-corporate.modele';
import { InformationsAdministrativesModele as modelDataAdmin } from '../../shared/modeles/informations-administratives.modele';
import { AbstractMockObservableService } from '../../shared/services/utils/abstract-mock-observable.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { CoordonneesPmComponent } from './coordonnees-pm.component';

class ContextAgentMockService extends AbstractMockObservableService {
  addListToContext(param: { keyValues: Map<string, any>; storageLevel: number }) {
    return this;
  }
}

const MockContexte = <IContexte>{
  codeEtablissement: '17515',
  estPersonnePhysique: false,
  identifiantPersonne: '9031175'
};

describe('CoordonneesPmComponent', () => {
  let component: CoordonneesPmComponent;
  let fixture: ComponentFixture<CoordonneesPmComponent>;
  let lisaUtilsService: LisaUtilsService;
  const contextAgentServiceStub = new ContextAgentMockService();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CoordonneesPmComponent],
      providers: [
        {
          provide: LisaAgentService,
          useValue: { next: () => {} }
        },
        {
          provide: NotificationService,
          useValue: { openInfo: () => {} }
        },
        {
          provide: ContextAgentService,
          useValue: contextAgentServiceStub
        },
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {}, selectSnapshot: () => MockContexte }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
    lisaUtilsService = TestBed.inject(LisaUtilsService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoordonneesPmComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'donneesAdministrative$', { writable: true });
    Object.defineProperty(component, 'donneesCorporate$', { writable: true });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component pas de donnees admin', () => {
    component.donneesAdministrative$ = of(undefined);
    component.donneesCorporate$ = of(undefined);
    component.ngOnInit();
  });

  it('init component avec donnees admin', () => {
    component.donneesAdministrative$ = of(mockDonneesAdmin);
    component.donneesCorporate$ = of(mockDonneesCorporate);
    component.ngOnInit();
    expect(component.coordonnees).toEqual(mockDonneesAdmin);
  });

  it('recupere la classe telephones pour le composant ihm des medias', () => {
    const classe = component.getClassMedia(mockDonneesMediaTel);
    expect(classe).toEqual(CLASSE_TELEPHONE);
  });

  it('recupere la classe emails pour le composant ihm des medias', () => {
    const classe = component.getClassMedia(mockDonneesMediaEmail);
    expect(classe).toEqual(CLASSE_EMAIL);
  });
});

const mockDonneesAdmin: modelDataAdmin.IDonneesAdministratives = {
  raisonSociale: 'ICYACJO EVAYEYAV EBTYTO',
  nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
  numeroSiren: '302769161',
  adressePrincipale: { ligne2: null, ligne3: null, ligne4: '1    RUE DU GAZ', ligne5: 'BP 93330', ligne6: '12033 RODEZ CEDEX 9' },
  interlocuteurPrincipal: {
    designation: 'MR JALADEAU FREDERIC',
    medias: [
      { estMediaValeur: true, type: 1, valeur: '05 65 73 31 92' },
      { estMediaValeur: false, type: 2, valeur: 'Non Renseigné' },
      { estMediaValeur: true, type: 0, valeur: 'fjaladeau@udaf12.fr' }
    ],
    poste: 'CONTACT BANQUE A DISTANCE'
  }
} as modelDataAdmin.IDonneesAdministratives;

const mockDonneesMediaTel: modelDataAdmin.IMediaPM = {
  estMediaValeur: true,
  type: 1,
  valeur: '05 65 73 31 92'
} as modelDataAdmin.IMediaPM;

const mockDonneesMediaEmail: modelDataAdmin.IMediaPM = {
  estMediaValeur: true,
  type: 0,
  valeur: 'fjaladeau@udaf12.fr'
} as modelDataAdmin.IMediaPM;

const mockDonneesCorporate: DonneesCorporateModele.IDonneesCorporate = {
  activiteEconomique: {
    anneeDernierBilan: '2018',
    chiffreAffaire: 'K€4,152',
    dateArrete: '31/12',
    effectif: '80'
  },
  existenceJuridique: {
    categorieJuridique: '9220',
    dateCloture: '01/01/2020',
    dateCreation: '01/01/1900',
    montantCapitalSocial: '€306,000',
    nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
    numeroSiren: '302769161',
    raisonSocial: 'ICYACJO EVAYEYAV EBTYTO',
    secteurActivite: '8899B'
  },
  nombrePNDAdresseSiege: 0
};
