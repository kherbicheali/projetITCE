import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { DonneesTopCCState } from '../../shared/states/donnees-top-cc/donnees-top-cc.state';
import { BlocStatutTopCcComponent } from './bloc-statut-top-cc.component';

describe('BlocStatutTopCcComponent', () => {
  let component: BlocStatutTopCcComponent;
  let fixture: ComponentFixture<BlocStatutTopCcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BlocStatutTopCcComponent],
      providers: [
        {
          provide: DonneesTopCCState,
          useValue: { getContent: () => {}, isLoading: () => {}, getError: () => {} }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlocStatutTopCcComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'donneesTopCC$', { writable: true });
    component.donneesTopCC$ = of(undefined);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component', () => {
    component.ngOnInit();
  });

  it('init component avec donnees top cc', () => {
    component.donneesTopCC$ = of(MockAppDonneesTopCCComplet);
    component.ngOnInit();
    expect(component.donneesTopCC).toEqual(MockAppDonneesTopCCComplet);
  });
});

export const MockAppDonneesTopCCComplet = {
  couleurTopCC: 'V',
  derniereActualisation: '30/10/2020',
  dateDebutPeriodeActualisation: '01/08/2021',
  dateFinPeriodeActualisation: '31/12/2030',
  dateBlocage: '28/04/2022'
};
