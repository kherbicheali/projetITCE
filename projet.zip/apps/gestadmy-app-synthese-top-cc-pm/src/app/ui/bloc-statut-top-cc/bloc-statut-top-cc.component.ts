import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { Select } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {
  ERREUR_REST_COULEUR_TOPCC_PM,
  LIBELLE_COULEUR_TOPCC_BLANC,
  LIBELLE_COULEUR_TOPCC_ORANGE,
  LIBELLE_COULEUR_TOPCC_ROUGE,
  LIBELLE_COULEUR_TOPCC_VERT
} from '../../shared/constantes/ihm.constantes';
import { IDonneesTopCC } from '../../shared/modeles/donnees-top-cc.modele';
import { DonneesTopCCState } from '../../shared/states/donnees-top-cc/donnees-top-cc.state';

@Component({
  selector: 'gestadmy-bloc-statut-top-cc',
  templateUrl: './bloc-statut-top-cc.component.html',
  styleUrls: ['./bloc-statut-top-cc.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BlocStatutTopCcComponent implements OnInit, OnDestroy {
  donneesTopCC: IDonneesTopCC;
  @Select(DonneesTopCCState.getContent) donneesTopCC$: Observable<IDonneesTopCC>;
  @Select(DonneesTopCCState.isLoading) isLoadingTopCCPM$: Observable<boolean>;
  @Select(DonneesTopCCState.getError) errorTopCCPM$: Observable<HttpErrorResponse>;
  private unsubscribe$ = new Subject<void>();
  public texteErreurRestCouleurTopCCPM: string = ERREUR_REST_COULEUR_TOPCC_PM;

  constructor() {}

  ngOnInit(): void {
    this.donneesTopCC$.pipe(takeUntil(this.unsubscribe$)).subscribe((donneesTopCCPM: IDonneesTopCC) => {
      if (donneesTopCCPM) {
        this.donneesTopCC = donneesTopCCPM;
      }
    });
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  /* istanbul ignore next */
  public getLibelleCouleurTopCC(codeCouleur: string): string {
    let libelle: string;
    switch (codeCouleur) {
      case 'V': {
        libelle = LIBELLE_COULEUR_TOPCC_VERT;
        break;
      }
      case 'O': {
        libelle = LIBELLE_COULEUR_TOPCC_ORANGE;
        break;
      }
      case 'R': {
        libelle = LIBELLE_COULEUR_TOPCC_ROUGE;
        break;
      }
      case '': {
        libelle = LIBELLE_COULEUR_TOPCC_BLANC;
        break;
      }
      default: {
        libelle = LIBELLE_COULEUR_TOPCC_BLANC;
        break;
      }
    }
    return libelle;
  }
}
