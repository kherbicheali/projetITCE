import { NgModule } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MyWayLabelModule, MyWaySeparatorModule, MyWayTileModule, MyWayTooltipModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { BlocStatutTopCcComponent } from './bloc-statut-top-cc.component';

@NgModule({
  declarations: [BlocStatutTopCcComponent],
  imports: [SharedModule, MyWaySeparatorModule, MyWayTooltipModule, MatFormFieldModule, MatInputModule, MyWayLabelModule, MyWayTileModule],
  exports: [BlocStatutTopCcComponent]
})
export class BlocStatutTopCcModule {}
