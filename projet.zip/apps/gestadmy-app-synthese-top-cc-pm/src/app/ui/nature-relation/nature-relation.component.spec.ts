import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { NatureRelationComponent } from './nature-relation.component';

describe('NatureRelationComponent', () => {
  let component: NatureRelationComponent;
  let fixture: ComponentFixture<NatureRelationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NatureRelationComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NatureRelationComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'donneesNatureRelation$', { writable: true });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component', () => {
    component.donneesNatureRelation$ = of(undefined);
    component.ngOnInit();
  });
});
