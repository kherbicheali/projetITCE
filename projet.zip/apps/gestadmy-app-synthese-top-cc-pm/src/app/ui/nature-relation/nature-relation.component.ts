import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Select } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ERREUR_REST_NATURE_RELATION } from '../../shared/constantes/ihm.constantes';
import { INatureRelation } from '../../shared/modeles/nature-relation.modele';
import { DonneesNatureRelationState } from '../../shared/states/donnees-nature-relation/donnees-nature-relation.state';

@Component({
  selector: 'gestadmy-nature-relation',
  templateUrl: './nature-relation.component.html',
  styleUrls: ['./nature-relation.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NatureRelationComponent implements OnInit {
  public natureRelation: INatureRelation;
  public texteErreurRestNatureRelation: string;
  @Select(DonneesNatureRelationState.getContent) donneesNatureRelation$: Observable<INatureRelation>;
  @Select(DonneesNatureRelationState.getError) error$: Observable<HttpErrorResponse>;
  @Select(DonneesNatureRelationState.isLoading) isLoading$: Observable<boolean>;
  private unsubscribe$ = new Subject<void>();

  constructor() {}

  ngOnInit() {
    this.texteErreurRestNatureRelation = ERREUR_REST_NATURE_RELATION;

    this.donneesNatureRelation$.pipe(takeUntil(this.unsubscribe$)).subscribe((result: INatureRelation) => {
      if (result) {
        this.natureRelation = result;
      }
    });
  }
}
