import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { NotificationService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ErrorMessage } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ERREUR_REST_EAI } from '../../shared/constantes/ihm.constantes';
import { PROCESSUS_LISA_EAI } from '../../shared/constantes/lisa.constantes';
import { IEchangeAutomatiqueInformations } from '../../shared/modeles/echange-automatique-informations.modele';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { DonneesEaiState } from '../../shared/states/donnees-eai/donnees-eai.state';

@Component({
  selector: 'gestadmy-eai-auto-certification',
  templateUrl: './eai-auto-certification.component.html',
  changeDetection: ChangeDetectionStrategy.Default
})
export class EaiAutoCertificationComponent implements OnInit, OnDestroy {
  public eai: IEchangeAutomatiqueInformations;
  @Select(DonneesEaiState.getContent) donneesEai$: Observable<IEchangeAutomatiqueInformations>;
  @Select(DonneesEaiState.getError) error$: Observable<HttpErrorResponse>;
  @Select(DonneesEaiState.isLoading) isLoading$: Observable<boolean>;
  private unsubscribe$ = new Subject<void>();
  public texteErreurRestEai: string = ERREUR_REST_EAI;
  public identifiantPersonne: string;

  constructor(
    private lisaAgentService: LisaAgentService,
    private notificationService: NotificationService,
    public lisaUtilsService: LisaUtilsService,
    private store: Store,
    public alertesTopCCService: AlertesTopCCService
  ) {}

  ngOnInit(): void {
    this.identifiantPersonne = this.store.selectSnapshot(ContexteState.getContent).identifiantPersonne;

    this.donneesEai$.pipe(takeUntil(this.unsubscribe$)).subscribe((result: IEchangeAutomatiqueInformations) => {
      if (result) {
        this.eai = result;
      }
    });
  }

  public debranchementEai() {
    this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_EAI }).subscribe(
      (result: LisaCallbackResult) => {
        console.log('Sortie du processus');
      },
      (erreur: ErrorMessage) => {
        this.notificationService.openInfo("Erreur de lancement de l'application EAI");
      }
    );
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
