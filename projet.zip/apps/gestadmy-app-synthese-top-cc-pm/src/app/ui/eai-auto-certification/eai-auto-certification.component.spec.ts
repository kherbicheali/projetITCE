import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NotificationService } from '@myway/ui';
import { Store } from '@ngxs/store';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { of } from 'rxjs';
import { IContexte } from '../../shared/modeles/contexte.model';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { EaiAutoCertificationComponent } from './eai-auto-certification.component';

const MockContexte = <IContexte>{
  codeEtablissement: '17515',
  estPersonnePhysique: false,
  identifiantPersonne: '9031175'
};

describe('EaiAutoCertificationComponent', () => {
  let component: EaiAutoCertificationComponent;
  let fixture: ComponentFixture<EaiAutoCertificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EaiAutoCertificationComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        {
          provide: LisaAgentService,
          useValue: { next: () => {} }
        },
        {
          provide: NotificationService,
          useValue: { openInfo: () => {} }
        },
        {
          provide: LisaUtilsService,
          useValue: { debrancherVersClasseurClient: () => {} }
        },
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {}, selectSnapshot: () => MockContexte }
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EaiAutoCertificationComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'donneesEai$', { writable: true });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component', () => {
    component.donneesEai$ = of(undefined);
    component.ngOnInit();
  });
});
