import { NgModule } from '@angular/core';
import { MyWayCardModule, MyWayTableModule, MyWayTooltipModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { BeneficiairesEffectifsComponent } from './beneficiaires-effectifs.component';

@NgModule({
  declarations: [BeneficiairesEffectifsComponent],
  imports: [SharedModule, MyWayCardModule, MyWayTooltipModule, MyWayTableModule],
  exports: [BeneficiairesEffectifsComponent]
})
export class BeneficiairesEffectifsModule {}
