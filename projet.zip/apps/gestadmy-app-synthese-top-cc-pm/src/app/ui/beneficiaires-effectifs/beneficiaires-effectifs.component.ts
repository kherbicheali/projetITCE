import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { NotificationService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ErrorMessage } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ERREUR_REST_BENEFICIAIRES_EFFECTIFS } from '../../shared/constantes/ihm.constantes';
import { PROCESSUS_LISA_LIEN } from '../../shared/constantes/lisa.constantes';
import { IBeneficiaireEffectif } from '../../shared/modeles/donnees-liens.modele';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { DonneesLiensState } from '../../shared/states/donnees-liens/donnees-liens.state';

@Component({
  selector: 'gestadmy-beneficiaires-effectifs',
  templateUrl: './beneficiaires-effectifs.component.html',
  changeDetection: ChangeDetectionStrategy.Default
})
export class BeneficiairesEffectifsComponent implements OnInit, OnDestroy {
  public listeBeneficiaireEffectifs: Array<IBeneficiaireEffectif>;
  @Select(DonneesLiensState.getBeneficiairesEffectifs) donneesBeneficiairesEffectifs$: Observable<IBeneficiaireEffectif[]>;
  @Select(DonneesLiensState.getError) error$: Observable<HttpErrorResponse>;
  @Select(DonneesLiensState.isLoading) isLoading$: Observable<boolean>;
  private unsubscribe$ = new Subject<void>();
  public texteErreurRestBeneficiairesEffectifs: string = ERREUR_REST_BENEFICIAIRES_EFFECTIFS;
  public identifiantPersonne: string;

  constructor(
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    public lisaUtilsService: LisaUtilsService,
    private store: Store,
    public alertesTopCCService: AlertesTopCCService
  ) {}

  ngOnInit(): void {
    this.identifiantPersonne = this.store.selectSnapshot(ContexteState.getContent).identifiantPersonne;

    this.donneesBeneficiairesEffectifs$.pipe(takeUntil(this.unsubscribe$)).subscribe((liste: any) => {
      this.listeBeneficiaireEffectifs = liste;
    });
  }

  public debranchementLiens() {
    this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_LIEN }).subscribe(
      (result: LisaCallbackResult) => {},
      (erreur: ErrorMessage) => {
        this.notification.openInfo("Erreur de lancement de l'application de gestion des liens");
      }
    );
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
