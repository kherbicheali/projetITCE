import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ERREUR_REST_PPE } from '../../shared/constantes/ihm.constantes';
import { AppEnum } from '../../shared/enums/app-enums';
import { IContact } from '../../shared/modeles/contact.modele';
import { IContexte } from '../../shared/modeles/contexte.model';
import { IBeneficiaireEffectif, IDonneesLiens } from '../../shared/modeles/donnees-liens.modele';
import { InformationsAdministrativesModele } from '../../shared/modeles/informations-administratives.modele';
import { DonneesLiensService } from '../../shared/services/donnees-liens/donnees-liens.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { DonneesAdministrativesState } from '../../shared/states/donnees-administratives/donnees-administratives.state';
import { DonneesLiensState } from '../../shared/states/donnees-liens/donnees-liens.state';

@Component({
  selector: 'gestadmy-ppe',
  templateUrl: './ppe.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PpeComponent implements OnInit, OnDestroy {
  public contactPPE: IContact;
  public contexte: IContexte;
  private nomCommercial: string;
  @Select(DonneesAdministrativesState.getContent) donneesAdministrative$: Observable<
    InformationsAdministrativesModele.IDonneesAdministratives
  >;
  @Select(DonneesAdministrativesState.isLoading) isLoadingAdministrative$: Observable<boolean>;
  @Select(DonneesAdministrativesState.getError) errorAdministrative$: Observable<HttpErrorResponse>;
  @Select(DonneesLiensState.getContent) donneesLiens$: Observable<IDonneesLiens>;
  @Select(DonneesLiensState.getError) errorLiens$: Observable<HttpErrorResponse>;
  @Select(DonneesLiensState.isLoading) isLoadingLiens$: Observable<boolean>;
  private unsubscribe$ = new Subject<void>();
  public texteErreurRestPPE: string = ERREUR_REST_PPE;
  public recherchePpePersPhysEnCours: boolean;
  public erreurRecherchePpePersPhys: boolean;

  constructor(
    public lisaUtilsService: LisaUtilsService,
    private store: Store,
    private donneesLiensService: DonneesLiensService,
    private changeDetectionRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.contexte = this.store.selectSnapshot(ContexteState.getContent);

    if (this.contexte.estPersonnePhysique) {
      this.donneesAdministrative$
        .pipe(takeUntil(this.unsubscribe$))
        .subscribe((data: InformationsAdministrativesModele.IDonneesAdministratives) => {
          if (data) {
            this.nomCommercial = data.nomCommercial;
            const listeLienAvecPPSeul: IBeneficiaireEffectif[] = <IBeneficiaireEffectif[]>[
              {
                numeroPersonne: this.contexte.identifiantPersonne,
                role: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
                identite: this.nomCommercial
              }
            ];
            this.recherchePpePersPhysEnCours = true;
            this.donneesLiensService.completerInfosPPE(this.contexte.codeEtablissement, listeLienAvecPPSeul).subscribe(
              (listePPSeulAvecPPE: IBeneficiaireEffectif[]) => {
                this.recherchePpePersPhysEnCours = false;
                if (listePPSeulAvecPPE && listePPSeulAvecPPE[0] && listePPSeulAvecPPE[0].ppe) {
                  this.contactPPE = {
                    designation: listePPSeulAvecPPE[0].identite,
                    role: listePPSeulAvecPPE[0].role
                  };
                }
                this.changeDetectionRef.detectChanges();
              },
              /* istanbul ignore next */
              (erreur: HttpErrorResponse) => {
                if (erreur) {
                  this.recherchePpePersPhysEnCours = false;
                  this.erreurRecherchePpePersPhys = true;
                }
                this.changeDetectionRef.detectChanges();
              }
            );
          }
        });
    } else {
      this.donneesLiens$.pipe(takeUntil(this.unsubscribe$)).subscribe((donneesLiens: IDonneesLiens) => {
        if (donneesLiens) {
          const listeRepresentantLegaux = donneesLiens.listeNominationsReglementaires.filter(
            nomination => nomination.fonction === AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString()
          );
          const representantLegalPPE = listeRepresentantLegaux.find(representant => representant.ppe);

          if (representantLegalPPE) {
            this.contactPPE = {
              designation: representantLegalPPE.identite,
              role: representantLegalPPE.fonction
            };
          } else {
            const beneficiairePPE = donneesLiens.listeBeneficiairesEffectifs.find(be => be.ppe);

            if (beneficiairePPE) {
              this.contactPPE = {
                designation: beneficiairePPE.identite,
                role: beneficiairePPE.role
              };
            }
          }
        }
      });
    }
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
