import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgxsModule, Store } from '@ngxs/store';
import { of } from 'rxjs';
import { AppEnum } from '../../shared/enums/app-enums';
import { IContexte } from '../../shared/modeles/contexte.model';
import { DonneesLiensService } from '../../shared/services/donnees-liens/donnees-liens.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { DonneesAdministrativesState } from '../../shared/states/donnees-administratives/donnees-administratives.state';
import { DonneesLiensState } from '../../shared/states/donnees-liens/donnees-liens.state';
import { PpeComponent } from './ppe.component';

const MockContexte = <IContexte>{
  codeEtablissement: '17515',
  estPersonnePhysique: false,
  identifiantPersonne: '9031175'
};

describe('PpeComponent', () => {
  let component: PpeComponent;
  let fixture: ComponentFixture<PpeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PpeComponent],
      imports: [NgxsModule.forRoot([])],
      providers: [
        {
          provide: LisaUtilsService,
          useValue: { debrancherVersClasseurClient: () => {} }
        },
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {}, selectSnapshot: () => MockContexte }
        },
        {
          provide: DonneesAdministrativesState,
          useValue: { getContent: () => {}, isLoading: () => {}, getError: () => {} }
        },
        {
          provide: DonneesLiensState,
          useValue: {
            getContent: () => {},
            getBeneficiairesEffectifs: () => {},
            getNominationsReglementaires: () => {},
            isLoading: () => {},
            getError: () => {}
          }
        },
        {
          provide: DonneesLiensService,
          useValue: {
            completerInfosPPE: (codeEtablissement: string, liste: any[]) => {}
          }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PpeComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'donneesLiens$', { writable: true });
    Object.defineProperty(component, 'donneesAdministrative$', { writable: true });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component', () => {
    component.donneesLiens$ = of(undefined);
    component.ngOnInit();
    expect(component.contactPPE).toBeUndefined();
  });

  it('init component sans representant légal et sans ppe', () => {
    component.donneesLiens$ = of(MockDonneesLiens);
    component.ngOnInit();
    expect(component.contactPPE).toBeUndefined();
  });

  it('init component avec representant légal ppe', () => {
    component.donneesLiens$ = of(MockDonneesLiensRepresentantLegalPPE);
    component.ngOnInit();
    expect(component.contactPPE).toEqual(MockRetourRepresentantLegalPPE);
  });

  it('init component sans representant légal et be ppe', () => {
    component.donneesLiens$ = of(MockDonneesLiensBePPE);
    component.ngOnInit();
    expect(component.contactPPE).toEqual(MockRetourBeneficiairePPE);
  });

  it('init component EI sans donnees admin', () => {
    spyOn(component['store'], 'selectSnapshot').and.returnValue({
      identifiantPersonne: '123456789',
      estPersonnePhysique: true
    });
    component.donneesAdministrative$ = of(undefined);
    component.ngOnInit();
    expect(component.contactPPE).toBeUndefined();
  });

  it('init component EI sans ppe', () => {
    spyOn(component['store'], 'selectSnapshot').and.returnValue({
      identifiantPersonne: '123456789',
      estPersonnePhysique: true
    });
    spyOn(component['donneesLiensService'], 'completerInfosPPE').and.returnValue(
      of([
        {
          numeroPersonne: '123456789',
          role: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
          identite: 'MIWTO BELYB',
          ppe: false,
          provenanceStatutPpe: ''
        }
      ])
    );
    component.donneesAdministrative$ = of(MockDonneesAdmin);
    component.ngOnInit();
    expect(component['nomCommercial']).toEqual('MIWTO BELYB');
    expect(component.contactPPE).toBeUndefined();
  });

  it('init component EI avec ppe', () => {
    spyOn(component['store'], 'selectSnapshot').and.returnValue({
      identifiantPersonne: '123456789',
      estPersonnePhysique: true
    });
    spyOn(component['donneesLiensService'], 'completerInfosPPE').and.returnValue(
      of([
        {
          numeroPersonne: '123456789',
          role: AppEnum.LibelleTypeLienNominationReglementaires.REPRESENTANT_LEGAL.toString(),
          identite: 'MIWTO BELYB',
          ppe: true,
          provenanceStatutPpe: ''
        }
      ])
    );
    component.donneesAdministrative$ = of(MockDonneesAdmin);
    component.ngOnInit();
    expect(component['nomCommercial']).toEqual('MIWTO BELYB');
    expect(component.contactPPE).toEqual(MockRetourRepresentantLegalPPE);
  });
});

const MockDonneesAdmin = {
  raisonSociale: 'EVAYEYAV EBTYTO',
  nomCommercial: 'MIWTO BELYB',
  numeroSiren: '302769161',
  adressePrincipale: { ligne2: null, ligne3: null, ligne4: '1    RUE DU GAZ', ligne5: 'BP 93330', ligne6: '12033 RODEZ CEDEX 9' },
  interlocuteurPrincipal: {
    designation: 'MR JALADEAU FREDERIC',
    medias: [
      { estMediaValeur: true, type: 1, valeur: '05 65 73 31 92' },
      { estMediaValeur: false, type: 2, valeur: 'Non Renseigné' },
      { estMediaValeur: true, type: 0, valeur: 'fjaladeau@udaf12.fr' }
    ],
    poste: 'CONTACT BANQUE A DISTANCE'
  }
};

const MockRetourBeneficiairePPE = {
  designation: 'MIWTO BELYB',
  role: 'Bénéficiaire effectif'
};

const MockRetourRepresentantLegalPPE = {
  designation: 'MIWTO BELYB',
  role: 'Représentant légal'
};

const MockDonneesLiens = {
  listeNominationsReglementaires: [
    {
      numeroPersonne: '94211210',
      identite: 'FENNO VEBIO',
      fonction: 'Gérant',
      ppe: false,
      provenanceStatutPpe: ''
    },
    {
      numeroPersonne: '94211213',
      identite: 'MIWTO BELYB',
      fonction: 'Dirigeant',
      ppe: false,
      provenanceStatutPpe: ''
    }
  ],
  listeBeneficiairesEffectifs: [
    {
      numeroPersonne: '94211210',
      pourcentageDetention: '50%',
      gouvernanceDetention: 'Capital direct et indirect',
      ppe: false,
      provenanceStatutPpe: '',
      identite: 'FENNO VEBIO',
      role: 'Bénéficiaire effectif'
    },
    {
      numeroPersonne: '94211213',
      pourcentageDetention: '50%',
      gouvernanceDetention: 'Capital direct et indirect',
      ppe: false,
      provenanceStatutPpe: '',
      identite: 'MIWTO BELYB',
      role: 'Bénéficiaire effectif'
    }
  ]
};

const MockDonneesLiensRepresentantLegalPPE = {
  listeNominationsReglementaires: [
    {
      numeroPersonne: '94211210',
      identite: 'FENNO VEBIO',
      fonction: 'Gérant',
      ppe: false,
      provenanceStatutPpe: ''
    },
    {
      numeroPersonne: '94211213',
      identite: 'MIWTO BELYB',
      fonction: 'Représentant légal',
      ppe: true,
      provenanceStatutPpe: ''
    }
  ],
  listeBeneficiairesEffectifs: [
    {
      numeroPersonne: '94211210',
      pourcentageDetention: '50%',
      gouvernanceDetention: 'Capital direct et indirect',
      ppe: false,
      provenanceStatutPpe: '',
      identite: 'FENNO VEBIO',
      role: 'Bénéficiaire effectif'
    },
    {
      numeroPersonne: '94211213',
      pourcentageDetention: '50%',
      gouvernanceDetention: 'Capital direct et indirect',
      ppe: false,
      provenanceStatutPpe: '',
      identite: 'MIWTO BELYB',
      role: 'Bénéficiaire effectif'
    }
  ]
};

const MockDonneesLiensBePPE = {
  listeNominationsReglementaires: [
    {
      numeroPersonne: '94211210',
      identite: 'FENNO VEBIO',
      fonction: 'Gérant',
      ppe: false,
      provenanceStatutPpe: ''
    },
    {
      numeroPersonne: '94211213',
      identite: 'MIWTO BELYB',
      fonction: 'Dirigeant',
      ppe: true,
      provenanceStatutPpe: ''
    }
  ],
  listeBeneficiairesEffectifs: [
    {
      numeroPersonne: '94211210',
      pourcentageDetention: '50%',
      gouvernanceDetention: 'Capital direct et indirect',
      ppe: false,
      provenanceStatutPpe: '',
      identite: 'FENNO VEBIO',
      role: 'Bénéficiaire effectif'
    },
    {
      numeroPersonne: '94211213',
      pourcentageDetention: '50%',
      gouvernanceDetention: 'Capital direct et indirect',
      ppe: true,
      provenanceStatutPpe: '',
      identite: 'MIWTO BELYB',
      role: 'Bénéficiaire effectif'
    }
  ]
};
