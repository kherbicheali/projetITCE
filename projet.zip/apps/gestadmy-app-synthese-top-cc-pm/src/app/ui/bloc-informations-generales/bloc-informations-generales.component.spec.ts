import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BlocInformationsGeneralesComponent } from './bloc-informations-generales.component';

describe('BlocInformationsGeneralesComponent', () => {
  let component: BlocInformationsGeneralesComponent;
  let fixture: ComponentFixture<BlocInformationsGeneralesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BlocInformationsGeneralesComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlocInformationsGeneralesComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component', () => {
    component.ngOnInit();
  });
});
