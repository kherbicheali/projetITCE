import { NgModule } from '@angular/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MyWayExpansionPanelModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { CoordonneesPmModule } from '../coordonnees-pm/coordonnees-pm.module';
import { NatureRelationModule } from '../nature-relation/nature-relation.module';
import { BlocInformationsGeneralesComponent } from './bloc-informations-generales.component';

@NgModule({
  declarations: [BlocInformationsGeneralesComponent],
  imports: [SharedModule, MatExpansionModule, NatureRelationModule, CoordonneesPmModule, MyWayExpansionPanelModule],
  exports: [BlocInformationsGeneralesComponent]
})
export class BlocInformationsGeneralesModule {}
