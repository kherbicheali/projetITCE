import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 'gestadmy-bloc-informations-generales',
  templateUrl: './bloc-informations-generales.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BlocInformationsGeneralesComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
