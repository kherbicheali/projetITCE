import { NgModule } from '@angular/core';
import { MyWayCardModule, MyWayTooltipModule } from '@myway/ui';
import { SharedModule } from '../../shared/shared.module';
import { StatutInformationsJuridiquesComponent } from './statut-informations-juridiques.component';

@NgModule({
  declarations: [StatutInformationsJuridiquesComponent],
  imports: [SharedModule, MyWayCardModule, MyWayTooltipModule],
  exports: [StatutInformationsJuridiquesComponent]
})
export class StatutInformationsJuridiquesModule {}
