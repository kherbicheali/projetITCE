import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';

@Component({
  selector: 'gestadmy-statut-informations-juridiques',
  templateUrl: './statut-informations-juridiques.component.html',
  changeDetection: ChangeDetectionStrategy.Default
})
export class StatutInformationsJuridiquesComponent implements OnInit {
  public identifiantPersonne: string;

  constructor(public lisaUtilsService: LisaUtilsService, private store: Store, public alertesTopCCService: AlertesTopCCService) {}

  ngOnInit() {
    this.identifiantPersonne = this.store.selectSnapshot(ContexteState.getContent).identifiantPersonne;
  }
}
