import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Store } from '@ngxs/store';
import { IContexte } from '../../shared/modeles/contexte.model';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { StatutInformationsJuridiquesComponent } from './statut-informations-juridiques.component';

const MockContexte = <IContexte>{
  codeEtablissement: '17515',
  estPersonnePhysique: false,
  identifiantPersonne: '9031175'
};

describe('StatutInformationsJuridiquesComponent', () => {
  let component: StatutInformationsJuridiquesComponent;
  let fixture: ComponentFixture<StatutInformationsJuridiquesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StatutInformationsJuridiquesComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        {
          provide: LisaUtilsService,
          useValue: { debrancherVersClasseurClient: () => {} }
        },
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {}, selectSnapshot: () => MockContexte }
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatutInformationsJuridiquesComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component', () => {
    component.ngOnInit();
  });
});
