import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NotificationService } from '@myway/ui';
import { Store } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { of } from 'rxjs';
import { IContexte } from '../../shared/modeles/contexte.model';
import { DonneesCorporateModele } from '../../shared/modeles/donnees-corporate.modele';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { AbstractMockObservableService } from '../../shared/services/utils/abstract-mock-observable.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { DonneesNatureRelationState } from '../../shared/states/donnees-nature-relation/donnees-nature-relation.state';
import { ExistenceJuridiqueComponent } from './existence-juridique.component';

class ContextAgentMockService extends AbstractMockObservableService {
  addListToContext(param: { keyValues: Map<string, any>; storageLevel: number }) {
    return this;
  }
}

const MockContexte = <IContexte>{
  codeEtablissement: '17515',
  estPersonnePhysique: false,
  identifiantPersonne: '9031175'
};

describe('ExistenceJuridiqueComponent', () => {
  let component: ExistenceJuridiqueComponent;
  let fixture: ComponentFixture<ExistenceJuridiqueComponent>;
  const contextAgentServiceStub = new ContextAgentMockService();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ExistenceJuridiqueComponent],
      providers: [
        {
          provide: LisaAgentService,
          useValue: { next: () => {} }
        },
        {
          provide: NotificationService,
          useValue: { openInfo: () => {} }
        },
        {
          provide: ContextAgentService,
          useValue: contextAgentServiceStub
        },
        {
          provide: LisaUtilsService,
          useValue: { debrancherVersClasseurClient: () => {} }
        },
        {
          provide: Store,
          useValue: { dispatch: () => {}, select: () => {}, selectSnapshot: () => MockContexte }
        },
        AlertesTopCCService,
        {
          provide: DonneesNatureRelationState,
          useValue: { getContent: () => of({}) }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistenceJuridiqueComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'donneesExistenceJuridique$', { writable: true });
    component.alertesTopCCService.listeAlertes = [];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('init component pas de donnees existence juridique', () => {
    component.donneesExistenceJuridique$ = of(undefined);
    component.ngOnInit();
    expect(component.existenceJuridique).toBeUndefined();
  });

  it('init component avec donnees existence juridique', () => {
    component.donneesExistenceJuridique$ = of(mockDonneesExistenceJuridique);
    component.ngOnInit();
    expect(component.existenceJuridique).toEqual(mockDonneesExistenceJuridique);
  });

  const mockDonneesExistenceJuridique: DonneesCorporateModele.IExistenceJuridique = {
    categorieJuridique: '9220',
    dateCloture: '01/01/2020',
    dateCreation: '01/01/1900',
    montantCapitalSocial: '€306,000',
    nomCommercial: 'ICYACJO EVAYEYAV EBTYTO',
    numeroSiren: '302769161',
    raisonSocial: 'ICYACJO EVAYEYAV EBTYTO',
    secteurActivite: '8899B'
  } as DonneesCorporateModele.IExistenceJuridique;
});
