import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { NotificationService } from '@myway/ui';
import { Select, Store } from '@ngxs/store';
import { ContextAgentService } from '@ptmyway-stc-v2/core-agent';
import { ErrorMessage, StorageLevel } from '@ptmyway-stc-v2/core-common';
import { LisaAgentService } from '@ptmyway-stc-v2/lisa-agent';
import { LisaCallbackResult } from '@ptmyway-stc-v2/lisa-common';
import * as moment from 'moment';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DATAINCONNU, ERREUR_REST_EXISTENCE_JURIDIQUE } from '../../shared/constantes/ihm.constantes';
import { PROCESSUS_LISA_CONNAISSANCE_CLIENT } from '../../shared/constantes/lisa.constantes';
import { AppEnum } from '../../shared/enums/app-enums';
import { IAlerte } from '../../shared/modeles/alerte.modele';
import { DonneesCorporateModele } from '../../shared/modeles/donnees-corporate.modele';
import { INatureRelation } from '../../shared/modeles/nature-relation.modele';
import { AlertesTopCCService } from '../../shared/services/alertes-topcc/alertes-topcc.service';
import { LisaUtilsService } from '../../shared/services/utils/lisa-utils.service';
import { ContexteState } from '../../shared/states/contexte/contexte.state';
import { DonneesCorporateState } from '../../shared/states/donnees-corporate/donnees-corporate.state';
import { DonneesNatureRelationState } from '../../shared/states/donnees-nature-relation/donnees-nature-relation.state';

@Component({
  selector: 'gestadmy-existence-juridique',
  templateUrl: './existence-juridique.component.html',
  changeDetection: ChangeDetectionStrategy.Default
})
export class ExistenceJuridiqueComponent implements OnInit, OnDestroy {
  public existenceJuridique: DonneesCorporateModele.IExistenceJuridique;
  private natureRelation: INatureRelation;
  public texteErreurRestExistenceJuridique: string;
  public identifiantPersonne: string;
  @Select(DonneesCorporateState.getExistenceJuridique) donneesExistenceJuridique$: Observable<DonneesCorporateModele.IExistenceJuridique>;
  @Select(DonneesCorporateState.getError) error$: Observable<HttpErrorResponse>;
  @Select(DonneesCorporateState.isLoading) isLoading$: Observable<boolean>;
  @Select(DonneesNatureRelationState.getContent) donneesNatureRelation$: Observable<INatureRelation>;
  private unsubscribe$ = new Subject<void>();
  public estPersonnePhysique: boolean;

  constructor(
    private lisaAgentService: LisaAgentService,
    private notification: NotificationService,
    private contextAgentService: ContextAgentService,
    public lisaUtilsService: LisaUtilsService,
    private store: Store,
    public alertesTopCCService: AlertesTopCCService
  ) {}

  ngOnInit() {
    this.texteErreurRestExistenceJuridique = ERREUR_REST_EXISTENCE_JURIDIQUE;
    this.identifiantPersonne = this.store.selectSnapshot(ContexteState.getContent).identifiantPersonne;
    this.estPersonnePhysique = this.store.selectSnapshot(ContexteState.getContent).estPersonnePhysique;

    this.donneesExistenceJuridique$.pipe(takeUntil(this.unsubscribe$)).subscribe((result: DonneesCorporateModele.IExistenceJuridique) => {
      if (result) {
        this.existenceJuridique = result;
        this.ajoutAlerteDateCloture();
        this.donneesNatureRelation$.pipe(takeUntil(this.unsubscribe$)).subscribe((nature: INatureRelation) => {
          if (nature) {
            this.natureRelation = nature;
          }
        });
      }
    });
  }

  private ajoutAlerteDateCloture() {
    if (
      this.existenceJuridique.dateCloture !== DATAINCONNU &&
      moment()
        .startOf('day')
        .diff(moment(this.existenceJuridique.dateCloture, 'DD/MM/YYYY'), 'days') > 0
    ) {
      const alerteDateCloture: IAlerte = {
        codeAppartenanceBloc: AppEnum.CodeAppartenanceBloc.CODE_APPARTENANCE_BLOC_EXISTENCE_JURIDIQUE,
        entete: 'Existence juridique',
        message: 'Date de clôture de la personne morale dépassée',
        isBloquante: true
      };
      this.alertesTopCCService.ajouterAlerte(alerteDateCloture);
    }
  }

  public debranchementConnClientIdent() {
    const keyValuesToAdd: Map<string, any> = new Map<string, any>([
      ['codePage', this.estPersonnePhysique ? 'activitePro' : 'identification']
    ]);
    this.contextAgentService
      .addListToContext({
        keyValues: keyValuesToAdd,
        storageLevel: StorageLevel.Process
      })
      .subscribe(
        () => {
          this.lisaAgentService.next({ exitValue: PROCESSUS_LISA_CONNAISSANCE_CLIENT }).subscribe(
            (result: LisaCallbackResult) => {},
            (erreur: ErrorMessage) => {
              this.notification.openInfo("Erreur de lancement de l'application Connaissance Client");
            }
          );
        },
        (erreur: ErrorMessage) => {
          this.notification.openInfo("Erreur d'enregistrement dans le contexte");
        }
      );
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
