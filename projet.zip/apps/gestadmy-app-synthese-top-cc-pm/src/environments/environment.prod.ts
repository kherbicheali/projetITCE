import { EnvironmentProdModule } from '@myway/env';

export const environment = {
  production: true,
  envModule: EnvironmentProdModule
};
