'use strict';

module.exports = {
  allowBreakingChanges: [
      'feat'
  ],
  allowCustomScopes: false,
  scopes: [
      '*'
  ],
  types: [
    {value: 'feat',        name: 'feat:       🌟   A new feature.'},
    {value: 'fix',         name: 'fix:        🐞   A bug fix.'},
    {value: 'refactor',    name: 'refactor:   🎨   A code change that neither fixes a bug nor adds a feature like cleanup.'},
    {value: 'demo',        name: 'demo:       🔮   An improvement of the demo app.'},
    {value: 'docs',        name: 'docs:       📚   Documentation only changes.'},
    {value: 'test',        name: 'test:       ✅   Adding missing tests'},
    {value: 'chore',       name: 'chore:      🔩   Changes to the build process or auxiliary tools\n                  and libraries such as documentation generation.'},
    {value: 'revert',      name: 'revert:     ⏪   Revert to a commit.'}
  ]
};
