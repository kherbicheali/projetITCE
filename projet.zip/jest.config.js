module.exports = {
  preset: 'jest-preset-angular',
  setupFilesAfterEnv: ['<rootDir>/jest/jest-setup.ts'],
  globals: {
    'ts-jest': {
      tsConfig: '<rootDir>/tsconfig.spec.json',
      stringifyContentPathRegex: '\\.html$',
      astTransformers: ['jest-preset-angular/build/InlineFilesTransformer', 'jest-preset-angular/build/StripStylesTransformer']
    }
  },
  moduleDirectories: ['node_modules', 'projects'],
  roots: ['<rootDir>/apps/', '<rootDir>/libs/'],
  coverageReporters: ['html'],
  collectCoverage: true,
  coverageDirectory: 'coverage',

  coverageReporters: ['html'],
  coverageThreshold: {
    global: {
      branches: 60,
      functions: 60,
      lines: 60,
      statements: 60
    }
  },
  moduleNameMapper: {
    '@clients-gestadm-top-connaissance-client/gestadmy-lib-synthese-top-cc-pm-rest':
      '<rootDir>/libs/gestadmy-lib-synthese-top-cc-pm-rest/src/index.ts'
  }
};
